// Fabrique un paquet .aihubupdate (format 1, universel) à partir d'un dossier contenant les 4 fichiers du noyau.
// Usage : node tools/make-update.js <dossier-du-noyau> <version> "<notes>" [sortie.aihubupdate]
// Règle n°1 : toujours un paquet COMPLET (les 4 fichiers), requiresLauncher = null, version strictement supérieure.
const fs = require('fs'), path = require('path');
const { buildPackage } = require('../launcher/updater.js');
const [dir, version, notes, out] = process.argv.slice(2);
if (!dir || !version) { console.error('usage : node tools/make-update.js <dossier-du-noyau> <version> "<notes>" [sortie]'); process.exit(1); }
const RULE = '⚠ RÈGLE N°1 — MISE À JOUR UNIVERSELLE (à lire AVANT toute modification de ce fichier)\nCette mise à jour doit TOUJOURS être compatible, PEU IMPORTE la version actuellement installée :\nversion d\'origine de l\'exe, ancienne, récente, ou même plus récente que celle-ci. N\'importe qui doit\npouvoir l\'installer, depuis n\'importe quelle version, sans rien perdre (comptes, scripts, réglages).\nPour cela, TOUJOURS :\n 1. Livrer un paquet COMPLET : les 4 fichiers (main-core.js, preload.js, webview-preload.js, index.html), jamais un paquet partiel.\n 2. requiresLauncher = null. Ne rien supposer du lanceur (voir normalizeCtx dans main-core.js) et ne jamais exiger un lanceur plus récent.\n 3. Garder les 4 fichiers cohérents entre eux (preload.js <-> main-core.js <-> index.html).\n 4. Savoir lire les données écrites par N\'IMPORTE QUELLE version : champ absent = valeur par défaut ; ne jamais supprimer ni réécrire un champ inconnu.\n 5. Ne rien écrire qu\'une version plus ancienne ne puisse relire (le retour arrière doit toujours marcher).\n 6. Numéro de version strictement supérieur au précédent ; un numéro déjà publié n\'est jamais réutilisé.';
const pkg = buildPackage({ dir, version, notes, requiresLauncher: null, header: RULE });
const file = out || 'ai-hub-update-' + version + '.aihubupdate';
fs.writeFileSync(file, JSON.stringify(pkg)); console.log('écrit :', path.resolve(file), '(' + fs.statSync(file).size + ' octets)');
