// Compatibilité : l'ancien lanceur (et tools/make-update.js) chargeaient « ./updater ». Tout vit maintenant dans launcher/updater.js.
module.exports = require('./launcher/updater.js');
