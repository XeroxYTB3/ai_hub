// Lanceur 10 — amorçage STABLE. Ce fichier est volontairement minuscule : il ne change (presque) jamais.
// Il choisit le lanceur à utiliser (une version plus récente reconstruite dans les données d'AI Hub, sinon celle livrée
// à côté de ce fichier), puis laisse ce lanceur choisir et démarrer le noyau (core/ d'origine ou version mise à jour).
const { app } = require('electron');
const path = require('path'), fs = require('fs'), crypto = require('crypto');
if (!process.env.AIHUB_TEST) app.setPath('userData', path.join(app.getPath('appData'), 'ai-hub'));

const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const newer = (a, b) => { const x = String(a).split(/[.-]/).map(Number), y = String(b).split(/[.-]/).map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
const sleep = (ms) => { try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch {} };

// Un remplacement des fichiers du lanceur est en cours (quelques secondes au plus) : on attend qu'il soit fini
try { const lock = path.join(app.getPath('userData'), 'launcher', 'swap', 'lock'); for (let i = 0; i < 40 && fs.existsSync(lock) && Date.now() - fs.statSync(lock).mtimeMs < 60000; i++) sleep(500); } catch {}

let shipped = '0.0.0'; try { shipped = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).version; } catch {}
function pick() {
  try {                                                    // lanceur reconstruit, plus récent que celui-ci, intact
    const ud = app.getPath('userData'), cur = JSON.parse(fs.readFileSync(path.join(ud, 'launcher', 'current.json'), 'utf8')), dir = path.join(ud, 'launcher', cur.version);
    if (newer(cur.version, shipped) && Object.entries(cur.files).every(([rel, h]) => sha(fs.readFileSync(path.join(dir, rel))) === h)) return path.join(dir, 'launcher');
  } catch {}
  return path.join(__dirname, 'launcher');
}
let boot, dir = pick();
try { boot = require(path.join(dir, 'boot.js')); }
catch (e) { if (dir === path.join(__dirname, 'launcher')) throw e; boot = require(path.join(__dirname, 'launcher', 'boot.js')); dir = path.join(__dirname, 'launcher'); }

const ctx = boot.createContext({ app, appDir: __dirname, launcherDir: dir });
try { require(path.join(ctx.boot.dir, 'main-core.js'))(ctx); }
catch (e) { if (!ctx.fatal('chargement impossible : ' + e.message)) throw e; }
