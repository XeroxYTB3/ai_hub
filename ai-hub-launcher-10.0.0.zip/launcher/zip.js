'use strict';
// zip.js : lecture et écriture de fichiers ZIP, sans aucune dépendance (zlib + Buffer).
// Lecture sûre : pas de chemin absolu, pas de « .. », pas de ZIP64, limites de taille, CRC vérifié.
const zlib = require('zlib');

const LIM = { files: 3000, entry: 120 * 1048576, total: 400 * 1048576 };
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC_T[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };

function safeName(n) {
  n = String(n).replace(/\\/g, '/');
  if (!n || n.includes('\0') || n.startsWith('/') || /^[a-zA-Z]:/.test(n)) throw new Error('chemin refusé dans le ZIP : ' + n);
  if (n.split('/').some((s) => s === '..')) throw new Error('chemin refusé dans le ZIP (..) : ' + n);
  return n;
}

// Retourne [{ name, data: Buffer }] (les dossiers sont ignorés)
function readZip(buf, limits) {
  const lim = Object.assign({}, LIM, limits || {});
  if (!Buffer.isBuffer(buf) || buf.length < 22) throw new Error('ce n\'est pas un fichier ZIP');
  let eocd = -1;
  for (let i = buf.length - 22, stop = Math.max(0, buf.length - 22 - 65535); i >= stop; i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('ce n\'est pas un fichier ZIP (fin de fichier introuvable)');
  const count = buf.readUInt16LE(eocd + 10), cdSize = buf.readUInt32LE(eocd + 12), cdOff = buf.readUInt32LE(eocd + 16);
  if (count === 0xFFFF || cdOff === 0xFFFFFFFF || cdSize === 0xFFFFFFFF) throw new Error('ZIP64 non géré');
  if (count > lim.files) throw new Error('trop de fichiers dans le ZIP (' + count + ')');
  if (cdOff + cdSize > buf.length) throw new Error('ZIP tronqué ou corrompu');
  const out = []; let p = cdOff, total = 0;
  for (let k = 0; k < count; k++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new Error('ZIP corrompu (répertoire central)');
    const flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16);
    const csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const rawName = buf.toString('utf8', p + 46, p + 46 + nl); p += 46 + nl + el + cl;
    if (rawName.endsWith('/')) continue;                                  // dossier
    const name = safeName(rawName);
    if (flags & 1) throw new Error('ZIP chiffré non géré : ' + name);
    if (csize === 0xFFFFFFFF || usize === 0xFFFFFFFF) throw new Error('ZIP64 non géré : ' + name);
    if (usize > lim.entry) throw new Error('fichier trop gros dans le ZIP : ' + name);
    total += usize; if (total > lim.total) throw new Error('ZIP trop gros une fois décompressé');
    if (lo + 30 > buf.length || buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('ZIP corrompu (en-tête local) : ' + name);
    const start = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28);
    if (start + csize > buf.length) throw new Error('ZIP tronqué : ' + name);
    const raw = buf.subarray(start, start + csize);
    let data;
    if (method === 0) data = Buffer.from(raw);
    else if (method === 8) data = zlib.inflateRawSync(raw, { maxOutputLength: lim.entry + 1 });
    else throw new Error('méthode de compression non gérée (' + method + ') : ' + name);
    if (data.length !== usize) throw new Error('taille incorrecte : ' + name);
    if (crc32(data) !== crc) throw new Error('somme de contrôle incorrecte (ZIP corrompu) : ' + name);
    out.push({ name, data });
  }
  return out;
}

// entries : [{ name, data: Buffer, mtime?: Date }]
function makeZip(entries) {
  const locals = [], central = []; let off = 0;
  for (const e of entries) {
    const name = Buffer.from(safeName(e.name), 'utf8'), raw = Buffer.isBuffer(e.data) ? e.data : Buffer.from(e.data);
    const def = zlib.deflateRawSync(raw, { level: 9 }), useDef = def.length < raw.length, body = useDef ? def : raw, method = useDef ? 8 : 0;
    const crc = crc32(raw), d = e.mtime || new Date(Date.UTC(2026, 9, 14, 12, 0, 0));
    const time = (d.getUTCHours() << 11) | (d.getUTCMinutes() << 5) | (d.getUTCSeconds() >> 1);
    const date = (((d.getUTCFullYear() - 1980) & 127) << 9) | ((d.getUTCMonth() + 1) << 5) | d.getUTCDate();
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(time, 10); lh.writeUInt16LE(date, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(name.length, 26);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(method, 10);
    ch.writeUInt16LE(time, 12); ch.writeUInt16LE(date, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(body.length, 20); ch.writeUInt32LE(raw.length, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(off, 42);
    locals.push(lh, name, body); central.push(ch, name); off += 30 + name.length + body.length;
  }
  const cd = Buffer.concat(central), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...locals, cd, end]);
}

module.exports = { readZip, makeZip, crc32, safeName };
