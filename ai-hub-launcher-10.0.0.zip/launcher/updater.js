'use strict';
// updater.js (lanceur 10) : logique de mise à jour SANS Electron, compatible avec l'ancien format.
// - Mêmes fichiers et même format que l'ancien updater (state.json, versions/<v>/, paquets .aihubupdate format 1) :
//   un ancien lanceur relit tout ce que celui-ci écrit, et inversement (retour arrière toujours possible).
// - Nouveautés : écriture atomique + copie de secours de state.json, paquets jusqu'à 64 Mo,
//   « obsolète » jugé seulement quand le noyau d'origine (exe / lanceur) a changé, installation depuis un fichier,
//   dernière version confirmée (lastGood).
const fs = require('fs'), path = require('path'), crypto = require('crypto'), vm = require('vm');

const CORE_FILES = ['main-core.js', 'preload.js', 'webview-preload.js', 'index.html'];
const MAX_UNCONFIRMED = 2;                 // lancements sans confirmation avant retour arrière
const MAX_PKG_BYTES = 64 * 1024 * 1024;    // (8 Mo dans les anciens lanceurs)
const VERSION_RE = /^\d+\.\d+\.\d+(-[\w.]+)?$/;

const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const nums = (v) => String(v).split(/[.-]/).slice(0, 3).map((n) => parseInt(n, 10) || 0);
function cmp(a, b) {
  const x = nums(a), y = nums(b);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0);
  return 0;
}

// Vérifie la syntaxe sans exécuter (JS : fonction enveloppante ; HTML : chaque <script> en ligne)
function checkSyntax(name, code) {
  try {
    if (name.endsWith('.js')) new vm.Script('(function(exports,require,module,__filename,__dirname){' + code + '\n})', { filename: name });
    else if (name.endsWith('.html')) {
      const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi; let m, n = 0;
      while ((m = re.exec(code))) { n++; new vm.Script(m[1], { filename: name + '#script' + n }); }
    }
    return null;
  } catch (e) { return name + ' : ' + e.message; }
}

function atomicWrite(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, data);
  try { if (fs.existsSync(file)) fs.copyFileSync(file, file + '.bak'); } catch {}
  try { fs.renameSync(tmp, file); }
  catch (e) { try { fs.writeFileSync(file, data); fs.unlinkSync(tmp); } catch { throw e; } }
}

function createUpdater({ root, bundledDir, launcherVersion, bundledVersion: bundledOverride, keep = 5 }) {
  const F = { state: path.join(root, 'state.json'), versions: path.join(root, 'versions') };
  const fresh = () => ({ current: 'bundled', previous: 'bundled', pending: null, bad: [], history: [] });
  const dirOf = (v) => (v === 'bundled' ? bundledDir : path.join(F.versions, v));

  // Version du noyau fourni avec le lanceur (core/core.json) ; à défaut, la version du lanceur (ancien comportement)
  function bundledVersion() {
    try { const j = JSON.parse(fs.readFileSync(path.join(bundledDir, 'core.json'), 'utf8')); if (VERSION_RE.test(String(j.version))) return String(j.version); } catch {}
    return String(bundledOverride || launcherVersion);
  }

  function normalize(s) {
    s = Object.assign(fresh(), s && typeof s === 'object' ? s : {});     // les champs inconnus sont conservés
    if (!Array.isArray(s.bad)) s.bad = [];
    if (!Array.isArray(s.history)) s.history = [];
    if (typeof s.current !== 'string') s.current = 'bundled';
    if (typeof s.previous !== 'string') s.previous = 'bundled';
    return s;
  }
  function readState() {
    for (const f of [F.state, F.state + '.bak']) {
      try { return normalize(JSON.parse(fs.readFileSync(f, 'utf8'))); } catch {}
    }
    return fresh();
  }
  function writeState(s) { atomicWrite(F.state, JSON.stringify(s, null, 1)); }
  const note = (s, action, version, detail) => {
    s.history.push({ ts: Date.now(), action, version, detail: detail || '' });
    s.history = s.history.slice(-50);
  };

  // Vérifie qu'un dossier de version est complet et intact
  function verifyDir(v) {
    const d = dirOf(v);
    try {
      if (v === 'bundled') {
        for (const f of CORE_FILES) if (!fs.existsSync(path.join(d, f))) return { ok: false, reason: 'fichier d\'origine manquant : ' + f };
        return { ok: true };
      }
      const man = JSON.parse(fs.readFileSync(path.join(d, 'manifest.json'), 'utf8'));
      for (const f of CORE_FILES) {
        if (!man.files || !man.files[f]) return { ok: false, reason: 'manifeste incomplet : ' + f };
        if (sha(fs.readFileSync(path.join(d, f))) !== man.files[f]) return { ok: false, reason: 'fichier modifié ou corrompu : ' + f };
      }
      return { ok: true, manifest: man };
    } catch (e) { return { ok: false, reason: e.code === 'ENOENT' ? 'dossier de version absent' : e.message }; }
  }

  // Retour arrière : marque la version courante comme mauvaise, repasse à la précédente (ou à l'origine)
  function fallback(s, reason) {
    const bad = s.current;
    if (bad !== 'bundled') s.bad = [...new Set([...s.bad, bad])];
    let prev = s.previous && s.previous !== bad ? s.previous : 'bundled';
    if (prev !== 'bundled' && !verifyDir(prev).ok) prev = 'bundled';
    s.current = prev; s.previous = 'bundled'; s.pending = null;
    note(s, 'rollback', bad, reason);
    return reason;
  }

  // Appelé au démarrage : choisit le dossier de code à lancer
  function prepare() {
    const s = readState(), bv = bundledVersion();
    let rolledBack = null;
    if (s.bundledSeen !== bv) {                          // l'exe, le lanceur ou le noyau d'origine a changé depuis le dernier lancement
      if (s.current !== 'bundled' && cmp(s.current, bv) <= 0) {
        const ver = s.current;
        s.current = 'bundled'; s.previous = 'bundled'; s.pending = null;
        note(s, 'obsolete', ver, 'remplacée par le noyau ' + bv + ' du lanceur');
      }
      s.bundledSeen = bv;
    }
    if (s.current !== 'bundled') {
      const ver = s.current, v = verifyDir(ver);
      if (!v.ok) rolledBack = fallback(s, v.reason);
      else if (s.pending && s.pending.version === ver) {
        if (s.pending.boots >= MAX_UNCONFIRMED) rolledBack = fallback(s, 'non confirmée après ' + MAX_UNCONFIRMED + ' lancements');
        else s.pending.boots++;
      }
    }
    writeState(s);
    return { version: s.current, dir: dirOf(s.current), rolledBack };
  }

  // La nouvelle version a démarré correctement
  function confirm() {
    const s = readState();
    if (!s.pending) return false;
    note(s, 'confirmed', s.pending.version);
    s.lastGood = s.pending.version; s.pending = null; writeState(s); return true;
  }

  // Échec détecté pendant l'essai d'une nouvelle version : retour arrière immédiat
  function fail(reason) {
    const s = readState();
    if (!s.pending) return false;
    fallback(s, reason || 'échec au démarrage'); writeState(s); return true;
  }

  function validatePackage(pkg) {
    if (!pkg || typeof pkg !== 'object' || pkg.app !== 'ai-hub-update' || pkg.format !== 1) return 'Ce fichier n\'est pas un paquet de mise à jour AI Hub';
    if (!VERSION_RE.test(String(pkg.version))) return 'Numéro de version invalide : ' + pkg.version;
    if (!pkg.files || typeof pkg.files !== 'object' || !Object.keys(pkg.files).length) return 'Paquet vide';
    for (const [name, f] of Object.entries(pkg.files)) {
      if (!CORE_FILES.includes(name)) return 'Fichier non autorisé dans le paquet : ' + name;
      if (!f || typeof f.content !== 'string') return 'Contenu illisible : ' + name;
      if (sha(Buffer.from(f.content, 'utf8')) !== f.sha256) return 'Empreinte incorrecte (paquet altéré) : ' + name;
      const err = checkSyntax(name, f.content);
      if (err) return 'Erreur de syntaxe, paquet refusé — ' + err;
    }
    if (pkg.requiresLauncher && cmp(launcherVersion, pkg.requiresLauncher) < 0)
      return 'Ce paquet demande un lanceur ' + pkg.requiresLauncher + ' (le tien est ' + launcherVersion + ')';
    return null;
  }

  function readPackage(file) {
    const st = fs.statSync(file);
    if (st.size > MAX_PKG_BYTES) throw new Error('Fichier trop gros pour un paquet de mise à jour');
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  }

  // Installe un paquet : écrit versions/<v>/, bascule, marque "en attente de confirmation"
  function install(pkg, opts = {}) {
    const err = validatePackage(pkg);
    if (err) return { ok: false, error: err };
    const ver = String(pkg.version), s = readState();
    if (ver === s.current) return { ok: false, error: 'La version ' + ver + ' est déjà active' };
    if (opts.beforeInstall) { try { opts.beforeInstall(ver); } catch {} }   // sauvegarde des données
    const tmp = path.join(F.versions, ver + '.tmp'), dst = path.join(F.versions, ver);
    fs.rmSync(tmp, { recursive: true, force: true });
    fs.mkdirSync(tmp, { recursive: true });
    const files = {};
    for (const f of CORE_FILES) {                       // base = fichiers d'origine, recouverts par le paquet
      const buf = pkg.files[f] ? Buffer.from(pkg.files[f].content, 'utf8') : fs.readFileSync(path.join(bundledDir, f));
      fs.writeFileSync(path.join(tmp, f), buf); files[f] = sha(buf);
    }
    fs.writeFileSync(path.join(tmp, 'manifest.json'), JSON.stringify({ version: ver, notes: pkg.notes || '', createdAt: pkg.createdAt || null, installedAt: Date.now(), files }, null, 1));
    fs.rmSync(dst, { recursive: true, force: true });
    fs.renameSync(tmp, dst);
    s.previous = s.pending ? s.previous : s.current;   // si l'ancienne n'était pas confirmée, on garde la dernière sûre
    if (s.bundledSeen === undefined) s.bundledSeen = bundledVersion();   // une installation voulue n'est pas « obsolète » tant que le noyau d'origine ne change pas
    s.current = ver; s.pending = { version: ver, boots: 0 };
    s.bad = s.bad.filter((x) => x !== ver);
    note(s, 'install', ver, pkg.notes || '');
    writeState(s);
    prune(s);
    return { ok: true, version: ver, previous: s.previous, notes: pkg.notes || '' };
  }

  function installFile(file, opts) {
    try { return install(readPackage(file), opts); }
    catch (e) { return { ok: false, error: 'Fichier illisible : ' + e.message }; }
  }

  function prune(s) {
    try {
      const keepSet = new Set([s.current, s.previous]);
      const all = fs.readdirSync(F.versions).filter((n) => !n.endsWith('.tmp') && n !== 'bundled').sort((a, b) => cmp(b, a));
      all.filter((n) => !keepSet.has(n)).slice(Math.max(0, keep - keepSet.size)).forEach((n) => fs.rmSync(path.join(F.versions, n), { recursive: true, force: true }));
    } catch {}
  }

  // Retour manuel : 'previous' ou 'bundled'
  function revert(to) {
    const s = readState();
    let target = to === 'bundled' ? 'bundled' : s.previous;
    if (target !== 'bundled' && !verifyDir(target).ok) target = 'bundled';
    if (target === s.current) return { ok: false, error: 'Déjà sur cette version' };
    note(s, 'revert', s.current, 'vers ' + target);
    s.previous = s.current; s.current = target; s.pending = null;
    writeState(s);
    return { ok: true, version: target };
  }

  function info() {
    const s = readState();
    let versions = [];
    try {
      versions = fs.readdirSync(F.versions).filter((n) => !n.endsWith('.tmp')).sort((a, b) => cmp(b, a)).map((n) => {
        const v = verifyDir(n);
        return { version: n, ok: v.ok, notes: v.manifest ? v.manifest.notes : '', installedAt: v.manifest ? v.manifest.installedAt : null };
      });
    } catch {}
    return { launcherVersion, bundledVersion: bundledVersion(), current: s.current, previous: s.previous, pending: s.pending, bad: s.bad, lastGood: s.lastGood || null, history: s.history.slice(-15).reverse(), versions };
  }

  return { prepare, confirm, fail, install, installFile, revert, info, readPackage, validatePackage, verifyDir, readState };
}

// Fabrique un paquet à partir d'un dossier core/ (utilisé par tools/make-update.js)
function buildPackage({ dir, version, notes, only, requiresLauncher, header }) {
  if (!VERSION_RE.test(version)) throw new Error('Version invalide : ' + version + ' (attendu 1.2.3)');
  const names = only && only.length ? only : CORE_FILES;
  const files = {};
  for (const n of names) {
    if (!CORE_FILES.includes(n)) throw new Error('Fichier non autorisé : ' + n);
    const content = fs.readFileSync(path.join(dir, n), 'utf8');
    const err = checkSyntax(n, content);
    if (err) throw new Error('Erreur de syntaxe : ' + err);
    files[n] = { sha256: sha(Buffer.from(content, 'utf8')), content };
  }
  const pkg = {};
  if (header) pkg.LIRE_EN_PREMIER = header;                 // la règle n°1 est TOUJOURS en tête du fichier
  return Object.assign(pkg, { app: 'ai-hub-update', format: 1, version, notes: notes || '', createdAt: new Date().toISOString(), requiresLauncher: requiresLauncher || null, files });
}

module.exports = { createUpdater, buildPackage, checkSyntax, cmp, sha, atomicWrite, CORE_FILES, MAX_UNCONFIRMED, MAX_PKG_BYTES, VERSION_RE };
