'use strict';
// swap.js : assistant de remplacement des fichiers du lanceur dans le dossier d'installation.
// Lancé en arrière-plan par AI Hub (ELECTRON_RUN_AS_NODE), il attend la fermeture d'AI Hub, puis :
//   1. vérifie les fichiers du nouveau lanceur ; 2. copie de secours de tout ce qu'il remplace ;
//   3. écrit chaque fichier en « .aihub-new » puis le renomme (jamais de fichier à moitié écrit) ;
//   4. contrôle les empreintes et fait un essai du nouveau lanceur ;
//   5. au moindre problème, remet la copie de secours : l'installation retrouve l'état d'avant.
// Résultat dans <données>/launcher/swap/result.json. Si AI Hub doit se relancer, l'assistant le fait.
const fs = require('fs'), path = require('path'), cp = require('child_process'), crypto = require('crypto');

const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const sleep = (ms) => { try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch { const t = Date.now() + ms; while (Date.now() < t); } };
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };
function atomicWrite(file, data) { const t = file + '.' + process.pid + '.tmp'; fs.writeFileSync(t, data); try { fs.renameSync(t, file); } catch { fs.writeFileSync(file, data); try { fs.unlinkSync(t); } catch {} } }
function retry(fn, what) {                                   // Windows : antivirus / fichier encore ouvert -> on réessaie
  let last; for (let i = 0; i < 40; i++) { try { return fn(); } catch (e) { last = e; if (!['EBUSY', 'EPERM', 'EACCES', 'ENOTEMPTY', 'EMFILE'].includes(e.code)) throw e; sleep(500); } }
  throw new Error(what + ' : ' + (last && last.message));
}

// Ordre : noyau, lanceur, puis main.js et package.json en dernier (ce sont eux qui font démarrer le nouveau lanceur)
function plan(job) {
  const items = [];
  for (const [name, h] of Object.entries(job.coreFiles || {})) items.push({ rel: 'core/' + name, src: path.join(job.coreSrc, name), sha: h });
  const inline = (job.files || {});
  const rank = (r) => r === 'main.js' ? 9 : r === 'package.json' ? 10 : r === 'updater.js' ? 5 : 3;
  for (const rel of Object.keys(inline).sort((a, b) => rank(a) - rank(b) || a.localeCompare(b))) items.push({ rel, src: path.join(job.stage, rel), sha: inline[rel] });
  return items;
}

function doSwap(job) {
  const items = plan(job), target = job.target, bk = path.join(job.userData, 'launcher', 'swap', 'backup-' + new Date().toISOString().replace(/[:.]/g, '-'));
  const coreJson = Buffer.from(JSON.stringify({ version: job.coreVersion || job.version }, null, 1));
  const journal = { target, createdTarget: false, entries: [] }, done = [];
  for (const it of items) { let d; try { d = fs.readFileSync(it.src); } catch (e) { throw new Error('fichier source introuvable : ' + it.rel); } if (sha(d) !== it.sha) throw new Error('fichier source altéré : ' + it.rel); }
  if (!fs.existsSync(target)) { journal.createdTarget = true; }
  fs.mkdirSync(bk, { recursive: true });
  const all = items.map((i) => i.rel).concat(['core/core.json']);
  for (const rel of all) {                                 // copie de secours
    const dst = path.join(target, rel); let existed = fs.existsSync(dst);
    if (existed) { fs.mkdirSync(path.dirname(path.join(bk, rel)), { recursive: true }); fs.copyFileSync(dst, path.join(bk, rel)); }
    journal.entries.push({ rel, existed });
  }
  atomicWrite(path.join(bk, 'journal.json'), JSON.stringify(journal, null, 1));
  try {
    fs.mkdirSync(target, { recursive: true });
    const write = (rel, data) => {
      const dst = path.join(target, rel), tmp = dst + '.aihub-new'; fs.mkdirSync(path.dirname(dst), { recursive: true });
      retry(() => fs.writeFileSync(tmp, data), 'écriture ' + rel);
      if (sha(fs.readFileSync(tmp)) !== sha(data)) throw new Error('écriture incorrecte : ' + rel);
      retry(() => fs.renameSync(tmp, dst), 'remplacement ' + rel); done.push(rel);
    };
    for (const it of items) { if (it.rel.startsWith('core/') && path.resolve(it.src) === path.resolve(path.join(target, it.rel))) continue; write(it.rel, fs.readFileSync(it.src)); if (it.rel === 'core/index.html') write('core/core.json', coreJson); }
    for (const it of items) if (sha(fs.readFileSync(path.join(target, it.rel))) !== it.sha) throw new Error('contrôle final : ' + it.rel);
    const pj = JSON.parse(fs.readFileSync(path.join(target, 'package.json'), 'utf8'));
    if (pj.main !== 'main.js' || pj.version !== job.version) throw new Error('package.json inattendu');
    try {                                                  // essai du nouveau lanceur installé
      const code = 'try{process.stdout.write(String(require(' + JSON.stringify(path.join(target, 'launcher', 'boot.js')) + ').selftest()))}catch(e){process.stderr.write(String(e&&e.stack||e));process.exit(3)}';
      const out = cp.execFileSync(process.execPath, ['-e', code], { env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }), timeout: 25000, windowsHide: true, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
      if (String(out).trim() !== 'ok') throw new Error('essai : résultat inattendu');
    } catch (e) { if (e.status === 3) throw new Error('essai du lanceur installé : ' + String(e.stderr || e.message).slice(0, 200)); }
    return { ok: true, version: job.version, backup: bk, files: all.length };
  } catch (e) {
    const restored = restore(journal, bk);
    return { ok: false, error: e.message, restored, backup: bk };
  }
}

function restore(journal, bk) {
  let ok = true;
  for (const en of journal.entries) {
    const dst = path.join(journal.target, en.rel);
    try {
      try { fs.unlinkSync(dst + '.aihub-new'); } catch {}
      if (en.existed) retry(() => { fs.copyFileSync(path.join(bk, en.rel), dst + '.aihub-back'); fs.renameSync(dst + '.aihub-back', dst); }, 'restauration ' + en.rel);
      else if (fs.existsSync(dst)) retry(() => fs.unlinkSync(dst), 'suppression ' + en.rel);
    } catch { ok = false; }
  }
  if (journal.createdTarget) { try { fs.rmSync(journal.target, { recursive: true, force: true }); } catch { ok = false; } }
  return ok;
}

function main(jobFile) {
  const readJob = () => { try { return JSON.parse(fs.readFileSync(jobFile, 'utf8')); } catch { return null; } };
  let job = readJob(); if (!job) return;
  const dir = path.dirname(jobFile), lock = path.join(dir, 'lock'), resFile = path.join(dir, 'result.json');
  job.state = 'waiting'; job.helperPid = process.pid; atomicWrite(jobFile, JSON.stringify(job, null, 1));
  const t0 = Date.now();
  for (;;) {                                               // attend la fermeture d'AI Hub (le PID est relu : une nouvelle instance peut le changer)
    job = readJob(); if (!job) return;                     // job annulé
    if (job.helperPid && job.helperPid !== process.pid && alive(job.helperPid)) return;   // un autre assistant s'en occupe
    if (!alive(job.parentPid)) break;
    if (Date.now() - t0 > 24 * 3600 * 1000) return;
    sleep(700);
  }
  sleep(1500);                                             // laisse Windows libérer les fichiers
  job = readJob(); if (!job) return;
  job.state = 'running'; atomicWrite(jobFile, JSON.stringify(job, null, 1));
  try { fs.writeFileSync(lock, String(Date.now())); } catch {}
  let res;
  try { res = doSwap(job); } catch (e) { res = { ok: false, error: e.message, restored: true }; }
  res.ts = Date.now(); res.version = job.version; res.target = job.target;
  try { atomicWrite(resFile, JSON.stringify(res, null, 1)); } catch {}
  try { fs.unlinkSync(lock); } catch {}
  job = readJob() || job;
  try { fs.unlinkSync(jobFile); } catch {}
  if (job.relaunch) {                                      // relance AI Hub (avec les mêmes options)
    const env = Object.assign({}, process.env); delete env.ELECTRON_RUN_AS_NODE;
    try { const c = cp.spawn(job.exe, job.args || [], { detached: true, stdio: 'ignore', env }); c.unref(); } catch {}
  }
}

module.exports = { doSwap, restore, plan, main };
if (require.main === module && process.argv[2]) { try { main(process.argv[2]); } catch (e) { try { fs.appendFileSync(path.join(path.dirname(process.argv[2]), 'swap-error.log'), String(e && e.stack || e) + '\n'); } catch {} } }
