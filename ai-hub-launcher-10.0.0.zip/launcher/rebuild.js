'use strict';
// rebuild.js : reconstruction du lanceur d'AI Hub.
// Trouve le ZIP du lanceur (à côté / Téléchargements / dépôt GitHub / copie intégrée à la mise à jour), le vérifie
// (empreintes, syntaxe, essai dans un processus séparé), l'installe dans <données>/launcher/<version>/, puis prépare
// le remplacement des fichiers du lanceur dans le dossier d'installation (fait à la fermeture, avec copie de secours).
// Ce fichier est à la fois : (1) intégré dans le noyau de la mise à jour (première reconstruction) et
// (2) livré dans le ZIP (lanceur reconstruit). Il n'utilise pas Electron directement : tout passe par `env`.
const fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process'), crypto = require('crypto'), vm = require('vm');

const VERSION_RE = /^\d+\.\d+\.\d+(-[\w.]+)?$/;
const ZIP_RE = /^ai-hub-launcher-(\d+)[._](\d+)[._](\d+).*\.zip$/i;
const REQUIRED = ['main.js', 'package.json', 'updater.js', 'launcher/boot.js', 'launcher/updater.js', 'launcher/rebuild.js', 'launcher/zip.js', 'launcher/swap.js'];
const isPayloadRel = (r) => r === 'main.js' || r === 'package.json' || r === 'updater.js' || r.startsWith('launcher/');
const MAX_ZIP = 80 * 1048576;
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const nums = (v) => String(v).split(/[.-]/).slice(0, 3).map((n) => parseInt(n, 10) || 0);
const cmp = (a, b) => { const x = nums(a), y = nums(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; };
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };
function atomicWrite(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.' + process.pid + '.tmp'; fs.writeFileSync(tmp, data);
  try { fs.renameSync(tmp, file); } catch (e) { try { fs.writeFileSync(file, data); fs.unlinkSync(tmp); } catch { throw e; } }
}
function syntaxErr(name, code) {
  try { new vm.Script('(function(exports,require,module,__filename,__dirname){' + code + '\n})', { filename: name }); return null; } catch (e) { return name + ' : ' + e.message; }
}

function createRebuilder(env) {
  const zip = env.zip || require('./zip.js');
  const userData = env.userData, L = path.join(userData, 'launcher'), CUR = path.join(L, 'current.json'), LOG = path.join(L, 'rebuild.log'), SW = path.join(L, 'swap');
  const embed = env.embed || null;                       // { version, hashes: { rel: sha256 }, zipB64 }
  const minVersion = env.minVersion || (embed && embed.version) || '0.0.0';
  const gh = Object.assign({ owner: 'XeroxYTB3', repo: 'ai_hub', api: 'https://api.github.com', raw: 'https://raw.githubusercontent.com', page: 'https://github.com' }, env.github || {});
  const mem = [];                                        // dernières lignes du journal (pour l'écran)
  let running = null, lastError = null, lastResult = null;

  const log = (m) => {
    const line = '[' + new Date().toISOString().replace('T', ' ').slice(0, 19) + '] ' + m;
    mem.push(line); if (mem.length > 120) mem.shift();
    try { fs.mkdirSync(L, { recursive: true }); try { if (fs.statSync(LOG).size > 200000) fs.writeFileSync(LOG, mem.join('\n') + '\n'); } catch {} fs.appendFileSync(LOG, line + '\n'); } catch {}
    try { env.emit && env.emit('log', line); } catch {}
  };
  const emit = (type, data) => { try { env.emit && env.emit(type, data); } catch {} };

  // ---------- état du lanceur reconstruit ----------
  function readCurrent() {
    try { const c = JSON.parse(fs.readFileSync(CUR, 'utf8')); if (c && VERSION_RE.test(String(c.version)) && c.files && typeof c.files === 'object') return c; } catch {}
    return null;
  }
  function verifyInstalled(c) {
    if (!c) return false;
    const dir = path.join(L, c.version);
    try { for (const [rel, h] of Object.entries(c.files)) if (sha(fs.readFileSync(path.join(dir, rel))) !== h) return false; return true; } catch { return false; }
  }
  function payloadDir(c) { return path.join(L, (c || readCurrent()).version); }
  // Charge le lanceur reconstruit (après vérification de chaque fichier). null si absent ou abîmé.
  function loadPayload() {
    const c = readCurrent();
    if (!c) return null;
    if (!verifyInstalled(c)) { log('Lanceur reconstruit ' + c.version + ' : fichiers abîmés, ignoré'); return null; }
    try { const m = require(path.join(payloadDir(c), 'launcher', 'boot.js')); return { boot: m, version: c.version, dir: payloadDir(c), current: c }; }
    catch (e) { log('Lanceur reconstruit ' + c.version + ' : chargement impossible (' + e.message + ')'); return null; }
  }

  // ---------- validation d'un ZIP ----------
  function validate(entries, label) {
    const mf = entries.find((e) => e.name === 'manifest.json') || entries.find((e) => /^[^/]+\/manifest\.json$/.test(e.name));
    if (!mf) throw new Error('manifest.json absent (ce n\'est pas le ZIP du lanceur)');
    const prefix = mf.name.slice(0, mf.name.length - 'manifest.json'.length);
    let man; try { man = JSON.parse(mf.data.toString('utf8')); } catch { throw new Error('manifest.json illisible'); }
    if (!man || man.app !== 'ai-hub-launcher' || man.format !== 1) throw new Error('ce ZIP n\'est pas un lanceur AI Hub');
    if (!VERSION_RE.test(String(man.version))) throw new Error('version invalide : ' + man.version);
    if (cmp(man.version, minVersion) < 0) throw new Error('version ' + man.version + ' trop ancienne (' + minVersion + ' ou plus récente requise)');
    if (!man.files || typeof man.files !== 'object') throw new Error('liste de fichiers absente');
    for (const r of REQUIRED) if (!man.files[r]) throw new Error('fichier obligatoire absent du manifeste : ' + r);
    const byName = new Map(entries.map((e) => [e.name, e.data])), files = new Map();
    for (const [rel, h] of Object.entries(man.files)) {
      zip.safeName(rel);
      const d = byName.get(prefix + rel);
      if (!d) throw new Error('fichier manquant dans le ZIP : ' + rel);
      if (sha(d) !== h) throw new Error('empreinte incorrecte (ZIP modifié ou abîmé) : ' + rel);
      if (rel.endsWith('.js')) { const e = syntaxErr(rel, d.toString('utf8')); if (e) throw new Error('erreur de syntaxe — ' + e); }
      files.set(rel, d);
    }
    if (embed && man.version === embed.version)           // même version que celle prévue par la mise à jour : les fichiers doivent être identiques
      for (const [rel, h] of Object.entries(embed.hashes)) if (man.files[rel] !== h) throw new Error('ne correspond pas à cette mise à jour (' + rel + ' différent)');
    return { manifest: man, files, label };
  }

  // ---------- sources ----------
  function localDirs() {
    const out = [path.join(L, 'zip'), L, path.join(userData, 'updates')], g = (n) => { try { return env.app.getPath(n); } catch { return null; } };
    for (const n of ['downloads', 'desktop', 'documents', 'home', 'exe', 'temp']) { const p = g(n); if (p) out.push(n === 'exe' ? path.dirname(p) : p); }
    const h = os.homedir(); for (const s of ['Downloads', 'Téléchargements', 'Desktop', 'Bureau', 'Documents']) out.push(path.join(h, s));
    out.push(...(env.extraDirs || []), process.cwd());
    return [...new Set(out.filter(Boolean).map((d) => path.resolve(d)))];
  }
  function findLocalZips() {
    const found = [];
    for (const d of localDirs()) {
      let names; try { names = fs.readdirSync(d); } catch { continue; }
      const drop = d === path.join(L, 'zip');
      for (const n of names) {
        const m = ZIP_RE.exec(n); if (!m && !(drop && /\.zip$/i.test(n))) continue;
        const f = path.join(d, n); let st; try { st = fs.statSync(f); } catch { continue; }
        if (st.isFile() && st.size > 1000 && st.size <= MAX_ZIP) found.push({ file: f, v: m ? [+m[1], +m[2], +m[3]] : [0, 0, 0], mtime: st.mtimeMs });
      }
    }
    return found.sort((a, b) => cmp(b.v.join('.'), a.v.join('.')) || b.mtime - a.mtime).slice(0, 12);
  }
  async function http(url, ms, asBuf) {
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), ms);
    try {
      const r = await (env.fetch || fetch)(url, { signal: ac.signal, redirect: 'follow', headers: { 'User-Agent': 'AI-Hub-Launcher', Accept: 'application/vnd.github+json, */*' } });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      if (asBuf) { const n = +r.headers.get('content-length') || 0; if (n > MAX_ZIP) throw new Error('fichier trop gros'); const b = Buffer.from(await r.arrayBuffer()); if (b.length > MAX_ZIP) throw new Error('fichier trop gros'); return b; }
      return await r.text();
    } catch (e) { throw new Error(e.name === 'AbortError' ? 'délai dépassé' : e.message); } finally { clearTimeout(to); }
  }
  async function ghLatestZip() {
    let names = [], err = '';
    try { const j = JSON.parse(await http(gh.api + '/repos/' + gh.owner + '/' + gh.repo + '/contents/', 12000)); if (Array.isArray(j)) names = j.filter((f) => f && f.type === 'file').map((f) => f.name); } catch (e) { err = e.message; }
    const pick = (ns) => { let b = null; for (const n of ns) { const m = ZIP_RE.exec(String(n)); if (m && (!b || cmp(m.slice(1, 4).join('.'), b.version) > 0)) b = { name: String(n), version: m.slice(1, 4).join('.') }; } return b; };
    let best = pick(names);
    if (!best) { try { const h = await http(gh.page + '/' + gh.owner + '/' + gh.repo, 12000); best = pick([...new Set(h.match(/ai-hub-launcher-\d+[._]\d+[._]\d+[^"'<>\s]*\.zip/gi) || [])]); } catch (e) { err = err || e.message; } }
    if (!best) throw new Error(err ? 'dépôt injoignable (' + err + ')' : 'aucun ZIP de lanceur dans le dépôt');
    return best;
  }

  // ---------- essai dans un processus séparé ----------
  function selfTest(dir) {
    const code = 'try{const b=require(' + JSON.stringify(path.join(dir, 'launcher', 'boot.js')) + ');process.stdout.write(String(b.selftest()))}catch(e){process.stderr.write(String(e&&e.stack||e));process.exit(3)}';
    try {
      const out = cp.execFileSync(process.execPath, ['-e', code], { env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }), timeout: 25000, windowsHide: true, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
      if (String(out).trim() !== 'ok') throw Object.assign(new Error('résultat inattendu : ' + String(out).slice(0, 80)), { status: 3 });
      return { ok: true };
    } catch (e) {
      if (e.status === 3 || /^Error|SyntaxError|TypeError/.test(String(e.stderr || '').slice(0, 40))) return { ok: false, error: String(e.stderr || e.message).split('\n').slice(0, 3).join(' | ').slice(0, 300) };
      return { ok: true, warn: 'essai séparé impossible (' + (e.code || e.message) + ')' };
    }
  }

  // ---------- installation du lanceur reconstruit (données) ----------
  function installPayload(v, source) {
    const ver = v.manifest.version, tmp = path.join(L, ver + '.tmp'), dst = path.join(L, ver), hashes = {};
    fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
    for (const [rel, data] of v.files) {
      if (!isPayloadRel(rel)) continue;
      const f = path.join(tmp, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, data);
      if (sha(fs.readFileSync(f)) !== sha(data)) throw new Error('écriture incorrecte : ' + rel);
      hashes[rel] = sha(data);
    }
    fs.writeFileSync(path.join(tmp, 'manifest.json'), JSON.stringify(v.manifest, null, 1)); hashes['manifest.json'] = sha(fs.readFileSync(path.join(tmp, 'manifest.json')));
    const st = selfTest(tmp);
    if (!st.ok) { fs.rmSync(tmp, { recursive: true, force: true }); throw new Error('essai du lanceur échoué : ' + st.error); }
    if (st.warn) log('⚠ ' + st.warn);
    const old = readCurrent();
    fs.rmSync(dst, { recursive: true, force: true }); fs.renameSync(tmp, dst);
    atomicWrite(CUR, JSON.stringify({ format: 1, version: ver, files: hashes, source, installedAt: Date.now(), previous: old && old.version !== ver ? old.version : (old && old.previous) || null }, null, 1));
    try {                                                    // ne garde que les 3 dernières versions (et celle d'un remplacement en attente)
      const job = readJob(), keep = new Set([ver, old && old.version, job && job.version].filter(Boolean));
      for (const n of fs.readdirSync(L)) if (VERSION_RE.test(n) && !keep.has(n)) fs.rmSync(path.join(L, n), { recursive: true, force: true });
      for (const n of fs.readdirSync(L)) if (n.endsWith('.tmp')) fs.rmSync(path.join(L, n), { recursive: true, force: true });
    } catch {}
    return readCurrent();
  }

  // ---------- reconstruction complète ----------
  async function doRebuild(opts) {
    log('=== Reconstruction du lanceur (' + (opts.file ? 'ZIP choisi' : opts.auto ? 'automatique' : 'demandée') + ', version minimale ' + minVersion + ') ===');
    emit('start', {});
    let chosen = null; const tried = [];
    const tryBuf = (label, buf) => {
      try { const v = validate(zip.readZip(buf), label); log('✔ ' + label + ' : lanceur ' + v.manifest.version + ' valide'); return v; }
      catch (e) { log('✘ ' + label + ' : ' + e.message); tried.push(label + ' : ' + e.message); return null; }
    };
    if (opts.file) {
      try { chosen = tryBuf(opts.file, fs.readFileSync(opts.file)); } catch (e) { log('✘ ' + opts.file + ' : ' + e.message); tried.push(e.message); }
    } else {
      for (const c of findLocalZips()) { log('ZIP trouvé : ' + c.file); chosen = tryBuf(c.file, fs.readFileSync(c.file)); if (chosen) break; }
      if (!chosen && opts.network !== false) {
        try {
          log('Recherche du ZIP dans github.com/' + gh.owner + '/' + gh.repo + ' …');
          const best = await ghLatestZip();
          if (cmp(best.version, minVersion) < 0) throw new Error('le ZIP du dépôt (' + best.version + ') est plus ancien que ' + minVersion);
          const buf = await http(gh.raw + '/' + gh.owner + '/' + gh.repo + '/HEAD/' + encodeURIComponent(best.name), 90000, true);
          chosen = tryBuf('GitHub : ' + best.name, buf);
        } catch (e) { log('GitHub : ' + e.message); tried.push('GitHub : ' + e.message); }
      }
      if (!chosen && embed) {
        try { chosen = tryBuf('la copie intégrée à la mise à jour', Buffer.from(embed.zipB64, 'base64')); } catch (e) { log('✘ copie intégrée : ' + e.message); tried.push(e.message); }
      }
    }
    if (!chosen) { const err = 'aucun ZIP de lanceur utilisable (' + (tried.slice(-3).join(' ; ') || 'rien trouvé') + ')'; throw new Error(err); }
    const cur = installPayload(chosen, chosen.label);
    log('✔ Lanceur ' + cur.version + ' installé dans ' + payloadDir(cur));
    return { ok: true, version: cur.version, source: chosen.label };
  }
  function rebuild(opts) {
    if (running) return running;
    running = (async () => {
      try { const r = await doRebuild(opts || {}); lastError = null; lastResult = r; emit('done', r); return r; }
      catch (e) { lastError = String(e && e.message || e); log('✘ ' + lastError); const r = { ok: false, error: lastError }; emit('error', r); return r; }
      finally { running = null; }
    })();
    return running;
  }

  // ---------- remplacement des fichiers du lanceur dans le dossier d'installation ----------
  const JOB = () => path.join(SW, 'job.json'), RES = () => path.join(SW, 'result.json'), LOCK = () => path.join(SW, 'lock');
  function readJob() { try { return JSON.parse(fs.readFileSync(JOB(), 'utf8')); } catch { return null; } }
  function readSwapResult() { try { return JSON.parse(fs.readFileSync(RES(), 'utf8')); } catch { return null; } }
  function physicalInfo() {                                // où et dans quel état est le lanceur « physique » (celui de l'exe)
    const app = env.app;
    let appPath = ''; try { appPath = app.getAppPath(); } catch {}
    const bd = env.bundledDir && env.bundledDir(); const base = bd && path.basename(bd) === 'core' ? path.dirname(bd) : appPath;
    const asar = /\.asar$/i.test(base || '');
    const target = asar ? path.join(process.resourcesPath || path.dirname(base), 'app') : base;
    let version = null; try { const p = JSON.parse(fs.readFileSync(path.join(target, 'package.json'), 'utf8')); if (fs.existsSync(path.join(target, 'launcher', 'boot.js'))) version = p.version; } catch {}
    return { target, asar, version, installed: !!app.isPackaged || !!process.env.AIHUB_FORCE_SWAP };
  }
  function canWrite(dir) {                                 // vrai test d'écriture (sur Windows, access() ne suffit pas)
    try { fs.mkdirSync(dir, { recursive: true }); const f = path.join(dir, '.aihub-w' + process.pid + '.tmp'); fs.writeFileSync(f, 'x'); fs.unlinkSync(f); return true; } catch { return false; }
  }
  // Prépare (et lance en attente) le remplacement des fichiers du lanceur de l'exe ; ne bloque jamais, ne casse jamais.
  function stageSwap() {
    try {
      const c = readCurrent(); if (!c || !verifyInstalled(c)) return { state: 'none', detail: 'pas de lanceur reconstruit' };
      const ph = physicalInfo();
      if (!ph.installed) return { state: 'n/a', detail: 'AI Hub est lancé depuis les sources : rien à remplacer' };
      if (ph.asar) return { state: 'impossible', detail: 'l\'installation range son lanceur dans une archive fermée (app.asar), qu\'on ne modifie pas ; il fonctionne exactement de la même façon' };
      const dir = payloadDir(c);
      let same = ph.version === c.version;
      if (same) { try { same = sha(fs.readFileSync(path.join(ph.target, 'main.js'))) === c.files['main.js'] && sha(fs.readFileSync(path.join(ph.target, 'launcher', 'boot.js'))) === c.files['launcher/boot.js']; } catch { same = false; } }
      if (same) { try { fs.rmSync(JOB(), { force: true }); } catch {} return { state: 'ok', version: c.version, detail: 'le lanceur installé est déjà à jour' }; }
      const parent = ph.asar ? (process.resourcesPath || path.dirname(ph.target)) : ph.target;
      if (!canWrite(parent)) return { state: 'impossible', detail: 'dossier protégé en écriture (' + parent + ') : le lanceur reconstruit tourne depuis tes données, sans rien modifier à l\'installation' };
      const act = env.activeCore && env.activeCore();    // { dir, version } du noyau en cours : il devient le noyau d'origine du nouveau lanceur
      if (!act || !act.dir) return { state: 'impossible', detail: 'noyau actif introuvable' };
      const coreFiles = {};
      for (const f of ['main-core.js', 'preload.js', 'webview-preload.js', 'index.html']) { try { coreFiles[f] = sha(fs.readFileSync(path.join(act.dir, f))); } catch { return { state: 'impossible', detail: 'noyau actif incomplet : ' + f }; } }
      const old = readJob();
      if (old && old.state === 'running' && old.helperPid && alive(old.helperPid)) return { state: 'running', detail: 'remplacement en cours' };   // (un assistant mort en plein travail ne bloque pas la suite)
      const job = { v: 1, version: c.version, parentPid: process.pid, exe: process.execPath, args: process.argv.slice(1), target: ph.target, asar: ph.asar, stage: dir,
        files: Object.fromEntries(Object.entries(c.files).filter(([r]) => isPayloadRel(r))), coreSrc: act.dir, coreFiles, coreVersion: act.version, userData, relaunch: false, state: 'waiting', createdAt: Date.now() };
      fs.mkdirSync(SW, { recursive: true });
      if (old && old.helperPid && alive(old.helperPid) && old.state === 'waiting') {   // un assistant attend déjà : il attendra cette instance-ci
        job.helperPid = old.helperPid; atomicWrite(JOB(), JSON.stringify(job, null, 1)); log('Remplacement du lanceur déjà en attente (assistant ' + old.helperPid + ')');
        return { state: 'pending', version: c.version, detail: 'sera fait à la fermeture d\'AI Hub' };
      }
      atomicWrite(JOB(), JSON.stringify(job, null, 1));
      const swapJs = path.join(dir, 'launcher', 'swap.js');
      const child = cp.spawn(process.execPath, [swapJs, JOB()], { detached: true, stdio: 'ignore', windowsHide: true, env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }) });
      child.on('error', (e) => log('⚠ assistant de remplacement : ' + e.message)); child.unref();
      job.helperPid = child.pid; atomicWrite(JOB(), JSON.stringify(Object.assign(readJob() || job, { helperPid: child.pid }), null, 1));
      log('Remplacement du lanceur de l\'exe préparé (' + ph.target + ') : il sera fait à la fermeture d\'AI Hub');
      return { state: 'pending', version: c.version, detail: 'sera fait à la fermeture d\'AI Hub' };
    } catch (e) { log('⚠ remplacement du lanceur non préparé : ' + e.message); return { state: 'failed', detail: e.message }; }
  }
  // Demande à l'assistant de relancer AI Hub après le remplacement (utilisé quand on redémarre avec un remplacement en attente)
  function relaunchViaSwap() {
    const j = readJob(); if (!j || j.state !== 'waiting' || !j.helperPid || !alive(j.helperPid)) return false;
    j.relaunch = true; atomicWrite(JOB(), JSON.stringify(j, null, 1)); return true;
  }

  function status() {
    const c = readCurrent(), job = readJob(), res = readSwapResult(), ph = (() => { try { return physicalInfo(); } catch { return {}; } })();
    return { expected: minVersion, payload: c ? { version: c.version, source: c.source, installedAt: c.installedAt, ok: verifyInstalled(c) } : null,
      rebuilding: !!running, lastError, lastResult,
      swap: job ? { state: job.state, version: job.version, target: job.target } : null, swapResult: res,
      physical: { target: ph.target || null, version: ph.version || null, asar: !!ph.asar }, log: mem.slice(-60) };
  }
  function tailLog(n) { try { return fs.readFileSync(LOG, 'utf8').split('\n').filter(Boolean).slice(-(n || 60)); } catch { return mem.slice(); } }

  return { rebuild, loadPayload, readCurrent, verifyInstalled, stageSwap, relaunchViaSwap, status, tailLog, findLocalZips, localDirs, readJob, readSwapResult, physicalInfo, minVersion, log, isRunning: () => !!running };
}

module.exports = { createRebuilder, ZIP_RE, REQUIRED, isPayloadRel, cmp, sha };
