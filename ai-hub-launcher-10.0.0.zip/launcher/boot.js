'use strict';
// boot.js : cœur du lanceur 10. Utilisé de deux façons :
//   - physique : main.js (dans le dossier d'installation) l'appelle au démarrage, avant le noyau ;
//   - virtuel  : un noyau de mise à jour (chargé par un ANCIEN lanceur) l'appelle pour remplacer, en mémoire, le système
//                de mise à jour de l'ancien lanceur par celui-ci. Même comportement, même format de données.
// Ce fichier ne charge pas Electron lui-même (`app` est fourni par l'appelant) : il peut être essayé en Node pur.
const fs = require('fs'), path = require('path'), os = require('os');
const { createUpdater, buildPackage, CORE_FILES } = require('./updater.js');
const zip = require('./zip.js');

let VERSION = '0.0.0';
try { VERSION = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8')).version; } catch {}

// Relance / échec : mêmes gestes que l'ancien lanceur, mais un remplacement du lanceur en attente est honoré
function makeControls(ctx, app) {
  ctx.relaunch = () => {
    try { if (ctx.rebuilder && ctx.rebuilder.relaunchViaSwap && ctx.rebuilder.relaunchViaSwap()) { app.exit(0); return; } } catch {}
    app.relaunch(); app.exit(0);
  };
  // Échec pendant l'essai d'une nouvelle version : retour arrière puis relance. Faux si rien à annuler.
  ctx.fatal = (reason) => { try { if (ctx.updater.fail(reason)) { ctx.relaunch(); return true; } } catch {} return false; };
  return ctx;
}

// Lanceur « physique » : choisit le code à lancer, revient en arrière tout seul si une mise à jour ne démarre pas.
function createContext({ app, appDir, launcherDir }) {
  const userData = app.getPath('userData'), bundledDir = path.join(appDir, 'core');
  const updater = createUpdater({ root: path.join(userData, 'updates'), bundledDir, launcherVersion: VERSION });
  let boot;
  try { boot = updater.prepare(); }
  catch (e) { boot = { version: 'bundled', dir: bundledDir, rolledBack: 'erreur du système de mise à jour : ' + e.message }; }
  const ctx = { updater, boot, bundledDir, launcherVersion: VERSION, launcher: { version: VERSION, mode: 'physique', dir: launcherDir || __dirname } };
  makeControls(ctx, app);
  process.on('uncaughtException', (e) => { if (!ctx.fatal('exception : ' + (e && e.message))) console.error(e); });
  return ctx;
}

// Lanceur « virtuel » : remplace dans ctx (déjà préparé par l'ancien lanceur) le système de mise à jour et les gestes de relance.
function upgradeContext(ctx, { app, dir }) {
  const userData = app.getPath('userData'), exeVersion = ctx.launcherVersion;
  const bundledDir = ctx.bundledDir || path.join(app.getAppPath(), 'core');
  ctx.updater = createUpdater({ root: path.join(userData, 'updates'), bundledDir, launcherVersion: VERSION, bundledVersion: exeVersion });
  ctx.launcher = { version: VERSION, mode: 'virtuel', dir: dir || __dirname, exeVersion };
  makeControls(ctx, app);
  return ctx;
}

// Essai de bon fonctionnement, sans Electron et sans toucher aux vraies données : appelé dans un processus séparé
// avant toute installation du lanceur (et par l'assistant de remplacement après).
function selftest() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'aihub-selftest-'));
  try {
    const core = path.join(tmp, 'core'); fs.mkdirSync(core);
    const body = { 'main-core.js': 'module.exports=function(){}', 'preload.js': '// p', 'webview-preload.js': '// w', 'index.html': '<html><script>var a=1</script></html>' };
    for (const f of CORE_FILES) fs.writeFileSync(path.join(core, f), body[f]);
    const u = createUpdater({ root: path.join(tmp, 'updates'), bundledDir: core, launcherVersion: VERSION });
    if (u.prepare().version !== 'bundled') throw new Error('démarrage');
    const r = u.install(buildPackage({ dir: core, version: '99.0.0', notes: 'essai' }));
    if (!r.ok || u.info().current !== '99.0.0') throw new Error('installation : ' + (r.error || ''));
    if (u.prepare().version !== '99.0.0' || !u.confirm()) throw new Error('confirmation');
    if (u.revert('bundled').version !== 'bundled') throw new Error('retour arrière');
    const z = zip.readZip(zip.makeZip([{ name: 'a/b.txt', data: Buffer.from('ok') }]));
    if (z.length !== 1 || z[0].data.toString() !== 'ok') throw new Error('zip');
    for (const m of ['./rebuild.js', './swap.js']) require(m);
    return 'ok';
  } finally { try { fs.rmSync(tmp, { recursive: true, force: true }); } catch {} }
}

module.exports = { VERSION, createContext, upgradeContext, makeControls, selftest, createUpdater, buildPackage };
