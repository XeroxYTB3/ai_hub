/*
 * ⚠ RÈGLE N°1 — MISE À JOUR UNIVERSELLE (à lire AVANT toute modification de ce fichier)
 * Cette mise à jour doit TOUJOURS être compatible, PEU IMPORTE la version actuellement installée :
 * version d'origine de l'exe, ancienne, récente, ou même plus récente que celle-ci. N'importe qui doit
 * pouvoir l'installer, depuis n'importe quelle version, sans rien perdre (comptes, scripts, réglages).
 * Pour cela, TOUJOURS :
 *  1. Livrer un paquet COMPLET : les 4 fichiers (main-core.js, preload.js, webview-preload.js, index.html), jamais un paquet partiel.
 *  2. requiresLauncher = null. Ne rien supposer du lanceur (voir normalizeCtx dans main-core.js) et ne jamais exiger un lanceur plus récent.
 *  3. Garder les 4 fichiers cohérents entre eux (preload.js <-> main-core.js <-> index.html).
 *  4. Savoir lire les données écrites par N'IMPORTE QUELLE version : champ absent = valeur par défaut ; ne jamais supprimer ni réécrire un champ inconnu.
 *  5. Ne rien écrire qu'une version plus ancienne ne puisse relire (le retour arrière doit toujours marcher).
 *  6. Numéro de version strictement supérieur au précédent ; un numéro déjà publié n'est jamais réutilisé.
 */
const { app, BrowserWindow, ipcMain, session, clipboard, dialog, Notification, shell, nativeTheme, screen } = require('electron');   // 10.0.0 : lanceur reconstruit depuis le ZIP (voir <LANCEUR>)
const path = require('path'), fs = require('fs'), crypto = require('crypto');
const { pathToFileURL } = require('url');

// UNIVERSEL : ce noyau doit démarrer avec N'IMPORTE QUEL lanceur (ancien, incomplet...). On complète tout ce qui manque.
function normalizeCtx(c) {
  c = c || {};
  const lost = 'Ce lanceur ne gère pas les mises à jour : réinstalle AI Hub avec le dernier installeur.';
  const stub = {
    info: () => ({ launcherVersion: app.getVersion(), current: 'bundled', previous: 'bundled', pending: null, bad: [], history: [], versions: [] }),
    install: () => ({ ok: false, error: lost }), revert: () => ({ ok: false, error: lost }),
    confirm: () => false, fail: () => false, readPackage: () => { throw new Error(lost); }
  };
  return Object.assign({}, c, {
    updater: c.updater || stub,
    boot: c.boot || { version: 'bundled', dir: __dirname, rolledBack: null },
    launcherVersion: c.launcherVersion || app.getVersion(),
    relaunch: typeof c.relaunch === 'function' ? c.relaunch : () => { app.relaunch(); app.exit(0); },
    fatal: typeof c.fatal === 'function' ? c.fatal : () => false
  });
}

// <LANCEUR>
// 10.0.0 — LANCEUR : le noyau sait reconstruire le lanceur d'AI Hub à partir du ZIP (ai-hub-launcher-10.0.0.zip),
// de GitHub ou de sa copie intégrée, sans aucune action manuelle. Voir launcher/rebuild.js (même code, intégré ici
// pour que la toute première reconstruction marche avec N'IMPORTE QUEL ancien lanceur).
const LZIP = (function () { const module = { exports: {} };
// zip.js : lecture et écriture de fichiers ZIP, sans aucune dépendance (zlib + Buffer).
// Lecture sûre : pas de chemin absolu, pas de « .. », pas de ZIP64, limites de taille, CRC vérifié.
const zlib = require('zlib');

const LIM = { files: 3000, entry: 120 * 1048576, total: 400 * 1048576 };
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC_T[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };

function safeName(n) {
  n = String(n).replace(/\\/g, '/');
  if (!n || n.includes('\0') || n.startsWith('/') || /^[a-zA-Z]:/.test(n)) throw new Error('chemin refusé dans le ZIP : ' + n);
  if (n.split('/').some((s) => s === '..')) throw new Error('chemin refusé dans le ZIP (..) : ' + n);
  return n;
}

// Retourne [{ name, data: Buffer }] (les dossiers sont ignorés)
function readZip(buf, limits) {
  const lim = Object.assign({}, LIM, limits || {});
  if (!Buffer.isBuffer(buf) || buf.length < 22) throw new Error('ce n\'est pas un fichier ZIP');
  let eocd = -1;
  for (let i = buf.length - 22, stop = Math.max(0, buf.length - 22 - 65535); i >= stop; i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('ce n\'est pas un fichier ZIP (fin de fichier introuvable)');
  const count = buf.readUInt16LE(eocd + 10), cdSize = buf.readUInt32LE(eocd + 12), cdOff = buf.readUInt32LE(eocd + 16);
  if (count === 0xFFFF || cdOff === 0xFFFFFFFF || cdSize === 0xFFFFFFFF) throw new Error('ZIP64 non géré');
  if (count > lim.files) throw new Error('trop de fichiers dans le ZIP (' + count + ')');
  if (cdOff + cdSize > buf.length) throw new Error('ZIP tronqué ou corrompu');
  const out = []; let p = cdOff, total = 0;
  for (let k = 0; k < count; k++) {
    if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw new Error('ZIP corrompu (répertoire central)');
    const flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16);
    const csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
    const nl = buf.readUInt16LE(p + 28), el = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32), lo = buf.readUInt32LE(p + 42);
    const rawName = buf.toString('utf8', p + 46, p + 46 + nl); p += 46 + nl + el + cl;
    if (rawName.endsWith('/')) continue;                                  // dossier
    const name = safeName(rawName);
    if (flags & 1) throw new Error('ZIP chiffré non géré : ' + name);
    if (csize === 0xFFFFFFFF || usize === 0xFFFFFFFF) throw new Error('ZIP64 non géré : ' + name);
    if (usize > lim.entry) throw new Error('fichier trop gros dans le ZIP : ' + name);
    total += usize; if (total > lim.total) throw new Error('ZIP trop gros une fois décompressé');
    if (lo + 30 > buf.length || buf.readUInt32LE(lo) !== 0x04034b50) throw new Error('ZIP corrompu (en-tête local) : ' + name);
    const start = lo + 30 + buf.readUInt16LE(lo + 26) + buf.readUInt16LE(lo + 28);
    if (start + csize > buf.length) throw new Error('ZIP tronqué : ' + name);
    const raw = buf.subarray(start, start + csize);
    let data;
    if (method === 0) data = Buffer.from(raw);
    else if (method === 8) data = zlib.inflateRawSync(raw, { maxOutputLength: lim.entry + 1 });
    else throw new Error('méthode de compression non gérée (' + method + ') : ' + name);
    if (data.length !== usize) throw new Error('taille incorrecte : ' + name);
    if (crc32(data) !== crc) throw new Error('somme de contrôle incorrecte (ZIP corrompu) : ' + name);
    out.push({ name, data });
  }
  return out;
}

// entries : [{ name, data: Buffer, mtime?: Date }]
function makeZip(entries) {
  const locals = [], central = []; let off = 0;
  for (const e of entries) {
    const name = Buffer.from(safeName(e.name), 'utf8'), raw = Buffer.isBuffer(e.data) ? e.data : Buffer.from(e.data);
    const def = zlib.deflateRawSync(raw, { level: 9 }), useDef = def.length < raw.length, body = useDef ? def : raw, method = useDef ? 8 : 0;
    const crc = crc32(raw), d = e.mtime || new Date(Date.UTC(2026, 9, 14, 12, 0, 0));
    const time = (d.getUTCHours() << 11) | (d.getUTCMinutes() << 5) | (d.getUTCSeconds() >> 1);
    const date = (((d.getUTCFullYear() - 1980) & 127) << 9) | ((d.getUTCMonth() + 1) << 5) | d.getUTCDate();
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(method, 8);
    lh.writeUInt16LE(time, 10); lh.writeUInt16LE(date, 12); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(name.length, 26);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(method, 10);
    ch.writeUInt16LE(time, 12); ch.writeUInt16LE(date, 14); ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(body.length, 20); ch.writeUInt32LE(raw.length, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(off, 42);
    locals.push(lh, name, body); central.push(ch, name); off += 30 + name.length + body.length;
  }
  const cd = Buffer.concat(central), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...locals, cd, end]);
}

module.exports = { readZip, makeZip, crc32, safeName };

return module.exports; })();
const LREBUILD = (function () { const module = { exports: {} };
// rebuild.js : reconstruction du lanceur d'AI Hub.
// Trouve le ZIP du lanceur (à côté / Téléchargements / dépôt GitHub / copie intégrée à la mise à jour), le vérifie
// (empreintes, syntaxe, essai dans un processus séparé), l'installe dans <données>/launcher/<version>/, puis prépare
// le remplacement des fichiers du lanceur dans le dossier d'installation (fait à la fermeture, avec copie de secours).
// Ce fichier est à la fois : (1) intégré dans le noyau de la mise à jour (première reconstruction) et
// (2) livré dans le ZIP (lanceur reconstruit). Il n'utilise pas Electron directement : tout passe par `env`.
const fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process'), crypto = require('crypto'), vm = require('vm');

const VERSION_RE = /^\d+\.\d+\.\d+(-[\w.]+)?$/;
const ZIP_RE = /^ai-hub-launcher-(\d+)[._](\d+)[._](\d+).*\.zip$/i;
const REQUIRED = ['main.js', 'package.json', 'updater.js', 'launcher/boot.js', 'launcher/updater.js', 'launcher/rebuild.js', 'launcher/zip.js', 'launcher/swap.js'];
const isPayloadRel = (r) => r === 'main.js' || r === 'package.json' || r === 'updater.js' || r.startsWith('launcher/');
const MAX_ZIP = 80 * 1048576;
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
const nums = (v) => String(v).split(/[.-]/).slice(0, 3).map((n) => parseInt(n, 10) || 0);
const cmp = (a, b) => { const x = nums(a), y = nums(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); return 0; };
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };
function atomicWrite(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.' + process.pid + '.tmp'; fs.writeFileSync(tmp, data);
  try { fs.renameSync(tmp, file); } catch (e) { try { fs.writeFileSync(file, data); fs.unlinkSync(tmp); } catch { throw e; } }
}
function syntaxErr(name, code) {
  try { new vm.Script('(function(exports,require,module,__filename,__dirname){' + code + '\n})', { filename: name }); return null; } catch (e) { return name + ' : ' + e.message; }
}

function createRebuilder(env) {
  const zip = env.zip || require('./zip.js');
  const userData = env.userData, L = path.join(userData, 'launcher'), CUR = path.join(L, 'current.json'), LOG = path.join(L, 'rebuild.log'), SW = path.join(L, 'swap');
  const embed = env.embed || null;                       // { version, hashes: { rel: sha256 }, zipB64 }
  const minVersion = env.minVersion || (embed && embed.version) || '0.0.0';
  const gh = Object.assign({ owner: 'XeroxYTB3', repo: 'ai_hub', api: 'https://api.github.com', raw: 'https://raw.githubusercontent.com', page: 'https://github.com' }, env.github || {});
  const mem = [];                                        // dernières lignes du journal (pour l'écran)
  let running = null, lastError = null, lastResult = null;

  const log = (m) => {
    const line = '[' + new Date().toISOString().replace('T', ' ').slice(0, 19) + '] ' + m;
    mem.push(line); if (mem.length > 120) mem.shift();
    try { fs.mkdirSync(L, { recursive: true }); try { if (fs.statSync(LOG).size > 200000) fs.writeFileSync(LOG, mem.join('\n') + '\n'); } catch {} fs.appendFileSync(LOG, line + '\n'); } catch {}
    try { env.emit && env.emit('log', line); } catch {}
  };
  const emit = (type, data) => { try { env.emit && env.emit(type, data); } catch {} };

  // ---------- état du lanceur reconstruit ----------
  function readCurrent() {
    try { const c = JSON.parse(fs.readFileSync(CUR, 'utf8')); if (c && VERSION_RE.test(String(c.version)) && c.files && typeof c.files === 'object') return c; } catch {}
    return null;
  }
  function verifyInstalled(c) {
    if (!c) return false;
    const dir = path.join(L, c.version);
    try { for (const [rel, h] of Object.entries(c.files)) if (sha(fs.readFileSync(path.join(dir, rel))) !== h) return false; return true; } catch { return false; }
  }
  function payloadDir(c) { return path.join(L, (c || readCurrent()).version); }
  // Charge le lanceur reconstruit (après vérification de chaque fichier). null si absent ou abîmé.
  function loadPayload() {
    const c = readCurrent();
    if (!c) return null;
    if (!verifyInstalled(c)) { log('Lanceur reconstruit ' + c.version + ' : fichiers abîmés, ignoré'); return null; }
    try { const m = require(path.join(payloadDir(c), 'launcher', 'boot.js')); return { boot: m, version: c.version, dir: payloadDir(c), current: c }; }
    catch (e) { log('Lanceur reconstruit ' + c.version + ' : chargement impossible (' + e.message + ')'); return null; }
  }

  // ---------- validation d'un ZIP ----------
  function validate(entries, label) {
    const mf = entries.find((e) => e.name === 'manifest.json') || entries.find((e) => /^[^/]+\/manifest\.json$/.test(e.name));
    if (!mf) throw new Error('manifest.json absent (ce n\'est pas le ZIP du lanceur)');
    const prefix = mf.name.slice(0, mf.name.length - 'manifest.json'.length);
    let man; try { man = JSON.parse(mf.data.toString('utf8')); } catch { throw new Error('manifest.json illisible'); }
    if (!man || man.app !== 'ai-hub-launcher' || man.format !== 1) throw new Error('ce ZIP n\'est pas un lanceur AI Hub');
    if (!VERSION_RE.test(String(man.version))) throw new Error('version invalide : ' + man.version);
    if (cmp(man.version, minVersion) < 0) throw new Error('version ' + man.version + ' trop ancienne (' + minVersion + ' ou plus récente requise)');
    if (!man.files || typeof man.files !== 'object') throw new Error('liste de fichiers absente');
    for (const r of REQUIRED) if (!man.files[r]) throw new Error('fichier obligatoire absent du manifeste : ' + r);
    const byName = new Map(entries.map((e) => [e.name, e.data])), files = new Map();
    for (const [rel, h] of Object.entries(man.files)) {
      zip.safeName(rel);
      const d = byName.get(prefix + rel);
      if (!d) throw new Error('fichier manquant dans le ZIP : ' + rel);
      if (sha(d) !== h) throw new Error('empreinte incorrecte (ZIP modifié ou abîmé) : ' + rel);
      if (rel.endsWith('.js')) { const e = syntaxErr(rel, d.toString('utf8')); if (e) throw new Error('erreur de syntaxe — ' + e); }
      files.set(rel, d);
    }
    if (embed && man.version === embed.version)           // même version que celle prévue par la mise à jour : les fichiers doivent être identiques
      for (const [rel, h] of Object.entries(embed.hashes)) if (man.files[rel] !== h) throw new Error('ne correspond pas à cette mise à jour (' + rel + ' différent)');
    return { manifest: man, files, label };
  }

  // ---------- sources ----------
  function localDirs() {
    const out = [path.join(L, 'zip'), L, path.join(userData, 'updates')], g = (n) => { try { return env.app.getPath(n); } catch { return null; } };
    for (const n of ['downloads', 'desktop', 'documents', 'home', 'exe', 'temp']) { const p = g(n); if (p) out.push(n === 'exe' ? path.dirname(p) : p); }
    const h = os.homedir(); for (const s of ['Downloads', 'Téléchargements', 'Desktop', 'Bureau', 'Documents']) out.push(path.join(h, s));
    out.push(...(env.extraDirs || []), process.cwd());
    return [...new Set(out.filter(Boolean).map((d) => path.resolve(d)))];
  }
  function findLocalZips() {
    const found = [];
    for (const d of localDirs()) {
      let names; try { names = fs.readdirSync(d); } catch { continue; }
      const drop = d === path.join(L, 'zip');
      for (const n of names) {
        const m = ZIP_RE.exec(n); if (!m && !(drop && /\.zip$/i.test(n))) continue;
        const f = path.join(d, n); let st; try { st = fs.statSync(f); } catch { continue; }
        if (st.isFile() && st.size > 1000 && st.size <= MAX_ZIP) found.push({ file: f, v: m ? [+m[1], +m[2], +m[3]] : [0, 0, 0], mtime: st.mtimeMs });
      }
    }
    return found.sort((a, b) => cmp(b.v.join('.'), a.v.join('.')) || b.mtime - a.mtime).slice(0, 12);
  }
  async function http(url, ms, asBuf) {
    const ac = new AbortController(), to = setTimeout(() => ac.abort(), ms);
    try {
      const r = await (env.fetch || fetch)(url, { signal: ac.signal, redirect: 'follow', headers: { 'User-Agent': 'AI-Hub-Launcher', Accept: 'application/vnd.github+json, */*' } });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      if (asBuf) { const n = +r.headers.get('content-length') || 0; if (n > MAX_ZIP) throw new Error('fichier trop gros'); const b = Buffer.from(await r.arrayBuffer()); if (b.length > MAX_ZIP) throw new Error('fichier trop gros'); return b; }
      return await r.text();
    } catch (e) { throw new Error(e.name === 'AbortError' ? 'délai dépassé' : e.message); } finally { clearTimeout(to); }
  }
  async function ghLatestZip() {
    let names = [], err = '';
    try { const j = JSON.parse(await http(gh.api + '/repos/' + gh.owner + '/' + gh.repo + '/contents/', 12000)); if (Array.isArray(j)) names = j.filter((f) => f && f.type === 'file').map((f) => f.name); } catch (e) { err = e.message; }
    const pick = (ns) => { let b = null; for (const n of ns) { const m = ZIP_RE.exec(String(n)); if (m && (!b || cmp(m.slice(1, 4).join('.'), b.version) > 0)) b = { name: String(n), version: m.slice(1, 4).join('.') }; } return b; };
    let best = pick(names);
    if (!best) { try { const h = await http(gh.page + '/' + gh.owner + '/' + gh.repo, 12000); best = pick([...new Set(h.match(/ai-hub-launcher-\d+[._]\d+[._]\d+[^"'<>\s]*\.zip/gi) || [])]); } catch (e) { err = err || e.message; } }
    if (!best) throw new Error(err ? 'dépôt injoignable (' + err + ')' : 'aucun ZIP de lanceur dans le dépôt');
    return best;
  }

  // ---------- essai dans un processus séparé ----------
  function selfTest(dir) {
    const code = 'try{const b=require(' + JSON.stringify(path.join(dir, 'launcher', 'boot.js')) + ');process.stdout.write(String(b.selftest()))}catch(e){process.stderr.write(String(e&&e.stack||e));process.exit(3)}';
    try {
      const out = cp.execFileSync(process.execPath, ['-e', code], { env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }), timeout: 25000, windowsHide: true, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
      if (String(out).trim() !== 'ok') throw Object.assign(new Error('résultat inattendu : ' + String(out).slice(0, 80)), { status: 3 });
      return { ok: true };
    } catch (e) {
      if (e.status === 3 || /^Error|SyntaxError|TypeError/.test(String(e.stderr || '').slice(0, 40))) return { ok: false, error: String(e.stderr || e.message).split('\n').slice(0, 3).join(' | ').slice(0, 300) };
      return { ok: true, warn: 'essai séparé impossible (' + (e.code || e.message) + ')' };
    }
  }

  // ---------- installation du lanceur reconstruit (données) ----------
  function installPayload(v, source) {
    const ver = v.manifest.version, tmp = path.join(L, ver + '.tmp'), dst = path.join(L, ver), hashes = {};
    fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
    for (const [rel, data] of v.files) {
      if (!isPayloadRel(rel)) continue;
      const f = path.join(tmp, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, data);
      if (sha(fs.readFileSync(f)) !== sha(data)) throw new Error('écriture incorrecte : ' + rel);
      hashes[rel] = sha(data);
    }
    fs.writeFileSync(path.join(tmp, 'manifest.json'), JSON.stringify(v.manifest, null, 1)); hashes['manifest.json'] = sha(fs.readFileSync(path.join(tmp, 'manifest.json')));
    const st = selfTest(tmp);
    if (!st.ok) { fs.rmSync(tmp, { recursive: true, force: true }); throw new Error('essai du lanceur échoué : ' + st.error); }
    if (st.warn) log('⚠ ' + st.warn);
    const old = readCurrent();
    fs.rmSync(dst, { recursive: true, force: true }); fs.renameSync(tmp, dst);
    atomicWrite(CUR, JSON.stringify({ format: 1, version: ver, files: hashes, source, installedAt: Date.now(), previous: old && old.version !== ver ? old.version : (old && old.previous) || null }, null, 1));
    try {                                                    // ne garde que les 3 dernières versions (et celle d'un remplacement en attente)
      const job = readJob(), keep = new Set([ver, old && old.version, job && job.version].filter(Boolean));
      for (const n of fs.readdirSync(L)) if (VERSION_RE.test(n) && !keep.has(n)) fs.rmSync(path.join(L, n), { recursive: true, force: true });
      for (const n of fs.readdirSync(L)) if (n.endsWith('.tmp')) fs.rmSync(path.join(L, n), { recursive: true, force: true });
    } catch {}
    return readCurrent();
  }

  // ---------- reconstruction complète ----------
  async function doRebuild(opts) {
    log('=== Reconstruction du lanceur (' + (opts.file ? 'ZIP choisi' : opts.auto ? 'automatique' : 'demandée') + ', version minimale ' + minVersion + ') ===');
    emit('start', {});
    let chosen = null; const tried = [];
    const tryBuf = (label, buf) => {
      try { const v = validate(zip.readZip(buf), label); log('✔ ' + label + ' : lanceur ' + v.manifest.version + ' valide'); return v; }
      catch (e) { log('✘ ' + label + ' : ' + e.message); tried.push(label + ' : ' + e.message); return null; }
    };
    if (opts.file) {
      try { chosen = tryBuf(opts.file, fs.readFileSync(opts.file)); } catch (e) { log('✘ ' + opts.file + ' : ' + e.message); tried.push(e.message); }
    } else {
      for (const c of findLocalZips()) { log('ZIP trouvé : ' + c.file); chosen = tryBuf(c.file, fs.readFileSync(c.file)); if (chosen) break; }
      if (!chosen && opts.network !== false) {
        try {
          log('Recherche du ZIP dans github.com/' + gh.owner + '/' + gh.repo + ' …');
          const best = await ghLatestZip();
          if (cmp(best.version, minVersion) < 0) throw new Error('le ZIP du dépôt (' + best.version + ') est plus ancien que ' + minVersion);
          const buf = await http(gh.raw + '/' + gh.owner + '/' + gh.repo + '/HEAD/' + encodeURIComponent(best.name), 90000, true);
          chosen = tryBuf('GitHub : ' + best.name, buf);
        } catch (e) { log('GitHub : ' + e.message); tried.push('GitHub : ' + e.message); }
      }
      if (!chosen && embed) {
        try { chosen = tryBuf('la copie intégrée à la mise à jour', Buffer.from(embed.zipB64, 'base64')); } catch (e) { log('✘ copie intégrée : ' + e.message); tried.push(e.message); }
      }
    }
    if (!chosen) { const err = 'aucun ZIP de lanceur utilisable (' + (tried.slice(-3).join(' ; ') || 'rien trouvé') + ')'; throw new Error(err); }
    const cur = installPayload(chosen, chosen.label);
    log('✔ Lanceur ' + cur.version + ' installé dans ' + payloadDir(cur));
    return { ok: true, version: cur.version, source: chosen.label };
  }
  function rebuild(opts) {
    if (running) return running;
    running = (async () => {
      try { const r = await doRebuild(opts || {}); lastError = null; lastResult = r; emit('done', r); return r; }
      catch (e) { lastError = String(e && e.message || e); log('✘ ' + lastError); const r = { ok: false, error: lastError }; emit('error', r); return r; }
      finally { running = null; }
    })();
    return running;
  }

  // ---------- remplacement des fichiers du lanceur dans le dossier d'installation ----------
  const JOB = () => path.join(SW, 'job.json'), RES = () => path.join(SW, 'result.json'), LOCK = () => path.join(SW, 'lock');
  function readJob() { try { return JSON.parse(fs.readFileSync(JOB(), 'utf8')); } catch { return null; } }
  function readSwapResult() { try { return JSON.parse(fs.readFileSync(RES(), 'utf8')); } catch { return null; } }
  function physicalInfo() {                                // où et dans quel état est le lanceur « physique » (celui de l'exe)
    const app = env.app;
    let appPath = ''; try { appPath = app.getAppPath(); } catch {}
    const bd = env.bundledDir && env.bundledDir(); const base = bd && path.basename(bd) === 'core' ? path.dirname(bd) : appPath;
    const asar = /\.asar$/i.test(base || '');
    const target = asar ? path.join(process.resourcesPath || path.dirname(base), 'app') : base;
    let version = null; try { const p = JSON.parse(fs.readFileSync(path.join(target, 'package.json'), 'utf8')); if (fs.existsSync(path.join(target, 'launcher', 'boot.js'))) version = p.version; } catch {}
    return { target, asar, version, installed: !!app.isPackaged || !!process.env.AIHUB_FORCE_SWAP };
  }
  function canWrite(dir) {                                 // vrai test d'écriture (sur Windows, access() ne suffit pas)
    try { fs.mkdirSync(dir, { recursive: true }); const f = path.join(dir, '.aihub-w' + process.pid + '.tmp'); fs.writeFileSync(f, 'x'); fs.unlinkSync(f); return true; } catch { return false; }
  }
  // Prépare (et lance en attente) le remplacement des fichiers du lanceur de l'exe ; ne bloque jamais, ne casse jamais.
  function stageSwap() {
    try {
      const c = readCurrent(); if (!c || !verifyInstalled(c)) return { state: 'none', detail: 'pas de lanceur reconstruit' };
      const ph = physicalInfo();
      if (!ph.installed) return { state: 'n/a', detail: 'AI Hub est lancé depuis les sources : rien à remplacer' };
      if (ph.asar) return { state: 'impossible', detail: 'l\'installation range son lanceur dans une archive fermée (app.asar), qu\'on ne modifie pas ; il fonctionne exactement de la même façon' };
      const dir = payloadDir(c);
      let same = ph.version === c.version;
      if (same) { try { same = sha(fs.readFileSync(path.join(ph.target, 'main.js'))) === c.files['main.js'] && sha(fs.readFileSync(path.join(ph.target, 'launcher', 'boot.js'))) === c.files['launcher/boot.js']; } catch { same = false; } }
      if (same) { try { fs.rmSync(JOB(), { force: true }); } catch {} return { state: 'ok', version: c.version, detail: 'le lanceur installé est déjà à jour' }; }
      const parent = ph.asar ? (process.resourcesPath || path.dirname(ph.target)) : ph.target;
      if (!canWrite(parent)) return { state: 'impossible', detail: 'dossier protégé en écriture (' + parent + ') : le lanceur reconstruit tourne depuis tes données, sans rien modifier à l\'installation' };
      const act = env.activeCore && env.activeCore();    // { dir, version } du noyau en cours : il devient le noyau d'origine du nouveau lanceur
      if (!act || !act.dir) return { state: 'impossible', detail: 'noyau actif introuvable' };
      const coreFiles = {};
      for (const f of ['main-core.js', 'preload.js', 'webview-preload.js', 'index.html']) { try { coreFiles[f] = sha(fs.readFileSync(path.join(act.dir, f))); } catch { return { state: 'impossible', detail: 'noyau actif incomplet : ' + f }; } }
      const old = readJob();
      if (old && old.state === 'running' && old.helperPid && alive(old.helperPid)) return { state: 'running', detail: 'remplacement en cours' };   // (un assistant mort en plein travail ne bloque pas la suite)
      const job = { v: 1, version: c.version, parentPid: process.pid, exe: process.execPath, args: process.argv.slice(1), target: ph.target, asar: ph.asar, stage: dir,
        files: Object.fromEntries(Object.entries(c.files).filter(([r]) => isPayloadRel(r))), coreSrc: act.dir, coreFiles, coreVersion: act.version, userData, relaunch: false, state: 'waiting', createdAt: Date.now() };
      fs.mkdirSync(SW, { recursive: true });
      if (old && old.helperPid && alive(old.helperPid) && old.state === 'waiting') {   // un assistant attend déjà : il attendra cette instance-ci
        job.helperPid = old.helperPid; atomicWrite(JOB(), JSON.stringify(job, null, 1)); log('Remplacement du lanceur déjà en attente (assistant ' + old.helperPid + ')');
        return { state: 'pending', version: c.version, detail: 'sera fait à la fermeture d\'AI Hub' };
      }
      atomicWrite(JOB(), JSON.stringify(job, null, 1));
      const swapJs = path.join(dir, 'launcher', 'swap.js');
      const child = cp.spawn(process.execPath, [swapJs, JOB()], { detached: true, stdio: 'ignore', windowsHide: true, env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }) });
      child.on('error', (e) => log('⚠ assistant de remplacement : ' + e.message)); child.unref();
      job.helperPid = child.pid; atomicWrite(JOB(), JSON.stringify(Object.assign(readJob() || job, { helperPid: child.pid }), null, 1));
      log('Remplacement du lanceur de l\'exe préparé (' + ph.target + ') : il sera fait à la fermeture d\'AI Hub');
      return { state: 'pending', version: c.version, detail: 'sera fait à la fermeture d\'AI Hub' };
    } catch (e) { log('⚠ remplacement du lanceur non préparé : ' + e.message); return { state: 'failed', detail: e.message }; }
  }
  // Demande à l'assistant de relancer AI Hub après le remplacement (utilisé quand on redémarre avec un remplacement en attente)
  function relaunchViaSwap() {
    const j = readJob(); if (!j || j.state !== 'waiting' || !j.helperPid || !alive(j.helperPid)) return false;
    j.relaunch = true; atomicWrite(JOB(), JSON.stringify(j, null, 1)); return true;
  }

  function status() {
    const c = readCurrent(), job = readJob(), res = readSwapResult(), ph = (() => { try { return physicalInfo(); } catch { return {}; } })();
    return { expected: minVersion, payload: c ? { version: c.version, source: c.source, installedAt: c.installedAt, ok: verifyInstalled(c) } : null,
      rebuilding: !!running, lastError, lastResult,
      swap: job ? { state: job.state, version: job.version, target: job.target } : null, swapResult: res,
      physical: { target: ph.target || null, version: ph.version || null, asar: !!ph.asar }, log: mem.slice(-60) };
  }
  function tailLog(n) { try { return fs.readFileSync(LOG, 'utf8').split('\n').filter(Boolean).slice(-(n || 60)); } catch { return mem.slice(); } }

  return { rebuild, loadPayload, readCurrent, verifyInstalled, stageSwap, relaunchViaSwap, status, tailLog, findLocalZips, localDirs, readJob, readSwapResult, physicalInfo, minVersion, log, isRunning: () => !!running };
}

module.exports = { createRebuilder, ZIP_RE, REQUIRED, isPayloadRel, cmp, sha };

return module.exports; })();
const LANCEUR_EMBED = {"version":"10.0.0","hashes":{"main.js":"734daebd269cfa01f2a173b4a59388dd072b0468306de2e81f875da7b46dcbef","package.json":"ea0117c8a8c12e8a2964bb913551b27939af1c8d13860f8560ead0e4dc07a326","updater.js":"855e71656754f8158f0d376228ff730e485a72c5920967f253f1dadf75ebc5fa","launcher/boot.js":"6ef6dbdb7b9cdaedaa0097e2ccf413595b57f523884997ef64f68dc43ecfffd8","launcher/updater.js":"d6f4e7f77088609c0d2411cec5e1b757c3708df571df842a0c371d9dd6ec5290","launcher/rebuild.js":"7becf8838b508c3086f2143b461baa5aedc42942bc09f41ff8f88cd5f8cb355d","launcher/zip.js":"670d9c7a04b17b2cdb101d13a813a59bc9717c26fb03084f0a947e98eb336686","launcher/swap.js":"2cdc18ec61fb516fe0fc023496db35a7aa0f4095322f16734bfba117b817d329"},"zipB64":"UEsDBBQAAAgIAABgTl2GFZ0xwAEAABIDAAANAAAAbWFuaWZlc3QuanNvbl3RS05cQQwF0Hmv4umNA7GrymUXu/E3NCF0q4FECmLvEQIGYXgl69i6fjlsu57P+8226/Hq9tmu7vX5wW/zsn87bHudLr/0ab/Z8C39zsvj8fTwNoxwDdfwPnO8z8f9Zns5bNv+S48P13dvcec+QtOizeWlgNUUudtQWl0kArgZjCkdZmRLwRKmULYxwy3rDd/2s/pP/ZHXd4/vi1MBkV1UHFuKtjWH2cJOhNZ49aWFLoFdJpTQhNSAHOHA2tt8V5/PoU95+bhUiJJx0mQaJUhSEJ1na1LFHXIIKTen1WBNrka9MDSKKc2p9N38LO67nU5PH/LMmmFhbMtDM1QBFmdzr4GdFhlxUesiYy3OmqOmhI+eXlUhX+T/z45ZI7mYQWTCcog2ED2dEo2JvTNIFDFGyWgK3hljRcx0agu+4Je05+N9fH7P0kukixGId5BZDUe3MdFUSTN8tDWaOawaWCUl4kElbp0ovuB/j+fPShhiOSsMQ7bmYQgY2FWwKy3zxcjeZhl0kFGga3AuSet9Tplf4Mc/+ik3D0dJn1hGOCuhHFofa4Z1UlaFGrCot1Y4uQ8rU0Q2QY7e1n7YXg+v/wBQSwMEFAAACAgAAGBOXTjizGN0BAAAhgkAAAcAAABtYWluLmpznVZbbhs3FP3XKk5+MiQypqZ5oYgyAZxHEQdpUsDJVxAEFOeOhs4MOebDtuAI6CK6gPwV/u8OtJOupODoYdmJ06KCIGl4z7333Cc1HuO1NIqiw08F/v79D8jOuuWfckY4fLf/9PULgWeEWqtGkwP5gBPbWhOkdtSRCei0iV7FlvAIuoUhqEaaGYH1jvxxJI4j2UntxWg8xkEL1VjtdUBLaNeul18Rg261JwcWDeGEnNfWoG+jh1teKDKB4EhZ44OLOhAqaTxa8qisMcuL9CPbP8DLOM3htbEGitrkQ5+45QUl58uvUMu/wvICFUFto+I5+qg9Wqm9HwQbXiuqDhRQLS866Ry5xNvYuYxgyjoao8qs0zNtCDZuiXfaU/J3ZKPjYjTwxjlk32OBEo6Oo3bEMmpJBWdNxidrUC9Ds4tIzxnPUfvd09qnM+XmfbC756uTZE3XYLd6ZxV5L8iciP2Dl++ffnr34vAdTzyEp/CbDA3Loif3XAaZ5YNzcWS1YQkx2yBk3w8AniOTeq+J04zzyWjN2DcSJdiUo3yypiSUIxnopfQNy3wj7z54mHER+0oGYlMuKj0jH1jW0Nll5IZOySVLMsfK2DlWkjOUOAxOmxmTXPi+1YGNP4i9j2MuOtmzN7GbDnWcXwKnPwBOUFsH1lKARoliAo3HuDeBvnOHI2WOnX3QH/HlCwqOW2UJNt8+czgK0RnsYp7sIiYbRC1bTxMsNhH6lqhPEXZ+HV9wc5xjP9hOKy9OpQ7M0CkOTLh3d985OR8eDxvpqBqen8a6Jsfuc56jGN6d5xMsoGRQDc4XyVtq9vcGjrq+lWo1pxX5TcN7VHHb42mkyUDZ6DzYcaT2OJKHT7OWdGQcppDjEayBDIFMheOY6Rbe6oBaGz1ahbEKsrXqM8qbWmnbbKmXWhmNashlOTJ/Kvv0ndSzGyp0v8Dt26i9oDPtgz+cG8USnqfj5zKQMPaUcewljA8yXCJEF3RHv3o8xsOiKIp1rYeKsAdFcSWHo1Fy7Bvd91ShRFaIQhTZZF2uS8Grw7dvRC+dJ1Z74UhWv+iWBq+X8X/6VGlnZEc5sl6qz3JG4sinmc+RxVD/nHEu1ovjCos6GhWGNajVZ8ZxPsKawf94jcfbku/s0fzKisVxTPuvjXpP6RzaBKnCKGmvShtTzDeWU0X3X1MSq2vVV9E5MuGbvOSotLvSTddVVXSb5PHJwDXN77BL2I4s31Rt6JW30yNSQZAJTpMfcLVuyXNBJ+TmjH1w1OZoPg5j6hv5g1gq7XI4ajnnKMsSzeWGuAa6pD0w3ak0vtXY7ZpdvcXQm1NrwzY3Q3dM1kOYJDs3wnUKSSyOfNrfWIxWBBhxnA9pGwyW5b/S4AiNs6egyc3+vqt5jcH14t4QNBabu0aFdBcMJlZXzDNrAp0FNtytefp4rt0j7Bja2BnOk8PFNlffklbhTAzWV9nqpDZ76ZpfEU7i7+btVtKrZZAty1Qj3Wy1c3XXW+/1dPhzlOEOSHTkvZzRbgYXo38AUEsDBBQAAAgIAABgTl0gC/9vugAAACABAAAMAAAAcGFja2FnZS5qc29uTY/LasMwEEX3/oph1rHiYCghqxayyb7rgiJdUjXRA42cTfC/B1k2dDVw5t7DzKsj4qA9+ESsXf87XXlX2RNZXAwVHwY1qKFhCzHZpbKuvuMk5CFkok8FQpcv0hN5eBCCzdGV1vPaLYU61Z802FTCJ3oRS9G51AgeMCXHQIp3tXBHPyWry3JiiBZUYnzI/t+mGmleD3yekRAsgnFY3ZuyGn7Gsb1D/LnxfdLmrm/IS+BwVKP6YJq7uXsDUEsDBBQAAAgIAABgTl3woDZUjgAAAL0AAAAKAAAAdXBkYXRlci5qc23LsQ3CMBBG4T5T/F2SArsHUbECCxzOiVxwzsE+I1ZCjEAXFqNAdNTve97jkOaFTE4Sxd4PbBFb0iCsiKSBa0bHBkspFj/ThTd1GcjYTaVHGCmfmYTVsD7h/LdlrC+HY6qGmxhmEjVWUsNAWhCpahg5/7SbimvmNNTIju9LylawR+Zrlcxd6/yfoe13zQdQSwMEFAAACAgAAGBOXRcSPalUBwAAwBEAABAAAABsYXVuY2hlci9ib290LmpztVfNbtzIEb7rKcqXbRKhOPItO/IY2LVlwMFGXlhYH2IY3hZZ1LREdnOru0cjjecBcs4L+BbP5hH2tsS+V1LNnyFHRmwEiA7CsH/q9/uqqoW3CNaRypw4PZrN4NIYl15bmEP2xz88Qe6hlDpDT/D4JIWfnCqVbXaQI+To11DI5p9GW5jzZYBjqJd3Vv3iEeZQSaVZVpRLbaFEyI21CglyobR1siylU0bHUApZ11iWCNJD3uwqSSSvMAG5ktrxTW3upIfTXslKkfNYAszB624zR6iURWg+wrXxBFG2lHTV7KCWxKe+O3/28uy892astObjhFVdygwpAdRQNbvKKMKElds765pPFbbaJ3+HSnNkuTpTqIe4sf4MS6+OM5XCX5tfK4TMVLUhhxVql0AV1gpDlXQhskbrZoc2ZY3PEAqVLTluGiE4hVBLC2clZo6MBhbdioh+lnX9M6B1UBhPWgXlnadSuxjmoEqo0TtofnWEgNbKu2bHPp+bHKH2lB5lRrMECwsg/MUrwkgUVsQJ1NItx6v8zetmctZYEZ92UjaQEUqHP9W5dBzdS6/K/EeZ3YQMP3v1+uz9i5c/nF3Adiwinfn2Qno9Enav6umhe1V3B45KdPDm7PXFy1fnsABxkp6kJ+L0yNEdbEYbf7l4dZ7WkixGhU0JZf5ClXhxp7OInUmvjdLR+/e5Ii0rTECkqUhA1K3B6bU1mh0W3hV/FnGcrpCsMvoUtpBJly1hsz3itL3GkH+YQbPLlpgxHzhHFq7QOrTAHDnESsKcsYzWHo4MkDEJUYN0DrXDkOWl0Yaa3VHhdcZcgkre4DOjHZnSRplbJyDrOobNEUDm1ilhKb3OOIdRDIunYQOgDZIqIGoPhRwhwTffwGRhuP9GyYtbWX/xQBTHsGETUlwrF53Ep0DoPIV4jSLGRvCp/noUn05uHQFs+d9/+ND8PYSzRp2H4iAYwgpy4TXXCb8KnO7SAnPWx8yURKr5RIxwZYHa7KTwQvo1WAXEWWg+gtTal0hpF69COllysAil5VLFITsIVw/UQqqyP8dej+MdDY6DI49T7/udQpaWt9jRbilz69OjFlA/dAj4/V/7Gvv7b1yol0ZZFcpkxhRuPrZooQQIV4oBxKjp/XfGO7DoS3abYzYpYBr7AhyKTLpHVktjxhauXRSSGsD1XFECrZdIzxXBtoNbYKy3SM+lk7AI+bxC96N0y0j068ylS6/zEnO+u4A9CXvZIjOEImCgk9kGHBbT0hJtgIxx85GIXgvzNRyyU317w9+0eJkPlWIbFHJR4ZbIv9us8xcsehvSmrCWhJxfRnGb0gjj/clNj8U5iE6zSCBXNJ8YQqYsMf9eZjdzEEiEbfPte8+DTjMHAX8CTCuG/xXCtjMgRChz66DZD0XXGPd1ju935mPTh93K5DgH0UOwd2UMgA8fYCigDHQO3ufrEu/UZDK0NjU6El5n0l8t3dk6w5pRJ5IQzMA65tujgZSRwP5QF4sIuRwNEYnjOETDlJgikaEIOUnxF9nVDxeBXH0dhjDDcFyjvNldNx+hpmZXS+oGjMNKHo8HhwfJQ2br0AlyHOrRnm6+viKZD3wLIetIl/8vJMM1dqlm3rh1egCAPb0mdOSTo4UPH6YEZV3f1XVQF0+puq+M/1eiDqeGjZGn28GU/vqUkIeo7lLfgzo/APMkil+A9UOInbV9CuHSaChMm2fdjYCW4TVMdOjaBWd8MJqb1IqkYrB0syHMIUx1PIvzUa97JnkLtoMmq21naK76COOxezxVROh6FFurrOMbAZWjIUTW1Hyy8QiiFsvCoXXRGIuu4hGtsGl1kzus6oPJytjUVXWuKMBFqqW/PO7lHIs4HgptGAm6amYIJ53BVfUea50uRUETLwYhA5pNfheSLvg5csz7PDHOQVQm91wb1jyJ20XvVhRvtmHiIyyNzLvDsxnUvHqLlyuFt8cPdm95V+kc1+nSVSWvPuEfT5/YjFTtnq4kgVw8fjLrvp/MwrZogQQ8/kPUTd5gitFkHLOLt6QcfmZUZYcSKJgtJr97W7ybeO+/gnttND9Luzm04r/QJSHUZr9vhv1UDI8Wi33Xi8EtydyCxls4CxVZ7B97YmI389SnHVyj8ZMh2rTcbA3bt9Zvvw0DfwLaOLTcQ5luArbxyMRHlJobpjTLLkwUp5knYnQHQzsZn7FzQpyu3VDbVlicEPHXBKKTzzce+TQzulBU8Yj8QF+3F/SJiWjCFZKL9kH96lgfDMLTgN/Dgl9X4UH0N1VH/JuLG/9+uwGufnMQcnaZurXj+iidnMP3vih48iVTRcLciBi278aRuE9L1FduGWx7zH7fvz15l/Ll1JkLR0pfRXFrebj+wOh7VfeGjghSMUHeinTWPTyYhvxUm9lbGR6E7+LhlVh117uCzHrCcwIKpWVZ3g3zPD8Hq8CuwIgNEGaerFrhPAztCVuQdR+M/PEIv+UiP60ooeoMHWYyPicH7T2ZNJJkqKzJf3s8c+H4N1BLAwQUAAAICAAAYE5dJRFJmJ0RAAC4MgAAEwAAAGxhdW5jaGVyL3VwZGF0ZXIuanOlW81y3EaSvvMpkrMbBmCBoGiPHRPdailkixrLK5EO0fbsBsVhVAMFdpFAFVRVaJFDM2Kve98H8NE9e9n73Nxvsk+ykfUDFNBNWt7Vgd0N1E9W/ueXpahVFJSWLNfRdGd/H9qmIJrK7FJBXBGe01bCweMEJlCJC/a+pVBQqJmisP4ZLkUr4eT50QkcVjTXUvAUclE3RLN5RYEsaQ5VRHjOKIdSyJroDDfZgzfrv9dUQcnyBaNSAdVQ4yM3CnCjbqajCWKliabZpcJ9llQqJrjaf7J8up9CQ963VCvICFu0czvDL3aQwAS3BWg5uDX92SStmAYtWg05NdvmtGrZXs5gvcol0ynSxjhuR2vKNcSSajw3kZKtf5EUJyMjFDRCKTx44g55JNolJa1erxRM3HKtpEC0qA0rH0EuGmZYqmhu1sCvwSn9sS5b9b6N1j/Dl3+ENyK1p/n1v0DMlajWv2gKv/4DLtuL9QoUbStL6fuW8AIqClzckBaKSEh2wTiFmF5T2Pc8SIBAviD8Yr1KgXGlSVURzQSHgjYtU8g1Jyi3cUElt2d3UoBc8JLJer2iqDZK/1mIIsl2csGVhlLBDCR93zJJ46hUUYIH04vwKf7G57m8abQI39gn+G5Zh8+XdZRMd9wWXx+/PTx/+er14QnM4DSqCeN7uZDIxiiFqJG0EqRwvz7Q+ZLRD3vDp4wX9Dpb6LqKzqZu2TfP//X8h6Ovj49evnr75vAFzOCzKYz/7TtOIs8VKMKVZ4flIlkSrmGkNcEG3/3Ln8+/+rfvDelf/hE+hYPHn/mPqdsg/hO8EVDg2hVVTomVl6BK3HI/Hr49eXV8dP72EGaw/9d3xaN3mf8T752++5CdPUqe/fN+xze1IDCDeJ7A7KnjfZZLSjT9hqhFHKkF+eyLL6MksxYVz5OsYBdU6Tha0GsUgF2HtzUKOV6ahU60ZPwiXiaZaiqm4/3TbO9sP8lUxXIaP07h8ySrSRPH3AxviFT0FdcxT42v+ekneJxMd8qW54aBed3EJIV5Arc7AHbDa5iZTWOSpHDjf8yT6Q6g2UNcodnCDB5PgcET+HwK7NGjBFgJcXx9ys7sLrA7m0F80/1OUE6t5BCO2QtH4AZuzOPpzt0OWsSP65VkJaNQEVA3XJNravWAXq9XeWt817cnMIFSuCNRvqSVaBrCNYUpfPP9m9cwQStEt/BE5ZI1+imgn2IXnCYBLxY0vzoxe8Sc1BQdbkEtZ7S8MZ9gTolvM8oL9RemF3GEWp4kwOkHWNbZidkhjmK/cEyvGyG1Sp19pbUo2oqm5+clq6jZ6fy8YBK/JbeRcV0FerDoHb9LohRuwQ+cAP6FO8MqAFopupUgY2pJ4kj2gpUUVdexIH62e/rXp2efvpsrmc8S8/1pfPpOvTs5+/RZ8uTdvmPV/gWbAoq8ToEbqbtFPyxYRSGOrevI6DXNY8Mx3Bj4o0fTEUvq04OzLad5BNE/2b3w7BxPB3dmD/vXqQRvqwq3voOc6HwBMYqme+kWggngIjSrqVLkguJKdzu9jE18yP8imaYxkpFCQTSxjCpVVl8VTJ7c8DxGp5k5oZiRSWp2y1up2JJOQMvWC8JyV9cNzMzZkJAMyWikyKlSWcMK80zXTTS1O31AEl6yiprddN04SqZe2YxcS5XRa6a0MqMMGQnOzkVz00225+g2npOrCDno2HR7161Yqkwaxvd7miUtu0OuduOHZAYcm+LblleMX/nVwk1BL6T4AMj/kQSsC/zB5h3xLUghdArzlhcVLV4wmUJFWp4vqPzRBsDupfs98b+Pl1RKVtAUrihF3n8Bd6EfewkzuLUhf2KCYnYpGI/thlGfCpj451KeLQP9qyiBu17apaQKo2xs3Gx8C3krJeV6ApEjL0qhkXTJRKuGDykvGL+YGIVOYU6KCZyepbBgSgt5gz8GelUweVz2ASBewmw26xeEZwHzIKT/ZeZJT2GZYEA38c6xEYrWJS+laCVnLqWkXfoWY5Dfd5Fe8ASmmJcW61VJWo1S6jKUou0nuRwQU1UhtQncCWq8F/9QlrF3UVbh7IEvYQbfnhwfZSZ4xUZrSdEpYX/AUGmijlAUZ9Tq8k9RkkyNFfWhO9MYX10MvfT8SfrYtPFqZEgwGjhSRYxjI/U1krzbCXnAMXeu2N9orPz5McIfzy9prjOiFLvgsVGwOElBwSefgL5pqChxGMpemJEoesx+b9Fh+myJKgx1daOA8Vxw3ipQgmvDWiqX65XqotjucynJTcaU+YxVNidFkoD5xFTvbHr/UKesZrj7PpriKc6cYZh0IFKGbVESPA90ectsb0Ib07sXG/OdhJRlfMB3VKMTNPtO7Uw64wwaRAmnLzPjF1JwXzqPetYHU6urPvB0snxAZcteIzcVaqBWTuobpBs/bGlHnRnEsY5mQ4FlEStvYpU6F3OQeBdvE0qhMRHA98Ss3rm/FAqqCauMo3GK6cWbNa1axLeg1QReoOvk4gOq5z1LTNwnWkQUdRlLqC390jZ53fvCpoB3nafyud/7Nmo5FFgDUol1nPc8VGnjajA9MbWkJrkO+bakkpU3L5hE72lP5LwqzKxnjZeOtD7Fsyo48rO9/DfVpi+RbBa8O4zbvccqUigDb3ML4moCJakUTVE7FUa3yBWEULzrqsqacKw4tUtvShuJ7L/BWjYr8S/vBulfTfjHetYihagmnJVU6U2nuvPbXOh5ZfhRE55h8qBQHfpfp+XZb/DCE0GNO7OC3sID3EQtyMMnMpxHN/I79veyqEXBSrZegWghF1KKumk3CfH83hBJCv4gEyMGN2NrKruVEJqZmsBo5OHR8eHR9+j9oy0mQeaKco2JcJcEw501/ztnV29HKAvSJA0sRALUoZWmgspFXaMCtkvCLEUNURajqgg0cr3K16uC4tBYtOaxV9tB4C9JVc1JfoVux55qaJA26HRhoQ8F+GJ3aIldiMqyDEuME6pj/G6em5TqLHGhCBUGQ4VZu4sZn3wyDi244LPw4WRbWDIrDYjBpXZ7L4MDkkxcJX7T0SJh2MMR0/siGT63iaIpwG3pA8Z3IwcjKSw7I3PcjqWDCGifTQPJP28aWq1XgJDVelUTKVE9sDoWTDGN6V+gUkbljJx5TmUozAa1QPZx1CEephDsYmwKc+TAOOPr5YJnoMVXJL8anNEYc+amnVDKrYDQgcO9/zD3ieg1TcMUVrTbILoOkvMgHJ4aYTcqe7QpCASjFCaUPMIn3evU0PhkhrhG7/8sa5ZUbmr3WCGG0v8dWjHQDINbUk0jE5NRVWjdVCRHALEhsucIOq/50lTNfQYfJWNnNhQFCmIa5C0PMGgMP4x4kAJqRxCgqez2NkFjaexooCShE1lmA50P0JCeSdbO7Q+f0hsnipuNglQ/cC6EVvB0NsYoHyAm4kOkljRy/YsyLB4DncjvHtTs+e0OMCLj0aOhPOzfQTo4sPlb78EnIacLJicu3emeJml4nLvQTbwmwBFgr6ogrniPsV6ZCEhz7Q2lr+0tAx52C0FV0Z21i8Im7I1cnVvVFM8b0uzySg+NW0c/HLTFbkYs9PtjsA45sf4PRAXx6Jrmer0y1TsmYlWEsZVBEbWcbnJrMgalgdX1elUwoodBkVXxtmj4f+TZZpA1+fd6ZU4x8PqIEX0ED/pMmlQMMZvvSH5FLmjcXF0kASS621xd4F6ucMNfu2Gp+tNP+CwjTWOfE7a3aOd7FvvuXruuEo446M4XfU19kwT4uwhz/oaY1olt4Wy0zZ6/gm/aeRC2d+9BAHDLTQwgOmrr9UqKMKti3JyfupwvmDgdsKDPcntGuGdjduy6ev+K3qi4G5ZkFeUXetFT85095JIV1B0pSLxPLVBdnmEC7hakXEtGwzWTQWGz2yfqGeN51RZUGQQ5YMFLz2+0/FYLyRTGS9sk8Xy3vMCZA79dBscvs1xwvVn+d6I1b1tgVcVMg++eRTG5/6otSyqzUoo67tbtyxKzQ5nZtkq/w2HdSMq4qyCs34LYnYBUer2S61WyZVvLYCoxaG22BjoCBjGLShnsLCUmIdh2tI0L33MEScsW+fk///6fFq6WchxTUXiuX6BeO0TJZxwbAOm2wQk8gcfJsCBBS+pspia8oGhFPlvyir2xLUasuKKgEdlD88ORIyJwUDIEYDrAfmcMwngfYtDnod/DPKhUBtHoMe8gL9SZYn+j8HTY3ksc3ozFwKGUQsadBmspGriQAnvIrbzfa0TDOPoQmmNQ8LAa9tHile3w0mAX35weN9XnROXYBPKl1x8oNie0qaNM6t13Of8Qss81kVE/UhCNxkBxezdkotXZbQ67Z2SoqYOKkyL7JmYNV6WG2dsWx5neH6zMnFmQ8z24ZfS6Lz9Rw5ZO9VDjivXqcv2zAZuWNPKU4R7Ig2xOSyGpY3/fwNh8Z7PMAIKDO1s8KNIu6QWRBbJfQSE4X6+oChhg+zv3wOuWVNPgSVIojBrfO9RxCPWq7lsxG92lFB19Pmw1jbpU2yd2Yx04Y8IPqsl05zdxm/vLqzlR1DS43L2SrqDCVCPHBEhq5SsMq/0DTzpvsYvRBaXT8gyeQejTw1cb7h07vB/VCCgDgGrcv+pn2OYXlqhtib0sT9EM2/axeRg45N9aaBMrG0GxQVZuajLMbbHXdHWRma8WJU1dc6x4ru277ie+t1ius387JsRhrZTvQsx3pGWF0r9Hy8atwkLpLtkOitM+sx7BJ32x6yyMddeOMGOO1itNmE3l+sIpBcHBmmFFgsswav0PSe9BB9DDtLygJeO0SDbr1TH+YMnBtH1wI2cp2qpFwnyCOb4DpAl3t6c2MQVOLaiAmq82kJ4llcMSZKwPptSbwGPv2DzAZT7RKLBXGl8bXP7aJDq9G+nqJHcaX/ePlMuN3lI5NrLlW+rIHrsc0to3NXtx36fRQVk5jmBoSy6UopseNgIdET7YbeQMbo6/J/BbKKoPMD4nGGeb25HSAO2yDApJHLg27D+fUJR0h0YGxXfPprNkmFySqrLpDh7Q+/Q+WCSd5O1lnl0e3vEwsQZTQj6CXTIlpI7dtR68e1Q38TwF0jtGUlXjpd0RsgVRMU/8faI36Odqco0Xi0yTfc+f1aRhSYIV2yHJF36d3ttsj348+QgXlAzR8dst2HVNeEsrFJ/nbYRoX8eEYcaJoSnW4iNKbIQlNZEXRph4WW7Uau+/h+of9C3t3IcgYjvEgsTdVttaoO7dx+dPL2ySpFoJOdW6q167fKlHjw1LDJ7Sqam56GDMwVG41dl3Pj30b3bCfejkQ2DVFifjzr3Vc5Qi/kghepULutKh3Qav/z/m94CthbfwNtDgAfDJky3NvI4dPDVMQjC087LLzCcc8Cz44TzvxKQSg0ThvgnBILAXUoJm1jYzDCj82Gs6XeBN+zsygdptDyfdJZlOpdxNGdfi8WjfJET+uiSpu0qz0WI++CLJjPIr06Do1KDXtu58rseR+uwkNWhdx9g0DGSpczKp0dE0LHLTcSGW9qJPe91FCuyNx5dkLs0V5r6IXP+MebVm0sCNXYvGXNCBuNWsMvAM5t5aiErt1+SKOmwtu1TBHcd5y6oulN4iJBx07o36YAZW3aQwRgFSWFBSUOnvWG3F1TowbbMe/3E7krbs4QOITQFctHCQfZZ9nkTBJShMRdFYkTb0p/jpkDJ4Zp9OgkImuKc1KH6C0odj6WOWHcCYW7Gx5AF8YYiQORhpUH95BGz2QAVjBMH7Jvt050EIKoUh+tRV9BtkboBQPuWRXRlqah9+Zm/LGfRsAmO8bQNt6yjwpuOpReTXsxvJslqTmMzw9au3h+eHR+ffvT188+rwLcycTt1z8Rvk+pcLTLZ//e8DgwJ8f/zDt8c/vD3B27t6/XeESlpfkPamO7xHZYCSWyBNMxmjzqn7XwwTOBhbwQTuq8uQty9MsMm0eHVy7BCRZNNiJhtPeg/lqrXEGL29D5y5a8JGDoNbkunAbNNQFVKMOCmKKw3vBKWBLaTjDlQ6xM7S8Gr73XTnfwFQSwMEFAAACAgAAGBOXZwmhDUFHQAAflYAABMAAABsYXVuY2hlci9yZWJ1aWxkLmpztVxbcxw3dn7XrzhMbam7zWYPZXkd74wply5cW45sKZRsb5aitZhuDAdU3wygh6TJqdofkYfU1j74KVluqvK0L6m87fwT/5LUOQC60T0zuuwmKpc5g0EDB8C5fuegg0ZxUFqKVAeTW6MRSD5tRJ4lZwrGIHlalUrLJtWiKiFrIGdlyhsJWXD/MXzRTBN85oWsmgWHnMNvHz/ze4WrnyBd/UWvbmAEL1Y3+eomnTN5ygteagUjyFY39eovGj4X+otmCiNIq1pwEKVe3ZzK1Q2H1U+QMyiEoo9nVSOjGGdarG6kmAmO84e8qCUXpeYqBnVZanbBY+BKMQEZKxU0JdSySrlSjQK1uqmZXN3gOIEolWZ5zk2/T7OqLFc3XN0b5awp0zmXo08XXCpRlfdGMdSNUFBLGoBmzjlIXtQ5S2lJkHEFM5HOBZeqt104Os5SKSU4bp+dmNHGhjMmtF3qjMuC60byGNiCp3ZHMg6Kp1UjVURb/pC7eYCr9tFK4KmFd6JuB9upy+qSNTjOYDshrCUvxOpPkg/OOwKuaXs/jCAXC38wPOfQLa59Sugogcc5lEGjRY5z1EzBYc5TLZF9hOSpNhs1Bl01Gn+nXhJ+x8vF75JbNBLMFByA5D80QvIwmKkgiqFmeu634ndsr3p9K+qb1n5bOhd59soyAP0sL2td9bpQC/62KPz2RRFEk1uWqm8Pj54/fvr1q6NDOIDR9y+z3ZeJ+1+4d/zyPDnZjT77xWhi+//28TPXl4m9eTPdc0y1F77MdqPj5NVJ/0PywcvkR1H/YiTcGEeH//zN46PDR3AAx0HBRJmcqSCGoGbpa3bKkzNVlfi9qTOmubS/tsw7rSo9bNvStRP8XvOPoh42qXNGbSeOSKGescu8YtkRz+EAQhnBwT2QcHBwAC3RcH3tmnrEe+0eZdSaKM2kVt8JPQ+76fFEzLxf3f/NK+TEA/hkHz6AO/sfffLLf/zY/armDImZEjHmgJNUcqb5F0zNw0DN2Ye//DiIEjNtOI2STJxypcNgzi+6WcqmQBYLFzTQcy1FeRouokTVudDh6DjZOxlFicpFysP9GO5GScHqMCype82k4o9LHZYx3NmPcFn77chpgXwashgMkVdg2i/ggGYNWRTDpfsyjSYwqySEOdcg4AD2JyDgU7g7AbG7G4GYQRheHIsTMwnsHBxAeNl+j0CiWinB77Pn95i4HvsTWDoaWS4WHKmsRWaJ1PISrpxCTV6LPMcfY38ELRs+gSWkTKdzCHkEV+4nnqRVxs2BHz47PPoqwI7Lya1ZUxozw3RViPQ7KTQPZyLnMWRMswiubgHMVFK8zoR8flmmIaqAJBOyZIXpGcU0T9pIJRZ8TGTAMprcAruzmnYcu8IuBEkAu+06apFRmy7qYILznCMBvxY5p7l0UVs6cDSzBTOVSI6Tdz2IiuHK2979Ib210YRNmYvytRvLG+UK9FxW50Bbury17LbKGLtDKUMkIwbcWrNRZs6Sn8OiSJ6nUtQ6DEL3YMgv6kpqFVtNFxdV1uQ8fvUKiaKxXr2yOxtd4TbRoe1C8LJcRgFus+s4Bvw/7rI74bLJ8y2HT113IYAx4KA8KdBKn+LCbi1vdesycnpkVBKXIS8XZlnmGH8UeIy8XKC2JFXhFHbiFJZ36I3i8hHTzD7ivsbwBA7IrCRnlSjDrr3VNWgQHn5z1Ov2JIYgbaTkpTYKLIrhydPP1/o4fZpXp9jl+XdrPVCP+nTyYsozS6T5fH1tN3Pzv9EIrsC6JzHMmZpzNabNzsdg1BssY9ytBx9/BMt2okKU35qn7Gxew/U1ulM4+e3bhqLEzkDKK9hP9pP9oCP6FI3y0+kZT3XClBKnZXgF1XnJ5RiC33BZXfzLiwd3gxgkr6sxBEy8mjfTIAZWizEEc61rNR6NWC2SU6HnzTRJqwK7s3PvZ8nO7c94SmlVatx+07Nmp9zr6o2Ci8flmSYk/8pXBgVHW398sm17N+13xmVJvpKCXJyWnLw8dKNKlkNYoz+VB6ubVLIyugWAqlo2ZSnKU1LjeR5DzpQ+lLKSvZYjrppc26bJrZbIvMInw8Lo3ltIhv1BlKiXg2MUJJTzR2jEokRXj58/tVYqSiQn5zQMXqAJh8AzVHd+FaEonpAkFhMauuBFUjdqHuLo0YRsCrblvDzVc7gHdz7cj6iXmouZDiPzWKvgOt38ZIsqtn1x4JlCA69N96efR4kSP3K4Bx/u479oXWE+efp5TJOTCAUvyyAyKinwleUSH2R1zcus/yTt2Ib+3hKM6AlNzG8/hwGKsHl8+NzSl16Bxxfqy7q1WJ653Diy17e3gCUxwGgEe+0/WN1opv2YwnO7vX5oI50WlZxlD42qCiPLPIYa63/AAXz5/OnXCXkpIZkz1m3aw2+O0LPUs0+CyPJCiuR3fnCi0V2yzJa2iiLCXmmCFkLhR1xmNWtbyPRXpDKC1itJ107Etya41f7KFlyK2eVjG7xlYeqWh0TupO2oM5YrPvGkJhNyqIc7unvMjJ6WeeZY8jyG+QlUM6fpeKml4Cq0S4qM96XmbG0Tu6kyIVEL5lFkfLP5gMrNvtPVoNNyuBW1cb0fCUm74Lr3lhimxkh67BB1q6bxMKak0BzDu00sFrJarv6kXOCdmsg145DO2Q9NG45GCZ0YKAFsqjDUqxpg09V/FaubxKcbibZhQ8ucHVv2aJ1sOlrHF/aHdY7Azcir0zB4smE15NK4LbAeSRu4W3JVDOK0rOTqJlhzbtZkyQ8bu73vHY7vWMQQuNgs6ga/AmwcQxE7sz7uqIyReccwGNK6ImNIYeno8h2v99qBDpwBUdSIVUxzDmHPVcOu0cYNWa4rrQXLRWY5JWhKwg026yrbk4dWtNAqTnne54xiRg4LdUhmosxCXOTBPeAJeZY24CzFjCvnnSHnb3pk9P3x96OT3Zcj1/8lPfCLkVFqZsTI571iFllHHM0tmfCwP5tj+TDlUL4MEJlBBGQNGIuCyFdKteQzgUFfMaNZOxvtGqz93Ruuzv5gR0Nvo2Cls7EFK/sKvpglaGsSXVmV3Sn3YaixdYUizwWxRRA5djObw8h3LFiJtpcUXDBAPQLXYVbJgmnqc2fDlqZmu7wNbMpWJRnYMfDPZYs9wplai7RhGsf6oiTe4zYm8R/rJkmL2h8w9nzoCD7FUHrr+INBSdS0rGpgZSp4WVoB83xw7FE1UOeNArm6SXmpuVEuike9pdNuklG9vnZmtmvb6RnaNQJzoTQhi57iQ/blbgrPBko0fg6MigaTH8uTDcM7fLKa5uKU6UpI7uQja8Bxldt22ZOI6eXXJM803lesdlrBQCtGgI+NiMbAiatPosiE38p7bH0hbzDm7Xoip3UAY6dEsRlHckI03hP7g3Un4MDSmpxyHVpB3gW/J+1V9oYNKlj5Q8NwWzx01e7KYBz0MLLWfVgbscXBQZRpJQluhRCHK6pMzMTqxrPG0ZY5JM8TXmYWdjMWqjVzeCYd6EB7mW3SJzgQ30ShlISHc4fTw8+//1eDBbT6BMwxJoprO4Olr1M3bYTqCxZq/0HE2ovditWfC+4MK6DPknKE/hHQXzQGhh6C42PIe5B+JRbIwKs/a8lBZLzU4oeGK0f3O/GZodGE69Zz9ESJ5ydbz7fkQMeq6qrMSDNigoVrzQeQvj1X0iSZmM1WN+gktLqjdTecFI7xkxUfa3lNbLPBpquqkSlXW+x4XqUsfySkGjh1iPYfwHEfAflR1ASfxJthGAPMqiA6iYGi4LIXUjlAsVygyUEBfMb0PCyjDd6zw6SWawqhxBM6DrLqvES/iqDujKvXuqrpY5U2lK3CL/Oq4PiXX9AfzYs6OOmEA0GpU5ofz7SOcNEmnDbMSc/BZ9DDLWuUw7plfjMSgiqVSnC+TMjQIb8W2DYUP/IpXkuuYeOjbhkPGslZQ43tgk48Arv9n8egnNvT/pwkSUhR64WWDE8X7c3xCaZlLHyanmdh1Gev4yRJkHmfcx3iSDORay7DB1WVc1ZamDyzMLmeJ5KrKl/wMIui6GQt5EPf7Qky129FPWSuWdWUmcFyhseb4WZ5TNmpdvSW8ASU85foC8LDJoRzSEbW4yfEnkTZ8E5Z2XnQoh+gQTgY4nzE5ZN1FUGcR5N2RIEXTpj8UcIveNoy1U6BWm8npOlu34aRSxgZ14c8nZbEwZizXuSbxYCD4i4o7bZAabP+FpeZvWXx1izpRCgMeUMK/ZV2UM6d/f19v+XTA5e0icyhGfYyaPIYZjEsxlDAZ3C8WxzfOYlhtzj+0Py5e3ICYzjejwH/O4mh0ALRZ6UT+vSVskh/Zyl6OIKZTlVSh13GBd26abKwgFKCyoj5Xyl6mJoJYA+Y+eSDaB9GjlOZuizTjl8RjwwbmcdQqBiYetDM+kzLUuuo3J9WUj+sSi2rPOcyjGKg7KTi+oUoeNXoMCRqWZow7Is9CuXDFT1WRISDnWNGmWR2xvHwrq+BPkSGpitAqJblYxzUfERwwqRoxxDMqjyvzoMY5pxlXBKsHHyjuNy7f8pLHYwhuP9474tmuvekC2nvpymv8WlW17lFCEaLMrMA7C4GEDF8MPogQE3cd5BkUr3eYPG+ePHimfFSiCcb1XvK7So4gTqAXZlYkskjCyxWvGcCJRMO7htZKuFex41bvTNy1U8lJpYnzjuFA3jQzGZcJjNZFaHZbJkwKdml+SF0TtC0w07fcy7Lt9NO2GyLm07zixYcGSScBhP44TFxGzWjKQqy1U2OZRJY06DU6gZhgDbWJ+GfiZLlOSEdOWfSsaSuog6NGvD+6fwJGm79W1G3mrpVt6SnY+AS+TQIJmtQylk/ajXLJXE6nSesFujVjDCdoEbIGafzhPIN1Gwb8Ff6bo9fjQKUVYSV7bncx7NKhKK/4VkUtcSdOUMVzkjqZqjAZglGV2YHUVcF1nzZLgYsGCa9zBJ7SS4v6Bfpa/JplHVqcIOmLgGwbidU1MOafONgve/SrY1sRLhDGQ8KXK2+uhPDR5Gv66adp3yPUsQ4vzGEY2hH9cCoLSMR9OQzbIdHTDnZFFxtaGydF77ij12CtHN9+kdeW9TpjaftjnfSm9F3QeZJgWcTjobFGC+zXazA8P58/w/Bp/deqhNTjjE6FZH1d062nbGUhDN5R+2DI2ada1IppZVAqoES5VmFiriD3KQ0YBsGaqxJLX6W8fWyIjPEwL3HWbf48G+rjdri3Cuez16gn5EJOcBsKacPgZaXV1ZJHrRJWdg18qyIo8TscoiKb8FFafUT52EqnaEXSSkhx/LTBEki1yeKoiUdTMijK+8ZLmX/GX77Nkdjkr6+vkaAz/XlF0KHd6NlsM2umhAmrUnoOoC/fZynGH/EcBzsYXiAW3ISm9TPeJgiXXaeMy8X2OvwyeHDF0cIY33z9av7z199/fTR4RiCOwEs0SEwWncMH/5yf38/hnNRZtW5+kJkNreGmc60ykR5OrY5mxiUzkQ1huOAYGwKWWpRd39PBkbYblDV6CjRUhRhZCGk1y181F+GZ8Lk6gYTmAz5mGnNy6yx+II/aus3fbIfUbGGMepjuOuR0kan1WuXN9xg5Dy6ufUNSD3fRUEcfU9kXT93UEUlr19c1pw+jXowIbdMQtltPz/60X7UFc0YYigHQ6arkq2C9AfoLKctD6JkY684yChNuO7lYu9ivnO5dQNiOGeyHENg5LaV0iFIH9rimh4lVocsOwxlg0LolSNuSTKGrjoy2qIe7CAuq7OILVbQVxULjhpzkbS4coupmuqcXvC0MJqeqnKiGDKj2gc9Ilf8gNbLRfgqkUVXl7OWi47RwqZ+YrqXvt78UMuka0APIZBopxcWQuwx6I5fIUcw4nqUtilGIyoIn3tT4dO2qqcNFUdeCZMPKQ6TljOboiS4ER/Y4LNikYPAOlUfa1xHFM3BGFjLG9AH9NbIHGzAMKMTD61Jx0uxrai4g66QnXrwuCNje6J246RRD58mNmytIVVrddZeaYplrv4GHlzHS42h7gQSQZ6qWd3YrVY6IW3US8YonaC+iEzy7+c//OS6Uqu/jirPNidbO9Iz3NV3E59hMVymtB3OL+mjsoLBCVK+vWB6DHc8b3PBpcUkx/YwnUaJna7h2X09ptKXpKzOQwKk+EJUaFNwcbdv458WIkamRpXyWa91DKHX1w0QufIrLCPq2MoLV/6Gf6MRlBxOmcw4IdCILt/1q4osTQpCri0+TZnTXpk5xyJJjGt41NMeZ9XUHueX1RQ34zXntUUZ0AU+ph1d35eYnrx9G/+4tpMhXrcVwhrgZU8spj1My5WEDe0gSQh+Y7jisVlPp5fRu7Dc+5FT+kkNMif/F9NvrllZE6gNFndwtyKtijpf/Unzvm0dBNZZZWsiw6rWrZEhMUff52jrfQ3jHuBDZJ8w7sBYIp1XQgkMMOgn1ugKf8K/BaPUBgUfGS9Yma1uuCm4akUUk5aiYDmH9QxmhN6Yi0hMHRWVc2Px6NJLWKfzSvGyjXttna4U3Ad0XSuiKxg0U4Yihmkz8+ri+ijCAp0MV1SAaTw8FAQk8CFXXTCxKvKPJgdlEh+mFsLtHLavOyvUyeSNPaxm4aHCwxqMn//4b2tz9AorqDZOcAuJvqnbhlKUZWd/2kOOhvvidtrsY9cxhqEx7MZYC3h7i+kY6q0L6oFKVnZ4rnhLpCfHKclxH/Bv50a+1XjjqDWCpgoL4bnBCtMty0vbtVFun56KYCo5e92doKk3MiOiusSlllyfV/I12REKBnzk3o8YW7E84hjXpnOO0kjhOwbdXZHqWyEs+Pn3/96lD7wUuYE5DFTSA9z8vq52YdpztN9evNCVrDh4gjTIdCACEd0+okIFU81ARq2vDDbRTlLcR3kkO38ryEPfvzi8/4gaKeDl3xw9flgVdVWisiX6CIuL4Vf7FCmjuu6TMGCSwF4+M7zUjmC0S/fgBinoPbiF7bd3WvZyFWv8RlniNfZapz5n73JpLoh7iLVJQZvCcIRcmOIffxS8QdjXpnhPWe+nZLyleqUFBhDeCHSZ+2QdNBaayUz8vNdF1RMwCH8gkRetlghsCDzZhMANEq9pg0QMAllDaWz3PrGmozO9aD6eeOYibWTPTtjh3P05unXiVfE1Mhrm5bvAv6sD7AZ1XvC4R5FL2PcKgNedBSrxMCXpLbphv1si2nr10Hgf4VYb22Wa+o6JK7Vfq3Wf9Gvd5cR6BllVIiwlO+Mmt5hSb0CHv5C0tOWJiH10dt3ZXPtUm8KRBHSvYzrd+EtHG/2ylbguO9Kv82+NXBT2D9fb641e4d9/m7TnQJrlfvn0AZ5nl2sneXn+XQwBuvwurj46fL6tm6Qz8268PPynbV3zKn1tLFavEp1CkmHxxhvKz798+gBDmE01isOijuFUz89ZbZjsvWY8Onz+t8xYzy+VSFn+uJxVNN/bY8Bq9d/AbcHXDw3PbXU/GlOv/Pqv/2nGRpv61//BqtK8EaQWsZIk8nPJtbsQxeq6861ZXT8z12aDwKX4uzZbNHPfNITrdyKssXZ3kqZNmeUcdZa7xNC1hF1ylCnMBEwpxiTOwBZCqqZZZDJoKaLRw0IY/HXsyPPdfqYYiuvoZYKf2loHmsiAtr0gAUtgyDPCxz7zmNMB7lhnQiVMtA/X1wMymELvAXPYARKE37sdbWvNLCv42rB+83UKD2AiEoe3eKPhZYsZ5SSUVtse35w1iTwia2cytt2uuAI3Gm5X3N0ma/GVMezsIKcghEnU0rW0nR0vfZHcf/zFNw9e/frp0cPDV8+/u/9sgylKWWngH5M6ehegZCGZADxqyDy0MVSNhO9M+iMGliIRYYSoimpmM0EFw9G2W0mUbdoMlm6skaHkVMIE5gvPt90W3YK0BhfB2r3OWfSe1zxGI3hm3zdAiBCpBh//efdXEFi1ARPcq2leoVY5YwUTKsaWlK7im4beRQ2l2SlHjdq/Q9QDntavbFgfj3hl092Mlv8wdYP390rjAmRcM5GPUTaU7wF6iYigy5RYwUNt1tfCvdqSep607Lxp5hHzJzYV5kYXszJFr43Tix8Qq3PFj2MgD3P1U7v50iOLyv/mpK42zNdlbfxp85d9Ky5ZecoBS+57Zr8pOTCZzvFWNr4qAn3xEOWTJovhh+ZlUJV4oKbk17yDYQIih1llTrTkwC+YexODfSME1cbO2Oo/8Er+YH/dpSnv4snEK6JTplS7nvcqcdu7Jb1kA4ZmrUW2D74Zja/nSavw3LsEUMmZOUzRbPvDCRWbvfN42xRob+y1lymc+GJr1+DEthfN9VfbgY3Ws7law9C9K4BrXFO9DrbcCmo5qJOWLuIg9bm6OVv91IaC3UWhVoAYSq05Q2s239FatrsZURmr+9YTv1b1m2midxYJ59/WssK4E1dTgmcJTCBFpBMWMd52d03jBV3u5FjjrV2byoxBoVSRMFuBkRQ+96VxTSRYqp3DlWqx4A8ryZ1X1LWgHnT3tMmWOAFZomY2b2ThiP02ElWKyCHjC4Hr6V7YElRSnOLNVXqiWXDW6nR/k5Eg1LUs1QmZ2HfcYzMLkjzD8B4jZgyz1xaMLtuv7e2Kq+UG7H1mqpJREvews3tRieSoNey3cz5dCH6+128VZcYvkrkuclNN7ZwqO+Px7O05O7vsGGbRRsf9/baBwHiuLcgxM+VNfZHpMmcU1/gM7+VXaFLj89q4L3A/zXlec/lMUF96y0bYa94kJm4Mj/BhXoh4iUSc+C5sSsBiDaXxgklRSepU51ygB8IWTOSeO0CX1RioRmzOLF1hee6dzWrICOIzkY19JykGfsG7lq5IhslT1bUzebpwpWVY7UJKxNMnxj0dO/0UG6dkTELVAmQ2U2hLVBDnOrQ3Lrbc2m0L/egC08E96KfpIyxRQS58LlOsk7Uc1vKl+fit2wvs0O5Gd4tBcmNAWqTBHSbiJuYwzdsuBpnMTgB7HixG2NvrEtYY8K1ctoFTHWHGTR+NoMdDprjH2RRSWqZJMnsVhRRnmfK9VLRngyhDR8tBn7ZJLz9sreMgQ3xWTXvJfQuu+46v5+sa4jo3GaEstwDKW/S2xt5obYldkzt8l4A5qjcaYMUlg02v8oLspXUrPb3q9Ml7r70nmPgSkS/VhqjF923cG5sGz9KLsUxJm6rZebmpls2MHwNRRuVsuNx0joGhQShtlVlXZLaxNu3vLYHzWJzITqqyg+bsjcC23KE77GwQHQ1ha0oa4XBNKfms0+NDfjWd6nfj1f5CO+zr+hroKK+gHXrcjUx1fmun/GY+5+ioYFBnX0q3urFekVOczjESObwLd67X4P0/isCmVMMffhpEs91iS4Ta2mVuzYp2JM+YyHnmGcsOJF72IuxHlN42aZNgwDs0u7t2DPYdCMOYOzT5idUN4EXODAiGzFY3BZN46RVf4/fmEg4PvTRy+61gvZC7q4zvXA7j+J0RW1n9vePrb/IHzzw2Jv+QbMDZJj/De1nGWeIIoUwTIhXvoKZ6CtqHORzW7WMKulFve+9DvF7QIrmyDT7GGxsIwF6TGQC+A2Bgg29o3LshUH8F/KLGqrZs7GUzYxcH4xsXPuvev9QThzY9k2wsV0oT72tMWYgNLzRZwtjsZyuSlGChCt+dHesKeq8T8t8j5J5B7T2mXfysEwzUbfTRk2Wv8Kdzv7DRqpGWGBrSTILvB1VuJrfL4xZS9Nw3V0nlTeihBe2Pxsfb2XFR6DJGrTA27xsyqb6PXZ1sD1xE8X5S4V2F4eEPIwZ6EZCFWXslusPLiXa+kMj7eH9jUNHRFZkA4ZbHPPa4Yv9FJ7HP3/Hw0OMOaouHiiC2IhO7tcb9+oi4u+MYO3mJB3IS90Qh7jF1jiMKdWS4amwTOy2b4Z4vb90yb4lL7MvjKCAYvKktthdT4vZlAXHPq47xQkpM72ZcTm79L1BLAwQUAAAICAAAYE5dl5FSACgIAAA/FgAADwAAAGxhdW5jaGVyL3ppcC5qc51YS3PbRhK+61d0LiYQQhAIkQxNCHIlslPrKnmd8qO21rK8BQIDcSJwhpkZWLJl/iAm173lFv6xrZ4ZvCQwiVcHm0D39PPrx2BQSgJSCZqqQXRwdASf6dr/WcIcCpKqUhAgCnbbVFD9kBHIabqkREh49/wnD2TCJCRlWjIC2W67JixLWErA+VzQBQzhhzLPiXB9FH1uJcrd74LAHNaJRIHpkqwog2QheVF61ds/fgPfhz9+r1+8e/7TdOxBQVdUEf1GJbQoiAdnr87g424raE53W/8g5Uwq0PpjEOSXkgriDPB54EYHlnz+/AXEcAc5LYicw3EQBB4QpsSnOYzCAL6FUTCeTb6beqC4Soo5jIPWW9hEVtDZq7P/vIEYHMeF+BTuwLxWEAMjN/CWMnUcfi9E8skJJ1M3gpwLcAqigEEMQQQMTiCcTCNgw6ELd4CkFE+3WK8N6zWcwCyCa2RElhQewQieQHD77OkPs9lxGMAHcFI4PT2FkQtzsD8jUBfsUh/A5yCCDQiiSsFARbBxHbfyJhXpcYjeLKw3lTXB7Y/2r2UWNWZROIGFXxB2pZYR0Mo6HZkLJ4UPsLigly48gnAyuWxMnLlRZYbmanS4tZ3RwUFeslRRzkAmOflnsiIOc+HuAHQAXytB2ZXDXF+QdZGkxDl6//7oyoPBEWYbgObgfMPgyxdgPmVpUWZEOoP3wcA176RKhJL/omrp4BF8efThIjn8/P3hu8v5ka+IVA5zXVBLwW90Tp8JwYUzsLgVJC/lbgsZVkKhcQpzGMAQWG0A8+W6oEpr8CVfEceROsAS4jiGge8PvlKD4/tuR40NJIsONgdYbK+I4qVgBC7ugCUr4kGWqGRuCxI2l5hCCRmXUlez5EwBvWJc7LbSbYIuSJK9o2tnUea2+KSJvgFMQVcQw8vFzyRVfiIlvWLO3cbD+qrYMaR3myYZxgKfSvMDJeuwL8rcgggrIuyLBwH2fkCk0j2hZFUvwoiYbCMqCU8ziOFwhC86WG1pOIQw9EAqvoYYXiRq6a+SWyfw7vPAIUwnk+OJizA/jfWJCOjhoaudQW6M0NvnWObnzxzq6owGt8E0mIwXkwBL2lpEI1gIklxHsLGx0IQTCL7SV3Byylq9GChTgpcfk0VBXBMIW868ZMo6Xpk5mp4/M4qHMApcD9LsNf1M7nFpZyquUHO9zPM/Y5rWGbZa46prYHLt8bjdScx7o7xD6AmH7v7AOIOr3VbstoN72k4RbL7u5j2nleDrzuzqlBIWkZEyhIHbkqxtHlY2nraw0W8hKMHZL+VuC7yElAvBV+uynQ9eYjYuLiMNVISe1mFnjO6mbcy22r62z7Z+rD5j4RqGMJ52LKsqqZOjtQvfGFSGwcigstf+ymZwBM5yoTgVBFKci0lhI1P5khfJlezDFho1cz1YEbXk2T4OAz2R9kFq3eCpRrLcg1HkDVFW+acc4440VuwzK0TLyV7ysbZ6PxkrpeD7rBiHHStEcoPjzHIrbmfZoFT5bOCBSW71Pzb6wo3wKa4eYYimDiEtohoSVqhPWNZMNRc1KspKEsFf/h0dVVOhHTFjaD2CrRq3UWzw8AgXj35sLWmei922VcTVAOsKsql+0CpK+X91in4lRpjpGnrt65FUdVfdPa4El30zvhFrangYG0Mjrca8M2r07/2Nw6rARTrnVOI2nfLVWhApq3ZnTC+4BuJfV33B67IfB8d/q+wJO1S7XxWBgqdo7AMnDRr00gQxVKYMH5aDJoVTdz9t1vLJCBzaMv+aTrvHQpHc2LqS5SLR67fW4UFHlT2DzRbXo8agqnlh+FxNg9juTn4u+AoLwB4mhST3z8zqM3jv8CnLi0SRV8nN608sxbMe3MEquX1ZqnWpzrWn8waM2P9g05b/IAir3Ra16StZhRPc1xrgEzPZrFU42vpLAQ2tYIRw0fDtG6L6ugWUIVxIqsie8sUrhBZq0JeKtEeY5KuVtZ0psftvV7DTRmWP2bxU/rqUS6e929qAbZplmJeqWocxrJTgvbZ3H/ZgpeiKPJnD00QR2Fw2C/AquSa4AFsJneUXi0Tqie5VU7I137lemJqRbg4R4Dl0hN3rsW2U1f2W+Np9D8x0cD2L8PvLNPFN5J+A+QXzjjxLbldKRvIKphnpg2lBPpJiDo9ho6cseaoPZKS1rYvkxj54sODZJ4grxida/hy0rHojqIkzmJsA1XNebwQGQ1hiHiA/8XV69I2N3OgcOfiP//bNmRMG4dSDxx6Mxh6MQg8CDwK346M+HIOT+VdEvX1z9g9eCum4cHICo5ELXxrKC8pKRSxt0iG9JilnGZL09boTQwQNfgOomX8si+LfJBGOC4cwejwL8Po7Cr/Tch9ruY1OztTSwU45atRWRO1rR1mxbPKeFAVPnePAjaBY+jeCKlK3/6btYzy6DLoNh4EH4z5CcBvM8HvItI9okuhB1b4fMGCwPdzveg5joDBJffamIsUc9pEQUzXARrM+ljYEw7BPNxZQw3JvvXwQ0zE6n/bE1G7QJqbpvpj2EqZ9hCrYsz5iFWyMpjF3T7TDvtM22uM+T0y0e53sRDsM+lg60e71txvtWZ8Qjjefeic2zdS09WLp2SaNtuBZ01wNNbVUN9ItdhibFaSlEZeOxolqKthUZ02qU87SRDnVBQe/AGb3gRAaAwnLHmLB3vENFjoc5pZtunwdhtnf4ho9EGYSljUcYS+Hjqe9N9kJ2PXzwvd9E2a8z2tvL109IVc8Kwvik9s1F0rqL6P2w49XDUDPdGWvvgPgx7n/AVBLAwQUAAAICAAAYE5dvaHK0QgMAABkIAAAEAAAAGxhdW5jaGVyL3N3YXAuanOdWV9z2zYSf/en2LyYZENTipP07qQqN2niTtJp40ycXufG58lA5EqCBQIMAPrPOP4u91jfvd7bvVVf7GYBUCQlOUkv06lFElws9s9vf7uMaoNgrOa5jcZ7gwGYS1Zl5wZGwIzhxjJpoUDQWFaC5ViiuzYw4/mCozZQ1CCYzLHWUDBpQCAUyhiOGoqIS2OZEMxyJTMS/xOT+eoOUALTmq9+03hQCSahYhqev4ZX9RTio5+OXrx/d/zmw7tf3nx4fvLhzfHLoyQFLoBZi7IAwWCGukRba4Qi8u+lUNXcwIh2AXiUwcXqTvMZRxAb6kpVXyBr1R7DYQa5qjjSSQ3mqqaFCFbVFnKEj3XExdoEMPZbPM5gdZdrbiFfsI81NnvQ4X7/N2SML+rpgcRL+P2/XjdBdpSqLBHic1Yy7nZpXlv9E0rFLV/dBblJs9MTUk9avfqP8KfBstLIpaWfFmaMW6gloDGM7zygF/M0A1bTHrLQCJVWU7H6rcSUToaWrLplhBGIng9Bo9UkHUS0urPMQhGxCyatc+671Z2phbtLkfBdoaRc3aF5NhCslvkC9YDCa6CRlmXnRskMTnjj+EJxC4Zs5BTXKYioDUKB7qDZXq6ksTAzMAGNH2uuMY5mJkpSqJhddO/SNd3Pq+7dfMFF8aHSKkfjXsv1dWVVb4m7EyXjvbCbWTCYQDxNYPIsrM9yjcziK2YWcWQW7PDpt1GS1VXBLMbTJCv4HI2NowVekaAgRyCSMnFpnKgbsPoabuC5VSXPTXbJuI0pZF5L+/jwudbs2l2eLJjGwl1/X89mqOMnSZLC0P1XmmQMt5Azmy/gBvxOFibwklnMpLqME3gIpRnD5YILhLhz/zuw7uXbRkMm+AWShhUveioGg2VLLgQ9TGGYjCkeai3B6hpbHWJM4KZ5hFmuCoTJZALR0dujdz9HYb9ZLXMXU8wd/lfNLcYzLjCFglmW9I5C9+EhRFkED9eqVLxw92xZRWOYmeySZPzABZ5cyzy2QdA4nGBmMo2SleunJLRnui0RHXU6UmopuFx6Kd33b+lg7bkoV67jmUzhcsEsnefL/wYD+JXLQl06BJaWX3BdGxh0wCVXGoFyUFs4eAa0ESWZYRz3AITLZGPHMFMaYrrkMIHhGDh8B0/o78OHydqrwUkzGSeb/iMpMAEcA59B/OA0Ovr+l5O/R2njRvrx/MWLoxP3683x+6Of3773z3/+4fVPR9FZxmUu6gJN7IMgScAutLokmS4T4qfDoQ+/PQiPKNqPtFY6JqORe2EE5PTY6bO/7/TKSjrwHJNkvHe7R9hzrAnURiDVNavTBvpCUSgZl1TU0ELF8iWbowMfQuoCtSS7xjmCUdIC1lfwseYwo4tidVcyrVET/GzAatJ6mkpYfK6mCdzsQYhabrEkjDo9G++Bd4Z/cEohmMLiDNQMjqfnmNsMpdUcDcnIyL8UgAY+fYKb2yTxorKqNouYPCZGENGiAZnFCzM6Hzn4y84Vl2sxJzpP3YokJQgbwQJuk3GrIsWxS3Z6YdbZs12jmVzSCu3AQPs8DvaM4K/wFxg1d7umpUePhu0zj4s6vPQURvB4wywaRccgS7w2sdcvyYzSNo5ZCh5/SaWYJXDgf00TUpplQuVM4AtVVkwTAu8w3E5DGcvmrgiKxkp+31ON4izYK6SJk+cibu36Qp1csuo+568DIwXL9BwpoWhPf5HClGzbV6c2qF8yy1KImqpJOUWFk/5OWb6sqwPnerx0EB8nmVWvT45PrOZyHieZRkdU4sHpKDsbzFOIDqKk41MKjR8p/ifgq0k206qMfzw5fpMZJ4TPruMbuEBtuJIjaOLpb/4G2Ztuhedwm4KshUjhUXeXc1VryQRMCGzCeX3NLN67yxHMmDCYQoj+EZyekaxCuaDcShxuKUCcaR0+oYWiQeWCagThOyvW4M1tZnS+hWubOBM10GpUrXMELh3FYVOBAXq4zSg6SBBBoVmwuEjgwWRCT8yCJV+UyYRd3enV3ZbAPfDoOjMZXnFjja8qzj4JaRusmPUsB5Om4pKFTFYuC67dm9Nl6lA9r7XhFzhy63pJzwS5xGdGyao45i6puNMoy5XMmY1PPcDQ/3w6nyW705UJ8TWFbTDY4pZ7dN/LKlyhadOgiRZvI/Kzsw0GJ3cMVRjrFPNWDKsSX6VbozjJBdeEhHG7DdmKtkjuMRkJyVV1vQ6owtgUdrzv/QBrX4V47gFPcwLvClrfpT19oVEjyJk+SWEjM8PjjaxzieD06B2+MeZ9UdE4wREfh/SkrmdgRP/2vAe/7KkUbEncltYQK1v3P56b3eMO8uDnlINAo2KnzTbHK6ugbAqRb5uoKaQkc9ETZDRpuwkRtqwSn8kuqUnOjmRu5XJiXxpz20BDd5MNRbtc02npThr1Oum1CAd6PmBakbf+z/0QSMfyWEJVTFvzK7eLOJCDhMiSs7VGo8QFNoDoKnLvwbZDA0Ilies8uSSwcZYP+6X3oW0y7mjla79Th8sCr7KFLUWUBEmbGJOuC9M6o+47+n3+/NxBPovXbX8941S0+jjdSZPqHCY+HyumDX6FBn1eRCFQ29mfQ0H2oVmdZ0SpnIotufr0CarzdZGlZ52iu+MMPWrLpR+W1FHYx9fJP/xvMLh/rhAmA6u7Hkb4dg8iq69vmk7N2ELV1uduHHjKutuGh5sAt8OIXS40VYqmB1FCfW2UZAbFzFKznSTJrSv1MSbdvVHr/t64v4+UMvny0ydqIpq1eMVt/Di5jca9I9EcaAJ5leEV5q2r1y9h/pbZRQqn0QG6MC7wjEAN5cWoYbQ0yZjL+OY2XfevKC9o1a551wiiRxHcEqjyElVtR3D4dDgcpnDp28NXvAhQmbqesOByPgqhlYKxBVcjOI34XCpNOkUVr9q/Zx18pQAMZlG1TTKreRn7dInUMtoRaD4gRtR3hnnPVrT1KZcrzmRvWxuHCY/vlVrsCK+QjY3vgkcpP3DdCGZG8BzjYQqHw2FbkgNxvwG1bKzVY7XhIgXPq0dA9dd1QiPiNplAObcLj8S9M3UgQaOxSjt2En62FXq6DAbpKdLwXjr4qD1EuhbV1Sds3us6du3jdCKypJYNP+xTNpSEoBskpX+UzfreLG7SEGUHEFvCATtnI9tEoDcs6YQfymzN3bpV9GaLgvWJUlAn3eAcZLvI87dOEd6xxhflMTUdEZmU1dqPOSncemcFQGHQKbvNQJPN0t83AkG+qatKozE7hbcDKOc6Fx0+gJv+YGcX0E5x6KCl227TYVvEKqWIyLss957d3d4hatWy3/RSiaJmldzSbXupEv6opsQie7PDIOYzZTMI6xTHjl7hdWK7YXboA/3cbRU2jQPzeOBacf9K2/UUXDeB3TDPRv8UhMr7fXjBNZUcRWHkkpIW7ljRGWR74AvzBEekIxrmcjmPxu72AkWF+i0nmOgMMMe9PmBthi3GP93ZY9thb8y7TvjxOPnDxX4w+Oz3FZolwtvXLwF991fDCGoZpmJCoIdrmSNUWLtxfb5gco46Cb3Rl3x1n1L0JpOybniGz4euQff3NyxMtas7JN7f93Pt/ntJd+vBgD6hsNpq7Hz5MhGBZp7XFa73ftCKokmTtF7UVCNbtpSuM2M/IDc9g8Mn8A08/nY4hG/g0XA47AYphHnon2geGvLe33nkR6R/0JGCcWNwPUoWfLq681PM9lPYHnxdAvViWtdS+pj+/8J2jVf9No5SLW0KfGu6ZLNgUNZrNK0kjTRm6wzhtr9CGDeB+qqy26DiOICfyazpJ5i72VDyHiH3j3ZM+VpluyYLoLJlMo2ma7L+8XdVWTLd5roNv4Z53fgeCQ0Qbghp8ow+xxH3/mpEGQyaT3jrT7rsAnMXfOXqXyUaUBXVEZN0qAfKC5h8nixTm4wCLdLibBdt7rY6oRvxxN1U7NLPV/EKU+cdpudu3H3qqHqBluWLJgTWDLol0KQflcs8q6XGWbxpLkfQSlXUAjO8qpS2PvB8bK5jLHUz4dSVUKpkZOXQCfkekOixF+P693B6pucXp4dnbcl3JXjz6daos/E2qyqUu5rU/mhsQ1wYOx+4hMmEmlM1bFg4aRd6KMfEXS/2DxltfxD7H1BLAQIUABQAAAgIAABgTl2GFZ0xwAEAABIDAAANAAAAAAAAAAAAAAAAAAAAAABtYW5pZmVzdC5qc29uUEsBAhQAFAAACAgAAGBOXTjizGN0BAAAhgkAAAcAAAAAAAAAAAAAAAAA6wEAAG1haW4uanNQSwECFAAUAAAICAAAYE5dIAv/b7oAAAAgAQAADAAAAAAAAAAAAAAAAACEBgAAcGFja2FnZS5qc29uUEsBAhQAFAAACAgAAGBOXfCgNlSOAAAAvQAAAAoAAAAAAAAAAAAAAAAAaAcAAHVwZGF0ZXIuanNQSwECFAAUAAAICAAAYE5dFxI9qVQHAADAEQAAEAAAAAAAAAAAAAAAAAAeCAAAbGF1bmNoZXIvYm9vdC5qc1BLAQIUABQAAAgIAABgTl0lEUmYnREAALgyAAATAAAAAAAAAAAAAAAAAKAPAABsYXVuY2hlci91cGRhdGVyLmpzUEsBAhQAFAAACAgAAGBOXZwmhDUFHQAAflYAABMAAAAAAAAAAAAAAAAAbiEAAGxhdW5jaGVyL3JlYnVpbGQuanNQSwECFAAUAAAICAAAYE5dl5FSACgIAAA/FgAADwAAAAAAAAAAAAAAAACkPgAAbGF1bmNoZXIvemlwLmpzUEsBAhQAFAAACAgAAGBOXb2hytEIDAAAZCAAABAAAAAAAAAAAAAAAAAA+UYAAGxhdW5jaGVyL3N3YXAuanNQSwUGAAAAAAkACQAdAgAAL1MAAAAA"};
function lanceurAttach(ctx, getWin, ud) {
  const want = LANCEUR_EMBED.version, cmpV = LREBUILD.cmp;
  const R = LREBUILD.createRebuilder({
    app, zip: LZIP, userData: ud(), embed: LANCEUR_EMBED, minVersion: want,
    activeCore: () => ({ dir: ctx.boot.dir, version: ctx.boot.version && ctx.boot.version !== 'bundled' ? ctx.boot.version : ((ctx.updater.info() || {}).bundledVersion || want) }),
    bundledDir: () => ctx.bundledDir,
    emit: (type, data) => { try { const w = getWin(); if (w && !w.isDestroyed()) w.webContents.send('launcher-event', { type, data }); } catch {} }
  });
  ctx.rebuilder = R;
  let plan = null;                                              // résultat du dernier essai de remplacement des fichiers de l'exe
  if (!ctx.launcher) ctx.launcher = { version: String(ctx.launcherVersion), mode: 'ancien' };

  // Remplace, en mémoire, le système de mise à jour de l'ancien lanceur par celui du lanceur reconstruit
  const attach = () => {
    if (ctx.launcher.mode !== 'ancien') return false;
    const P = R.loadPayload(); if (!P || cmpV(P.version, want) < 0) return false;
    try { P.boot.upgradeContext(ctx, { app, dir: path.join(P.dir, 'launcher') }); R.log('Lanceur ' + P.version + ' en service (lu depuis les données d\'AI Hub)'); return true; }
    catch (e) { R.log('⚠ lanceur reconstruit non attaché : ' + e.message); return false; }
  };
  const maintain = () => { if (ctx.launcher.mode === 'virtuel') plan = R.stageSwap(); return plan; };
  const rebuild = async (opts) => { const r = await R.rebuild(opts); if (r && r.ok) { attach(); maintain(); } return r; };

  try { attach(); if (ctx.launcher.mode !== 'ancien') maintain(); } catch (e) { try { R.log('⚠ ' + e.message); } catch {} }
  try {                                                          // aucun lanceur assez récent (en service ou déjà reconstruit) : reconstruction automatique, sans bloquer le démarrage
    const cur = R.readCurrent(), have = [ctx.launcher.mode !== 'ancien' ? ctx.launcher.version : '0.0.0', cur && R.verifyInstalled(cur) ? cur.version : '0.0.0'].reduce((a, b) => (cmpV(a, b) >= 0 ? a : b));
    if (cmpV(have, want) < 0) app.whenReady().then(() => setTimeout(() => { rebuild({ auto: true }); }, 2500));
  } catch {}

  ipcMain.handle('launcher:info', () => Object.assign(R.status(), { version: ctx.launcher.version, mode: ctx.launcher.mode, exeVersion: ctx.launcher.exeVersion || (ctx.launcher.mode === 'ancien' ? ctx.launcher.version : null), swapPlan: plan, logFile: path.join(ud(), 'launcher', 'rebuild.log') }));
  ipcMain.handle('launcher:rebuild', () => rebuild({}));
  ipcMain.handle('launcher:pick', async () => {
    const r = await dialog.showOpenDialog(getWin(), { filters: [{ name: 'ZIP du lanceur AI Hub', extensions: ['zip'] }], properties: ['openFile'] });
    if (r.canceled || !r.filePaths[0]) return { ok: false, cancelled: true };
    return rebuild({ file: r.filePaths[0] });
  });
  ipcMain.handle('launcher:restart', () => { ctx.relaunch(); return { ok: true }; });
}

// </LANCEUR>

// 4.5.0 : écriture atomique au niveau du module (visible partout, y compris dans les gestionnaires IPC)
function atomicWrite(f, data, enc) { const t = f + '.' + process.pid + '.tmp'; try { fs.writeFileSync(t, data, enc); fs.renameSync(t, f); } catch (e) { try { fs.unlinkSync(t); } catch {} fs.writeFileSync(f, data, enc); } }
module.exports = function start(ctx0) {
const ctx = normalizeCtx(ctx0);
let win;
// (Le dossier de données fixe est défini par le lanceur main.js)
const ud = () => app.getPath('userData');
const STATE = () => path.join(ud(), 'ai-hub-state.json');
const BK = () => path.join(ud(), 'backups');
let lastBk = 0;

// Thème enregistré (lu avant d'ouvrir la fenêtre pour éviter un flash blanc/noir au démarrage)
const BG = { dark: '#121214', light: '#FFFFFF' };
function savedTheme() { try { const t = JSON.parse(fs.readFileSync(STATE(), 'utf8')).settings.theme; return ['light', 'dark'].includes(t) ? t : 'system'; } catch { return 'system'; } }
if (process.platform === 'win32') { try { app.setAppUserModelId('com.aihub.app'); } catch {} }   // nécessaire pour les notifications Windows

// Retire le drapeau « automatisé » de Chromium (une des choses que regarde la page de connexion Google)
try { app.commandLine.appendSwitch('disable-blink-features', 'AutomationControlled'); } catch {}

// Les sites ne peuvent pas envoyer leurs propres notifications ni demander la position : AI Hub centralise les notifications
const DENY = new Set(['notifications', 'geolocation', 'midi', 'midiSysex']);
app.on('session-created', (s) => {
  try {
    s.setPermissionRequestHandler((_wc, perm, cb) => cb(!DENY.has(perm)));
    s.setPermissionCheckHandler((_wc, perm) => !DENY.has(perm));
  } catch {}
});

// Connexion Google ("ce navigateur ou cette application ne sont peut-être pas sécurisés") : on retire toute trace d'Electron
// de l'identité du navigateur, dans les en-têtes réseau (User-Agent + sec-ch-ua) ET dans les fenêtres de connexion (popups).
const CHROME_FULL = process.versions.chrome || '130.0.0.0', CHROME_MAJOR = CHROME_FULL.split('.')[0];
const cleanUA = (ua) => String(ua || '').replace(/\s?Electron\/\S+/, '').replace(/\s?ai-hub\/\S+/, '').replace(/\s?AI Hub\/\S+/i, '');
// Client Hints d'un vrai Google Chrome (Electron n'annonce que « Chromium » + « Electron », ce que Google refuse)
const CH_BRANDS = '"Chromium";v="' + CHROME_MAJOR + '", "Google Chrome";v="' + CHROME_MAJOR + '", "Not?A_Brand";v="99"';
const CH_FULL = '"Chromium";v="' + CHROME_FULL + '", "Google Chrome";v="' + CHROME_FULL + '", "Not?A_Brand";v="99.0.0.0"';
const GOOGLE_HOST = /(^|\.)(google\.[a-z.]+|gstatic\.com|googleapis\.com|googleusercontent\.com|youtube\.com)$/i;
app.on('session-created', (s) => {
  try {
    s.setUserAgent(cleanUA(s.getUserAgent()));
    s.webRequest.onBeforeSendHeaders((d, cb) => {
      const h = d.requestHeaders; let host = ''; try { host = new URL(d.url).hostname; } catch {}
      let hasCh = false, hasFull = false;
      for (const k of Object.keys(h)) {
        if (/^user-agent$/i.test(k)) h[k] = cleanUA(h[k]);
        else if (/^sec-ch-ua$/i.test(k)) { h[k] = CH_BRANDS; hasCh = true; }
        else if (/^sec-ch-ua-full-version-list$/i.test(k)) { h[k] = CH_FULL; hasFull = true; }
      }
      if (GOOGLE_HOST.test(host) && /^https:/i.test(d.url)) { if (!hasCh) h['sec-ch-ua'] = CH_BRANDS; if (!hasFull) h['sec-ch-ua-full-version-list'] = CH_FULL; }
      cb({ requestHeaders: h });
    });
  } catch {}
});
app.on('web-contents-created', (_e, wc) => { try { wc.setUserAgent(cleanUA(wc.getUserAgent())); } catch {} });

function create() {
  nativeTheme.themeSource = savedTheme();
  const wa = (() => { try { return screen.getPrimaryDisplay().workArea; } catch { return { x: 0, y: 0, width: 1440, height: 900 }; } })();
  const ww = Math.min(1440, wa.width), wh = Math.min(900, wa.height);   // la fenêtre ne dépasse plus l'écran (barre des tâches)
  win = new BrowserWindow({
    x: wa.x + Math.round((wa.width - ww) / 2), y: wa.y + Math.round((wa.height - wh) / 2), width: ww, height: wh, minWidth: Math.min(900, wa.width), minHeight: Math.min(560, wa.height), backgroundColor: nativeTheme.shouldUseDarkColors ? BG.dark : BG.light, autoHideMenuBar: true,
    icon: fs.existsSync(path.join(__dirname, 'icon.ico')) ? path.join(__dirname, 'icon.ico') : undefined,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), webviewTag: true, contextIsolation: true }
  });
  if (wa.width < 1700 || wa.height < 1000) { try { win.maximize(); } catch {} }
  // 7.0 (V9) : la fenêtre reste dans la zone utile si l'écran ou la barre des tâches change (résolution, barre masquée / déplacée, écran débranché)
  const fitWin = () => { try {
    if (!win || win.isDestroyed() || win.isMaximized() || win.isFullScreen() || win.isMinimized()) return;
    const b = win.getBounds(), w = screen.getDisplayMatching(b).workArea;
    const nw = Math.min(b.width, w.width), nh = Math.min(b.height, w.height);
    const nx = Math.max(w.x, Math.min(b.x, w.x + w.width - nw)), ny = Math.max(w.y, Math.min(b.y, w.y + w.height - nh));
    if (nx !== b.x || ny !== b.y || nw !== b.width || nh !== b.height) win.setBounds({ x: nx, y: ny, width: nw, height: nh });
  } catch {} };
  try { screen.on('display-metrics-changed', fitWin); screen.on('display-removed', fitWin); win.on('unmaximize', () => setTimeout(fitWin, 60)); win.on('moved', fitWin); } catch {}
  win.loadFile(path.join(__dirname, 'index.html'));
  nativeTheme.on('updated', () => { try { win.setBackgroundColor(nativeTheme.shouldUseDarkColors ? BG.dark : BG.light); } catch {} });
  win.webContents.on('render-process-gone', (_e, d) => { ctx.fatal('interface plantée : ' + (d && d.reason)); });
}

// ---------- 2.4.0 : détection par le réseau + historique local des conversations ----------
const NET_HOSTS = /(^|\.)(claude\.ai|chatgpt\.com|openai\.com|gemini\.google\.com)$/;
const COMPLETION = /\/(completion|backend-api\/(f\/)?conversation|StreamGenerate)(\/|$)/i;
app.on('session-created', (s) => {
  try {
    s.webRequest.onCompleted((d) => {
      try {
        if (!win || win.isDestroyed() || !d.webContentsId) return;
        const u = new URL(d.url);
        if (!NET_HOSTS.test(u.hostname)) return;
        const isComp = d.method === 'POST' && COMPLETION.test(u.pathname);
        const bad = [429, 503, 529].includes(d.statusCode) && (isComp || /\/(api|backend-api)\//.test(u.pathname));
        if (!isComp && !bad) return;
        const h = d.responseHeaders || {};
        const pick = (n) => { const k = Object.keys(h).find((x) => x.toLowerCase() === n); return k ? String([].concat(h[k])[0]) : null; };
        let until = 0; const ra = pick('retry-after');
        if (ra) { const n = Number(ra); until = isFinite(n) ? Date.now() + n * 1000 : (Date.parse(ra) || 0); }
        const quota = {};
        for (const k of Object.keys(h)) if (/ratelimit|usage|quota/i.test(k)) quota[k.toLowerCase()] = String([].concat(h[k])[0]).slice(0, 120);
        win.webContents.send('net-event', { wc: d.webContentsId, status: d.statusCode, host: u.hostname, completion: isComp, until, quota, ts: Date.now() });
      } catch {}
    });
  } catch {}
});

// Historique local : un fichier JSON (300 conversations max), recherche plein texte simple
const CV = () => path.join(ud(), 'conversations.json');
let cvCache = null, cvT = null;
const cvLoad = () => cvCache || (cvCache = (() => { try { const j = JSON.parse(fs.readFileSync(CV(), 'utf8')); return Array.isArray(j) ? j : []; } catch { return []; } })());
const cvWrite = () => { try { fs.writeFileSync(CV() + '.tmp', JSON.stringify(cvCache || [])); fs.renameSync(CV() + '.tmp', CV()); } catch {} };
const cvSave = () => { clearTimeout(cvT); cvT = setTimeout(cvWrite, 1500); };
app.on('before-quit', () => { if (cvCache) cvWrite(); });
ipcMain.handle('conv:put', (_e, c) => {
  if (!c || !c.key || !c.text) return false;
  const l = cvLoad(), key = String(c.key).slice(0, 300), i = l.findIndex((x) => x.key === key);
  if (i >= 0) l.splice(i, 1);
  l.unshift({ key, acc: c.acc, platform: c.platform, name: c.name, url: String(c.url || '').slice(0, 500), title: String(c.title || '').slice(0, 160), ts: Date.now(), text: String(c.text).slice(-60000) });
  if (l.length > 300) l.length = 300;
  cvSave(); return true;
});
ipcMain.handle('conv:search', (_e, q) => {
  const terms = String(q || '').toLowerCase().split(/\s+/).filter(Boolean).slice(0, 6);
  if (!terms.length) return [];
  const out = [];
  for (const c of cvLoad()) {
    const t = c.text.toLowerCase(), ti = (c.title || '').toLowerCase();
    if (!terms.every((w) => t.includes(w) || ti.includes(w))) continue;
    let score = 0; for (const w of terms) { score += (ti.includes(w) ? 5 : 0) + Math.min(10, t.split(w).length - 1); }
    const p = Math.max(0, t.indexOf(terms[0]) - 60);
    out.push({ score, key: c.key, acc: c.acc, platform: c.platform, name: c.name, url: c.url, title: c.title, ts: c.ts, snip: c.text.slice(p, p + 180).replace(/\s+/g, ' ') });
  }
  return out.sort((a, b) => b.score - a.score || b.ts - a.ts).slice(0, 20);
});
ipcMain.handle('conv:count', () => cvLoad().length);
ipcMain.handle('conv:clear', () => { cvCache = []; cvWrite(); return true; });

ipcMain.handle('copy', (_e, t) => clipboard.writeText(t));

// ---------- 2.6.6 : enregistrement direct d'un fichier dans « Téléchargements » ----------
ipcMain.handle('save:file', async (_e, name, b64) => {
  try {
    const dir = app.getPath('downloads');
    let base = String(name || 'fichier').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/^\.+/, '').slice(0, 150) || 'fichier';
    const ext = path.extname(base), stem = base.slice(0, base.length - ext.length);
    let p = path.join(dir, base), n = 1;
    while (fs.existsSync(p) && n < 500) { p = path.join(dir, stem + ' (' + n + ')' + ext); n++; }
    const buf = Buffer.from(String(b64 || ''), 'base64');
    if (buf.length > 500 * 1048576) return { ok: false, err: 'fichier trop gros' };
    fs.writeFileSync(p, buf);
    return { ok: true, path: p, name: path.basename(p) };
  } catch (x) { return { ok: false, err: String((x && x.message) || x) }; }
});
ipcMain.handle('show:item', (_e, p) => {
  try { const dir = path.resolve(app.getPath('downloads')), r = path.resolve(String(p || '')); if (r.startsWith(dir + path.sep)) { shell.showItemInFolder(r); return true; } } catch {}
  return false;
});
ipcMain.handle('clear', (_e, p) => session.fromPartition(p).clearStorageData());
ipcMain.handle('wvpreload', () => pathToFileURL(path.join(__dirname, 'webview-preload.js')).href);
// Notifications Windows : un clic ramène la fenêtre au premier plan et ouvre le compte concerné
const liveNotifs = new Set();
ipcMain.handle('notify', (_e, t, b, accId) => {
  if (!Notification.isSupported()) return { ok: false, error: 'unsupported' };
  try {
    const n = new Notification({ title: String(t || 'AI Hub'), body: String(b || '') });
    liveNotifs.add(n);                                   // garder une référence (sinon le clic peut être perdu)
    n.on('close', () => liveNotifs.delete(n));
    n.on('failed', () => liveNotifs.delete(n));
    n.on('click', () => {
      liveNotifs.delete(n);
      if (!win) return;
      if (win.isMinimized()) win.restore();
      win.show(); win.focus();
      win.webContents.send('notif-click', accId || null);
    });
    n.show();
    return { ok: true };
  } catch (e) { return { ok: false, error: e.message }; }
});
// 2.8.0 : mode local — choix du dossier de travail du projet (le moteur est dans la section 3.0.0, en bas de ce fichier)
ipcMain.handle('local:pick', async (_e, cur) => {
  try {
    const r = await dialog.showOpenDialog(win, { title: 'Choisir le dossier de travail (mode local)', defaultPath: cur || undefined, properties: ['openDirectory', 'createDirectory'] });
    if (r.canceled || !r.filePaths || !r.filePaths[0]) return { cancelled: true };
    const p = r.filePaths[0];
    return { ok: true, path: p, name: path.basename(p) || p };
  } catch (x) { return { ok: false, error: String(x && x.message || x) }; }
});
ipcMain.handle('local:check', async (_e, p) => { try { return { ok: fs.statSync(String(p || '')).isDirectory() }; } catch { return { ok: false }; } });
ipcMain.handle('theme:set', (_e, t) => { nativeTheme.themeSource = ['light', 'dark'].includes(t) ? t : 'system'; return nativeTheme.shouldUseDarkColors; });

// Export de tous les comptes : liste + cookies de chaque session, chiffré (AES-256-GCM) si mot de passe
ipcMain.handle('export', async (_e, { state, partitions, pass }) => {
  const cookies = {};
  for (const p of partitions) cookies[p] = await session.fromPartition(p).cookies.get({});
  const data = JSON.stringify({ app: 'ai-hub', version: app.getVersion(), v: 1, exportedAt: new Date().toISOString(), state, cookies });
  let out = data;
  if (pass) {
    const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', crypto.scryptSync(pass, salt, 32), iv);
    const enc = Buffer.concat([c.update(data, 'utf8'), c.final()]);
    out = JSON.stringify({ app: 'ai-hub', version: app.getVersion(), enc: 1, salt: salt.toString('base64'), iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: enc.toString('base64') });
  }
  const r = await dialog.showSaveDialog(win, { defaultPath: 'ai-hub-comptes-' + new Date().toISOString().slice(0, 10) + '.json' });
  if (r.canceled) return { ok: false };
  fs.writeFileSync(r.filePath, out);
  return { ok: true, path: r.filePath, encrypted: !!pass };
});

ipcMain.handle('import', async (_e, pass) => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'JSON', extensions: ['json'] }], properties: ['openFile'] });
  if (r.canceled) return { ok: false };
  let j = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8'));
  const ver = j.version;
  if (j.app && j.app !== 'ai-hub') return { ok: false, error: 'Ce fichier ne vient pas de AI Hub' };
  if (j.enc) {
    try {
      const d = crypto.createDecipheriv('aes-256-gcm', crypto.scryptSync(pass || '', Buffer.from(j.salt, 'base64'), 32), Buffer.from(j.iv, 'base64'));
      d.setAuthTag(Buffer.from(j.tag, 'base64'));
      j = JSON.parse(Buffer.concat([d.update(Buffer.from(j.data, 'base64')), d.final()]).toString('utf8'));
    } catch { return { ok: false, error: 'Mot de passe incorrect ou fichier corrompu' }; }
  }
  let n = 0;
  for (const [p, list] of Object.entries(j.cookies || {})) for (const c of list) {
    try {
      const o = { url: `http${c.secure ? 's' : ''}://${c.domain.replace(/^\./, '')}${c.path}`, name: c.name, value: c.value, path: c.path, secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite, expirationDate: c.expirationDate };
      if (!c.hostOnly) o.domain = c.domain;
      await session.fromPartition(p).cookies.set(o); n++;
    } catch {}
  }
  return { ok: true, state: j.state, cookies: n, version: ver || j.version, current: app.getVersion() };
});

// Sauvegarde de l'état (comptes, code, détections) dans un fichier avec copies de secours
const count = (s) => { try { return (JSON.parse(s).accs || []).length; } catch { return -1; } };
ipcMain.handle('state:load', () => {
  const files = [STATE()];
  try { files.push(...fs.readdirSync(BK()).sort().reverse().map((f) => path.join(BK(), f))); } catch {}
  for (const f of files) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch {} }
  return null;
});
ipcMain.handle('state:save', (_e, json) => {
  fs.mkdirSync(BK(), { recursive: true });
  try {
    const old = fs.readFileSync(STATE(), 'utf8');
    if (old !== json && (count(json) < count(old) || Date.now() - lastBk > 60000)) {
      fs.writeFileSync(path.join(BK(), 'state-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json'), old); lastBk = Date.now();
      fs.readdirSync(BK()).sort().reverse().slice(40).forEach((f) => fs.unlinkSync(path.join(BK(), f)));
    }
  } catch {}
  fs.writeFileSync(STATE() + '.tmp', json); fs.renameSync(STATE() + '.tmp', STATE());
  return true;
});
// Sessions qui existent sur le disque mais ne sont plus dans la liste des comptes
ipcMain.handle('orphans', async (_e, known) => {
  let names = []; try { names = fs.readdirSync(path.join(ud(), 'Partitions')); } catch {}
  const out = [];
  for (const n of names) {
    if (!/^a\d+$/.test(n) || known.includes(n)) continue;
    const ck = await session.fromPartition('persist:' + n).cookies.get({});
    if (ck.length) out.push({ id: n, domains: [...new Set(ck.map((c) => c.domain.replace(/^\./, '')))] });
  }
  return out;
});
ipcMain.handle('open-data', () => shell.openPath(ud()));


// ---------- Résumé par Gemini (appel fait ici, dans le processus principal : pas de souci CORS) ----------
ipcMain.handle('gemini', async (_e, { key, model, system, prompt }) => {
  if (!key) return { ok: false, error: 'Clé Gemini absente' };
  const m = String(model || 'gemini-flash-latest').replace(/[^\w.\-]/g, '');
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), 90000);
  try {
    const r = await fetch((process.env.AIHUB_GEMINI_URL || 'https://generativelanguage.googleapis.com/v1beta/models/') + m + ':generateContent', {
      method: 'POST', signal: ac.signal, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ systemInstruction: system ? { parts: [{ text: system }] } : undefined, contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.2, maxOutputTokens: 8192 } })
    });
    const j = await r.json().catch(() => null);
    if (!r.ok) return { ok: false, status: r.status, error: (j && j.error && j.error.message) || 'HTTP ' + r.status };
    const c = j && j.candidates && j.candidates[0];
    const text = ((c && c.content && c.content.parts) || []).map((p) => p.text || '').join('').trim();
    if (!text) return { ok: false, error: 'Réponse vide (' + ((c && c.finishReason) || (j && j.promptFeedback && j.promptFeedback.blockReason) || '?') + ')' };
    return { ok: true, text };
  } catch (e) { return { ok: false, error: e.name === 'AbortError' ? 'Délai dépassé (90 s)' : e.message }; }
  finally { clearTimeout(to); }
});

// ---------- Mises à jour (la logique est dans updater.js, testée à part) ----------
const backupState = (ver) => {                       // copie des données AVANT d'installer : on ne perd rien
  try { fs.mkdirSync(BK(), { recursive: true }); fs.copyFileSync(STATE(), path.join(BK(), 'state-' + new Date().toISOString().replace(/[:.]/g, '-') + '-avant-maj-' + ver + '.json')); } catch {}
};
ipcMain.handle('upd:info', () => Object.assign(ctx.updater.info(), { active: ctx.boot.version, rolledBack: ctx.boot.rolledBack, dataDir: ud(), launcher: ctx.launcher || null }));
ipcMain.handle('upd:apply', async () => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'Mise à jour AI Hub', extensions: ['aihubupdate', 'json'] }], properties: ['openFile'] });
  if (r.canceled) return { ok: false, cancelled: true };
  try { return ctx.updater.install(ctx.updater.readPackage(r.filePaths[0]), { beforeInstall: backupState }); }
  catch (e) { return { ok: false, error: 'Fichier illisible : ' + e.message }; }
});
ipcMain.handle('upd:revert', (_e, to) => ctx.updater.revert(to));
ipcMain.handle('upd:healthy', () => ctx.updater.confirm());
// ===== 4.1.0 : mise à jour depuis le dépôt GitHub (même source et même logique que l'installeur) =====
// Le paquet le plus récent à la racine de github.com/XeroxYTB3/ai_hub est téléchargé, vérifié (sha256), puis installé par le lanceur
// exactement comme un fichier choisi à la main (copie de sauvegarde avant, retour arrière automatique si le démarrage échoue).
const GH = { owner: 'XeroxYTB3', repo: 'ai_hub', setup: 'AI-Hub-Setup.exe' };
const GH_RAW = (name) => 'https://raw.githubusercontent.com/' + GH.owner + '/' + GH.repo + '/HEAD/' + encodeURIComponent(name);
const PKG_RE = /^ai-hub-update-(\d+)[._](\d+)[._](\d+)\.aihubupdate$/i;        // accepte 4_0_0 comme 3.9.0 (les deux existent dans le dépôt)
const verCmp = (a, b) => { for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] > b[i] ? 1 : -1; return 0; };
const verOf = (s) => { const m = /(\d+)[._](\d+)[._](\d+)/.exec(String(s || '')); return m ? [+m[1], +m[2], +m[3]] : null; };
function pickLatest(names) {
  let best = null;
  for (const n of names) { const m = PKG_RE.exec(String(n)); if (!m) continue; const v = [+m[1], +m[2], +m[3]]; if (!best || verCmp(v, best.v) > 0) best = { name: String(n), v, version: v.join('.') }; }
  return best;
}
async function ghGet(url, ms, asBuf) {
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), ms || 20000);
  try {
    const r = await fetch(url, { signal: ac.signal, redirect: 'follow', headers: { 'User-Agent': 'AI-Hub-Updater', 'Accept': 'application/vnd.github+json, */*' } });
    if (!r.ok) { const e = new Error('HTTP ' + r.status); e.status = r.status; throw e; }
    return asBuf ? Buffer.from(await r.arrayBuffer()) : await r.text();
  } catch (e) { if (e.name === 'AbortError') throw new Error('délai dépassé'); throw e; }
  finally { clearTimeout(to); }
}
async function ghLatest() {                                   // { name, version, v, hasSetup }
  let names = [], setup = false, lastErr = '';
  try { const j = JSON.parse(await ghGet('https://api.github.com/repos/' + GH.owner + '/' + GH.repo + '/contents/', 15000));
    if (Array.isArray(j)) { names = j.filter((f) => f && f.type === 'file').map((f) => f.name); setup = names.includes(GH.setup); } }
  catch (e) { lastErr = e.message; }
  if (!pickLatest(names)) {                                    // repli : la page du dépôt (si l'API GitHub est limitée ou bloquée)
    try { const h = await ghGet('https://github.com/' + GH.owner + '/' + GH.repo, 15000);
      names = [...new Set(h.match(/ai-hub-update-\d+[._]\d+[._]\d+\.aihubupdate/gi) || [])]; setup = setup || h.includes(GH.setup); }
    catch (e) { lastErr = lastErr || e.message; }
  }
  const best = pickLatest(names);
  if (!best) throw new Error(lastErr ? 'dépôt injoignable (' + lastErr + ')' : 'aucune mise à jour trouvée dans le dépôt');
  best.hasSetup = setup; return best;
}
const curVersion = () => { let i = {}; try { i = ctx.updater.info() || {}; } catch {} return verOf(i.current) || verOf(ctx.boot && ctx.boot.version) || verOf(i.launcherVersion) || [0, 0, 0]; };
async function ghPackage(name) {                               // télécharge + vérifie, écrit dans un fichier temporaire
  const txt = await ghGet(GH_RAW(name), 90000);
  let pkg; try { pkg = JSON.parse(txt); } catch { throw new Error('paquet illisible'); }
  if (!pkg || pkg.app !== 'ai-hub-update' || !pkg.files) throw new Error('ce n\'est pas un paquet AI Hub');
  const core = ['main-core.js', 'preload.js', 'webview-preload.js', 'index.html'];
  for (const f of core) { const e = pkg.files[f]; if (!e || typeof e.content !== 'string') throw new Error('paquet incomplet (' + f + ')');
    if (e.sha256 && crypto.createHash('sha256').update(e.content, 'utf8').digest('hex') !== e.sha256) throw new Error('téléchargement corrompu (' + f + ')'); }
  const file = path.join(app.getPath('temp'), 'ai-hub-' + name);
  fs.writeFileSync(file, txt, 'utf8'); return file;
}
ipcMain.handle('upd:check', async () => {
  try { const l = await ghLatest(), cur = curVersion();
    return { ok: true, current: cur.join('.'), latest: l.version, name: l.name, newer: verCmp(l.v, cur) > 0, hasSetup: !!l.hasSetup, repo: GH.owner + '/' + GH.repo };
  } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
});
ipcMain.handle('upd:fetch', async () => {                      // le nom du paquet n'est jamais fourni par la page : on le relit dans le dépôt
  let file = null;
  try { const l = await ghLatest(), cur = curVersion();
    if (verCmp(l.v, cur) <= 0) return { ok: true, uptodate: true, version: cur.join('.') };
    file = await ghPackage(l.name);
    const r = ctx.updater.install(ctx.updater.readPackage(file), { beforeInstall: backupState });
    if (r && r.ok === false) return Object.assign({ launcherTooOld: /lanceur/i.test(String(r.error || '')) }, r);
    return r;
  } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  finally { try { if (file) fs.unlinkSync(file); } catch {} }
});
ipcMain.handle('upd:setup', async () => {                      // dernier recours : relance l'installeur du dépôt (comptes, scripts et réglages restent dans le dossier de données)
  try { const buf = await ghGet(GH_RAW(GH.setup), 120000, true);
    if (buf.length < 100000 || buf[0] !== 0x4d || buf[1] !== 0x5a) throw new Error('installeur invalide');
    const file = path.join(app.getPath('temp'), 'AI-Hub-Setup.exe'); fs.writeFileSync(file, buf);
    const err = await shell.openPath(file); if (err) throw new Error(err);
    setTimeout(() => { try { app.quit(); } catch {} }, 1500);
    return { ok: true };
  } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
});
ipcMain.handle('upd:fail', (_e, reason) => ctx.fatal('interface : ' + String(reason).slice(0, 200)));
ipcMain.handle('relaunch', () => { ctx.relaunch(); });
// ---------- 2.5.4 : export du logiciel complet en ZIP (mode développeur) ----------
// <PACK>
const zlib = require('zlib');
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC_T[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
function makeZip(entries) {                       // entries : [{ name, data: Buffer, mtime: Date }]
  const parts = [], central = []; let off = 0;
  for (const e of entries) {
    const name = Buffer.from(e.name, 'utf8'), raw = e.data, def = zlib.deflateRawSync(raw), useDef = def.length < raw.length;
    const body = useDef ? def : raw, method = useDef ? 8 : 0, crc = crc32(raw), d = e.mtime || new Date();
    const dt = (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF, tm = ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xFFFF;
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(method, 8); lh.writeUInt16LE(tm, 10); lh.writeUInt16LE(dt, 12);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(name.length, 26);
    parts.push(lh, name, body);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(method, 10); ch.writeUInt16LE(tm, 12); ch.writeUInt16LE(dt, 14);
    ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(body.length, 20); ch.writeUInt32LE(raw.length, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(off, 42);
    central.push(ch, name);
    off += 30 + name.length + body.length;
  }
  const cd = Buffer.concat(central), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, end]);
}
const PACK_SKIP = /^(node_modules|\.git|dist|out|release)$/i;
function packWalk(root, rel, map, lim) {
  let names; try { names = fs.readdirSync(path.join(root, rel)); } catch { return; }
  for (const n of names) {
    const r = rel ? rel + '/' + n : n, full = path.join(root, r);
    let st; try { st = fs.statSync(full); } catch { continue; }
    if (st.isDirectory()) { if (!PACK_SKIP.test(n)) packWalk(root, r, map, lim); continue; }
    if (!st.isFile() || st.size > 40 * 1048576) continue;
    if (lim.n >= 5000 || lim.bytes + st.size > 300 * 1048576) throw new Error('logiciel trop gros pour le ZIP (plus de 5000 fichiers ou 300 Mo)');
    map.set(r, { name: r, data: fs.readFileSync(full), mtime: st.mtime }); lim.n++; lim.bytes += st.size;
  }
}
function packApp(ver, appRoot, activeDir) {
  const map = new Map(), lim = { n: 0, bytes: 0 };
  packWalk(appRoot, '', map, lim);                                                  // lanceur + fichiers d'origine
  if (path.resolve(activeDir) !== path.resolve(appRoot)) packWalk(activeDir, '', map, lim);   // version active : remplace les fichiers du même nom
  const core = ['main-core.js', 'preload.js', 'webview-preload.js', 'index.html'];
  if (core.every((f) => map.has(f))) {                                              // paquet de mise à jour prêt à réinstaller
    const files = {};
    for (const f of core) { const c = map.get(f).data.toString('utf8'); files[f] = { sha256: crypto.createHash('sha256').update(c, 'utf8').digest('hex'), content: c }; }
    map.set('ai-hub-update-' + ver + '.aihubupdate', { name: 'ai-hub-update-' + ver + '.aihubupdate', data: Buffer.from(JSON.stringify({ app: 'ai-hub-update', format: 1, version: ver, notes: 'Export complet du logiciel', createdAt: new Date().toISOString(), requiresLauncher: null, files }), 'utf8') });
  }
  map.set('LISEZMOI-EXPORT.txt', { name: 'LISEZMOI-EXPORT.txt', data: Buffer.from(
    'AI Hub - export du logiciel\r\nVersion : ' + ver + '\r\nCréé le : ' + new Date().toLocaleString('fr-FR') + '\r\n\r\n' +
    'Contenu : les fichiers du logiciel dans leur état actuel (version active par-dessus les fichiers du lanceur).\r\n' +
    'Ne contient PAS tes comptes, cookies, conversations ni ton code personnalisé (ils restent dans ' + ud() + ').\r\n\r\n' +
    'Pour relancer depuis les sources : installer Node.js, puis dans ce dossier : npm install electron  puis  npx electron .\r\n' +
    'Pour réinstaller cette version dans AI Hub : Paramètres > Mises à jour > Installer un fichier de mise à jour > ai-hub-update-' + ver + '.aihubupdate\r\n', 'utf8') });
  const entries = [...map.values()];
  return { buf: makeZip(entries), count: entries.length };
}
// </PACK>
ipcMain.handle('pack:zip', async () => {
  try {
    const info = ctx.updater.info(), boot = ctx.boot || {};
    const ver = boot.version && boot.version !== 'bundled' ? boot.version : (info.launcherVersion || app.getVersion());
    const r = await dialog.showSaveDialog(win, { defaultPath: 'ai-hub-' + ver + '-' + new Date().toISOString().slice(0, 10) + '.zip', filters: [{ name: 'ZIP', extensions: ['zip'] }] });
    if (r.canceled || !r.filePath) return { ok: false, cancelled: true };
    const res = packApp(ver, app.getAppPath(), __dirname);
    fs.writeFileSync(r.filePath, res.buf);
    try { shell.showItemInFolder(r.filePath); } catch {}
    return { ok: true, path: r.filePath, files: res.count, size: res.buf.length, version: ver };
  } catch (e) { return { ok: false, error: e.message }; }
});

// ---------- 2.5.5 : connexion via le vrai Google Chrome (Google refuse les fenêtres intégrées) ----------
// On ouvre un vrai Chrome (profil temporaire, port de débogage local), tu t'y connectes normalement,
// puis AI Hub lit les cookies du site concerné et les copie dans le compte. Le profil temporaire est supprimé ensuite.
// <CHROME>
const http = require('http'), cp = require('child_process'), os = require('os');
let chromeProc = null, chromeDir = null;
function chromePaths() {
  const e = process.env, c = [];
  if (process.platform === 'win32') {
    for (const b of [e.LOCALAPPDATA, e.ProgramFiles, e['ProgramFiles(x86)']]) if (b) c.push(path.join(b, 'Google', 'Chrome', 'Application', 'chrome.exe'));
    for (const b of [e['ProgramFiles(x86)'], e.ProgramFiles, e.LOCALAPPDATA]) if (b) c.push(path.join(b, 'Microsoft', 'Edge', 'Application', 'msedge.exe'));
  } else if (process.platform === 'darwin') {
    c.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge');
  } else {
    c.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge');
  }
  return c;
}
const cdpJson = (port, p) => new Promise((res, rej) => {
  const r = http.get({ host: '127.0.0.1', port, path: p, timeout: 3000 }, (m) => { let d = ''; m.on('data', (x) => { d += x; }); m.on('end', () => { try { res(JSON.parse(d)); } catch (e) { rej(e); } }); });
  r.on('error', rej); r.on('timeout', () => r.destroy(new Error('délai dépassé')));
});
// cookie Chrome (protocole DevTools) -> cookie Electron ; null si à ignorer
function toElectronCookie(c, hosts) {
  const raw = String(c.domain || ''), dom = raw.replace(/^\./, '').toLowerCase();
  if (!dom || c.partitionKey || /^(cf_clearance|__cf_bm|_cfuvid)$/.test(c.name)) return null;
  if (!hosts.some((h) => dom === h || dom.endsWith('.' + h))) return null;
  const o = { url: 'http' + (c.secure ? 's' : '') + '://' + dom + (c.path || '/'), name: c.name, value: c.value, path: c.path || '/', secure: !!c.secure, httpOnly: !!c.httpOnly };
  if (raw.startsWith('.')) o.domain = raw;
  const ss = String(c.sameSite || '').toLowerCase();
  o.sameSite = ss === 'none' ? 'no_restriction' : ss === 'lax' ? 'lax' : ss === 'strict' ? 'strict' : 'unspecified';
  if (c.expires > 0) o.expirationDate = c.expires;
  return o;
}
function chromeClean() {                           // supprime les profils temporaires oubliés (ils contiennent une session Google)
  try { for (const n of fs.readdirSync(os.tmpdir())) if (/^ai-hub-chrome-\d+$/.test(n)) { try { fs.rmSync(path.join(os.tmpdir(), n), { recursive: true, force: true, maxRetries: 8, retryDelay: 400 }); } catch {} } } catch {}
}
function chromeStop() {
  const p = chromeProc, dir = chromeDir; chromeProc = null; chromeDir = null;
  if (p && p.exitCode === null) {
    try { if (process.platform === 'win32') cp.execFile('taskkill', ['/pid', String(p.pid), '/T', '/F'], () => {}); else p.kill('SIGTERM'); } catch {}
  }
  if (dir) setTimeout(() => { try { fs.rmSync(dir, { recursive: true, force: true, maxRetries: 8, retryDelay: 400 }); } catch {} }, 1500);
}
// </CHROME>
ipcMain.handle('chrome:start', async (_e, url) => {
  try {
    chromeStop(); chromeClean();
    if (!/^https:\/\/[\w.-]+(\/|$)/i.test(String(url))) return { ok: false, error: 'adresse invalide' };
    const exe = chromePaths().find((p) => { try { return fs.existsSync(p); } catch { return false; } });
    if (!exe) return { ok: false, error: "Google Chrome (ou Microsoft Edge) n'est pas installé sur cet ordinateur." };
    const port = 9300 + Math.floor(Math.random() * 500);
    chromeDir = path.join(os.tmpdir(), 'ai-hub-chrome-' + Date.now());
    fs.mkdirSync(chromeDir, { recursive: true });
    const proc = cp.spawn(exe, ['--user-data-dir=' + chromeDir, '--remote-debugging-port=' + port, '--remote-allow-origins=*', '--no-first-run', '--no-default-browser-check', String(url)], { stdio: 'ignore' });
    chromeProc = proc; let dead = false; proc.on('exit', () => { dead = true; }); proc.on('error', () => { dead = true; });
    for (let i = 0; i < 40; i++) {                  // attend que Chrome réponde (20 s max)
      await new Promise((r) => setTimeout(r, 500));
      if (dead) { chromeStop(); return { ok: false, error: 'Chrome s\'est fermé au démarrage.' }; }
      try { const v = await cdpJson(port, '/json/version'); if (v && v.webSocketDebuggerUrl) return { ok: true, port, browser: String(v.Browser || '') }; } catch {}
    }
    chromeStop(); return { ok: false, error: 'Chrome ne répond pas.' };
  } catch (e) { chromeStop(); return { ok: false, error: e.message }; }
});
ipcMain.handle('chrome:ws', async (_e, port) => {
  try { const v = await cdpJson(Number(port), '/json/version'); return { ok: true, ws: v.webSocketDebuggerUrl }; }
  catch { return { ok: false, error: 'Chrome ne répond plus (l\'as-tu fermé ?). Clique « Ouvrir Chrome » pour recommencer.' }; }
});
ipcMain.handle('chrome:import', async (_e, { partition, hosts, cookies }) => {
  try {
    if (!/^persist:a\d+$/.test(String(partition))) return { ok: false, error: 'compte invalide' };
    const ses = session.fromPartition(partition); let n = 0, skipped = 0;
    for (const c of cookies || []) {
      const o = toElectronCookie(c, (hosts || []).map((h) => String(h).toLowerCase()));
      if (!o) { skipped++; continue; }
      try { await ses.cookies.set(o); n++; } catch { skipped++; }
    }
    try { await ses.cookies.flushStore(); } catch {}
    return { ok: true, imported: n, skipped };
  } catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('chrome:stop', () => { chromeStop(); return true; });
app.on('before-quit', () => { chromeStop(); });
app.whenReady().then(chromeClean);

// 10.0.0 : lanceur reconstruit depuis le ZIP (système de mise à jour du lanceur 10, remplacement des fichiers de l'exe à la fermeture)
lanceurAttach(ctx, () => win, ud);

// Garde-fou : une nouvelle version qui ne confirme pas en 15 s est annulée
if (ctx.updater.info().pending) setTimeout(() => { if (ctx.updater.info().pending) ctx.fatal('aucune confirmation de démarrage en 60 s'); }, 60000);   // 7.0 : 15 s était trop court sur un PC chargé (antivirus, 12 comptes) : la 6.0.1 a été annulée à tort

// Une seule instance à la fois : empêche deux fenêtres d'écraser les mêmes données
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
  app.whenReady().then(create);
}
app.on('window-all-closed', () => app.quit());
};

// ---------- 3.0.0 : moteur local complet (lecture, écriture sûre, commandes, mémoire, web) ----------
// Tout chemin est résolu puis vérifié : il doit rester DANS le dossier du projet (pas de « .. », pas de chemin absolu, pas de lien qui sort).
// Le dossier .aihub/ (mémo, journal, sauvegardes) appartient à AI Hub : l'IA ne peut ni le lire ni le modifier par les instructions.
const os = require('os'), cp = require('child_process');
const LOC_IGNORE = new Set(['node_modules', '.git', 'dist', 'build', '.aihub', '__pycache__', '.venv', '.next', '.cache']);
let LOC_IGN = LOC_IGNORE;
const LOC_MAXFILE = 200 * 1024, LOC_MAXOUT = 24000, LOC_MAXBACKUP = 100 * 1024 * 1024, LOC_UNDO_KEEP = 500;
const aihDir = (root) => path.join(fs.realpathSync(root), '.aihub');
function locSafe(root, rel, forInternal) {
  rel = String(rel == null || rel === '' ? '.' : rel).trim().replace(/\\/g, '/');
  if (/^([a-zA-Z]:|\/|~)/.test(rel)) throw new Error('chemin absolu refusé (utilise un chemin relatif au dossier)');
  if (rel.split('/').some(s => s === '..')) throw new Error('« .. » refusé (reste dans le dossier du projet)');
  const base = fs.realpathSync(root), full = path.resolve(base, rel);
  const inside = f => f === base || f.startsWith(base + path.sep);
  if (!inside(full)) throw new Error('chemin hors du dossier');
  // on vérifie le plus proche parent existant : un lien symbolique ne doit pas faire sortir une écriture du dossier
  let probe = full;
  for (let i = 0; i < 64; i++) {
    try { const real = fs.realpathSync(probe); if (!inside(real)) throw new Error('lien symbolique hors du dossier refusé'); break; }
    catch (e) { if (e.code !== 'ENOENT') throw e; const up = path.dirname(probe); if (up === probe) break; probe = up; }
  }
  const r = path.relative(base, full).replace(/\\/g, '/') || '.';
  if (!forInternal && r.split('/')[0].toLowerCase() === '.aihub') throw new Error('le dossier .aihub est réservé à AI Hub (mémo, journal, sauvegardes)');
  return { base, full, rel: r };
}
function locCap(s, n) { s = String(s); if (s.length <= n) return s; const a = Math.floor(n * .55), b = n - a; return s.slice(0, a) + '\n[… ' + (s.length - n) + ' caractères omis — redemande la partie utile avec @read début-fin ou @grep …]\n' + s.slice(-b); }
function locIsBinary(f) { try { const fd = fs.openSync(f, 'r'), buf = Buffer.alloc(4096), n = fs.readSync(fd, buf, 0, 4096, 0); fs.closeSync(fd); for (let i = 0; i < n; i++) if (buf[i] === 0) return true; return false; } catch { return true; } }
function* locWalk(dir, base, maxDepth, depth = 0) {
  let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  ents.sort((x, y) => (y.isDirectory() - x.isDirectory()) || x.name.localeCompare(y.name));
  for (const e of ents) {
    if (e.isSymbolicLink() || LOC_IGN.has(e.name)) continue;
    const full = path.join(dir, e.name), rel = path.relative(base, full).replace(/\\/g, '/');
    yield { e, full, rel, depth };
    if (e.isDirectory() && depth + 1 < maxDepth) yield* locWalk(full, base, maxDepth, depth + 1);
  }
}
const locArgs = s => (String(s || '').match(/"[^"]*"|\S+/g) || []).map(x => x.replace(/^"|"$/g, ''));
const locGlob = g => new RegExp('^' + String(g).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$', 'i');
const locSec = ms => (ms / 1000).toFixed(1).replace('.', ',') + ' s';
const nLines = s => s === '' ? 0 : String(s).split(/\r?\n/).length;

// ---- journal, sauvegardes, annulation (tout vit dans .aihub/) ----
function jlog(root, line) { try { const d = aihDir(root); fs.mkdirSync(d, { recursive: true }); fs.appendFileSync(path.join(d, 'journal.txt'), new Date().toISOString().slice(0, 19).replace('T', ' ') + ' ' + String(line).replace(/\s+/g, ' ').slice(0, 300) + '\n'); } catch {} }
const undoDir = (root) => path.join(aihDir(root), 'undo');
function undoIndex(root) { try { const a = JSON.parse(fs.readFileSync(path.join(undoDir(root), 'index.json'), 'utf8')); return Array.isArray(a) ? a : []; } catch { return []; } }
function undoSave(root, a) {
  const d = undoDir(root); fs.mkdirSync(d, { recursive: true });
  while (a.length > LOC_UNDO_KEEP) { const o = a.shift(); try { fs.rmSync(path.join(d, o.id), { recursive: true, force: true }); } catch {} }
  fs.writeFileSync(path.join(d, 'index.json'), JSON.stringify(a));
}
let undoSeq = 0;
function dirSize(p, limit) { let n = 0; const st = fs.lstatSync(p); if (!st.isDirectory()) return st.size; for (const e of fs.readdirSync(p)) { n += dirSize(path.join(p, e), limit); if (n > limit) throw new Error('trop gros pour être sauvegardé (> ' + Math.round(limit / 1048576) + ' Mo) : utilise @run pour cette opération'); } return n; }
// Enregistre une modification annulable. backup = chemin complet à sauvegarder avant d'agir (ou null si rien à sauvegarder).
function undoPush(root, ctx, op, rel, rel2, backupFull) {
  const id = Date.now().toString(36) + (undoSeq++).toString(36), e = { id, ts: Date.now(), turn: (ctx && ctx.turn) || 't0', op, rel, rel2: rel2 || '', bak: false };
  if (backupFull && fs.existsSync(backupFull)) {
    dirSize(backupFull, LOC_MAXBACKUP);
    const dst = path.join(undoDir(root), id); fs.mkdirSync(dst, { recursive: true });
    fs.cpSync(backupFull, path.join(dst, 'b'), { recursive: true }); e.bak = true; e.dir = fs.statSync(backupFull).isDirectory();
  }
  const a = undoIndex(root); a.push(e); undoSave(root, a); return e;
}
function undoDropLast(root, id) { const a = undoIndex(root).filter(x => x.id !== id); undoSave(root, a); try { fs.rmSync(path.join(undoDir(root), id), { recursive: true, force: true }); } catch {} }
function undoOne(root, e) {
  const base = fs.realpathSync(root), P = r => locSafe(root, r).full, bak = path.join(undoDir(root), e.id, 'b');
  const restoreBak = (full) => { fs.mkdirSync(path.dirname(full), { recursive: true }); fs.rmSync(full, { recursive: true, force: true }); fs.cpSync(bak, full, { recursive: true }); };
  if (e.op === 'write' || e.op === 'edit' || e.op === 'append') { const f = P(e.rel); if (e.bak) restoreBak(f); else fs.rmSync(f, { force: true }); return 'restauré ' + e.rel; }
  if (e.op === 'delete') { const f = P(e.rel); if (fs.existsSync(f)) throw new Error(e.rel + ' existe déjà : rien restauré'); if (!e.bak) throw new Error('sauvegarde introuvable'); restoreBak(f); return 'récupéré ' + e.rel; }
  if (e.op === 'mkdir') { const f = P(e.rel); try { fs.rmdirSync(f); } catch { throw new Error('dossier ' + e.rel + ' non vide ou déjà supprimé : laissé tel quel'); } return 'dossier retiré ' + e.rel; }
  if (e.op === 'move') { const a = P(e.rel), b = P(e.rel2); if (!fs.existsSync(b)) throw new Error(e.rel2 + ' n\'existe plus'); if (fs.existsSync(a)) throw new Error(e.rel + ' existe déjà'); fs.mkdirSync(path.dirname(a), { recursive: true }); try { fs.renameSync(b, a); } catch { fs.cpSync(b, a, { recursive: true }); fs.rmSync(b, { recursive: true, force: true }); } return 'remis ' + e.rel2 + ' → ' + e.rel; }
  if (e.op === 'copy') { const t = P(e.rel2); if (e.bak) restoreBak(t); else fs.rmSync(t, { recursive: true, force: true }); return 'copie annulée ' + e.rel2; }
  throw new Error('opération inconnue : ' + e.op);
}
function undoMany(root, list) { const out = []; let ok = 0; for (const e of list) { try { out.push('✔ ' + undoOne(root, e)); undoDropLast(root, e.id); ok++; } catch (x) { out.push('✕ ' + e.op + ' ' + e.rel + ' : ' + (x.message || x)); } } return { ok, out }; }

// ---- éditions ----
function parseEdit(body) {
  const L = String(body || '').replace(/\r/g, '').split('\n'), pairs = []; let mode = '', s = [], r = [];
  const flush = () => { if (mode === 'r') pairs.push({ s: s.join('\n'), r: r.join('\n') }); s = []; r = []; };
  for (const l of L) {
    const t = l.trim();
    if (t === 'CHERCHE' || t === 'SEARCH') { flush(); mode = 's'; continue; }
    if (t === 'REMPLACE' || t === 'REPLACE') { if (mode !== 's') throw new Error('REMPLACE sans CHERCHE avant'); mode = 'r'; continue; }
    if (mode === 's') s.push(l); else if (mode === 'r') r.push(l);
  }
  flush();
  if (!pairs.length) throw new Error('bloc invalide : écris CHERCHE, le texte à trouver, REMPLACE, puis le nouveau texte (entre <<< et >>>)');
  return pairs;
}
function countOcc(h, n) { let c = 0, i = 0; while ((i = h.indexOf(n, i)) !== -1) { c++; i += n.length; } return c; }

// ---- web ----
function htmlToText(h) {
  h = String(h).replace(/<(script|style|noscript|svg|template)[\s\S]*?<\/\1>/gi, ' ').replace(/<!--[\s\S]*?-->/g, ' ');
  h = h.replace(/<(br|\/p|\/div|\/li|\/tr|\/h[1-6]|\/pre|\/blockquote|\/table|\/section|\/article)\s*\/?>/gi, '\n').replace(/<li[^>]*>/gi, '\n• ').replace(/<[^>]+>/g, ' ');
  const ent = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', laquo: '«', raquo: '»', hellip: '…', eacute: 'é', egrave: 'è', agrave: 'à', ecirc: 'ê', ccedil: 'ç' };
  h = h.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (m, e) => { if (e[0] === '#') { const n = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); try { return String.fromCodePoint(n); } catch { return ' '; } } return ent[e.toLowerCase()] != null ? ent[e.toLowerCase()] : m; });
  return h.replace(/[ \t\f\v]+/g, ' ').replace(/ ?\n ?/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
function privateHost(h) { h = String(h).toLowerCase().replace(/^\[|\]$/g, ''); return h === 'localhost' || h.endsWith('.local') || h.endsWith('.internal') || /^(127\.|10\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h) || h === '::1' || /^f[cd][0-9a-f]{2}:/.test(h) || /^fe80:/.test(h); }
async function locFetch(url, ms) {
  const u = new URL(url); if (!/^https?:$/.test(u.protocol)) throw new Error('seules les adresses http(s) sont permises');
  if (privateHost(u.hostname)) throw new Error('adresse locale ou privée refusée');
  const f = globalThis.fetch || require('electron').net.fetch, ac = new AbortController(), t = setTimeout(() => ac.abort(), ms || 20000);
  try {
    const r = await f(u.href, { signal: ac.signal, redirect: 'follow', headers: { 'User-Agent': 'Mozilla/5.0 (AI Hub)', 'Accept': 'text/html,text/plain,application/json;q=0.9,*/*;q=0.5', 'Accept-Language': 'fr,en;q=0.8' } });
    if (r.url) { try { if (privateHost(new URL(r.url).hostname)) throw new Error('redirection vers une adresse privée refusée'); } catch (e) { if (/refusée/.test(e.message)) throw e; } }
    const ct = String(r.headers.get('content-type') || '');
    if (/^(image|video|audio)\//i.test(ct) || /application\/(pdf|zip|octet-stream)/i.test(ct)) throw new Error('contenu non textuel (' + ct.split(';')[0] + ') : télécharge-le avec @run ou @script si besoin');
    const raw = (await r.text()).slice(0, 2 * 1024 * 1024);
    return { status: r.status, ct, raw, url: r.url || u.href };
  } catch (e) { if (e.name === 'AbortError') throw new Error('délai dépassé (' + Math.round((ms || 20000) / 1000) + ' s)'); throw e; }
  finally { clearTimeout(t); }
}
function parseSearch(html) {
  const out = [], re = /<a[^>]+class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>([\s\S]*?)(?=<a[^>]+class="[^"]*result__a|$)/gi; let m;
  while ((m = re.exec(html)) && out.length < 8) {
    let href = m[1].replace(/&amp;/g, '&'); const q = /[?&]uddg=([^&]+)/.exec(href); if (q) { try { href = decodeURIComponent(q[1]); } catch {} } else if (href.startsWith('//')) href = 'https:' + href;
    const sn = /class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/(?:a|td|div)>/i.exec(m[3]);
    out.push({ t: htmlToText(m[2]).slice(0, 140), u: href, s: sn ? htmlToText(sn[1]).slice(0, 220) : '' });
  }
  return out;
}

// ---- processus (commandes et scripts) ----
function killTree(child) { try { if (process.platform === 'win32') cp.spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true }); else process.kill(-child.pid, 'SIGKILL'); } catch { try { child.kill('SIGKILL'); } catch {} } }
function locProc(file, args, o) {
  return new Promise((resolve) => {
    const t0 = Date.now(); let head = '', tail = '', total = 0, done = false, timedOut = false;
    const push = (d) => { const s = d.toString('utf8'); total += s.length; if (head.length < 30000) { head += s; if (head.length > 30000) { tail = head.slice(30000); head = head.slice(0, 30000); } } else { tail += s; if (tail.length > 30000) tail = tail.slice(-30000); } };
    let child; try { child = cp.spawn(file, args, { cwd: o.cwd, shell: !!o.shell, windowsHide: true, detached: process.platform !== 'win32', stdio: ['ignore', 'pipe', 'pipe'], env: Object.assign({}, process.env, o.env || {}) }); }
    catch (e) { return resolve({ code: -1, out: String(e.message || e), ms: 0, spawnErr: true }); }
    LOC_PROCS.add(child);
    const fin = (code, extra) => { if (done) return; done = true; clearTimeout(tm); LOC_PROCS.delete(child); const omitted = total - head.length - tail.length; resolve({ code, out: head + (omitted > 0 ? '\n[… ' + omitted + ' caractères omis …]\n' : '') + tail + (extra || ''), ms: Date.now() - t0, timedOut }); };
    const tm = setTimeout(() => { timedOut = true; killTree(child); setTimeout(() => fin(-1, '\n[arrêté : délai de ' + Math.round(o.timeout / 1000) + ' s dépassé]'), 800); }, o.timeout);
    child.stdout.on('data', push); child.stderr.on('data', push);
    child.on('error', (e) => { head += String(e.message || e); fin(-1); });
    child.on('close', (code) => fin(code == null ? -1 : code));
  });
}
const LOC_PROCS = new Set();
const whichCache = {};
function haveCmd(cmd, args) { const k = cmd + ' ' + (args || []).join(' '); if (k in whichCache) return whichCache[k]; try { const r = cp.spawnSync(cmd, args || ['--version'], { stdio: 'ignore', windowsHide: true, timeout: 8000 }); return whichCache[k] = !r.error && r.status === 0; } catch { return whichCache[k] = false; } }
function interp(lang) {
  const win = process.platform === 'win32';
  if (lang === 'node') return haveCmd('node') ? { file: 'node', pre: [], env: {} } : { file: process.execPath, pre: [], env: { ELECTRON_RUN_AS_NODE: '1' } };
  if (lang === 'python') { const c = win ? [['python', []], ['py', ['-3']], ['python3', []]] : [['python3', []], ['python', []]]; for (const [f, pre] of c) if (haveCmd(f, pre.concat('--version'))) return { file: f, pre, env: { PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' } }; throw new Error('Python introuvable sur ce PC'); }
  if (lang === 'powershell') { const c = win ? ['powershell', 'pwsh'] : ['pwsh', 'powershell']; for (const f of c) if (haveCmd(f, ['-NoProfile', '-Command', 'exit 0'])) return { file: f, pre: ['-NoProfile'].concat(win ? ['-ExecutionPolicy', 'Bypass'] : []), env: {}, ps: true }; throw new Error('PowerShell introuvable sur ce PC'); }
  throw new Error('langage inconnu : ' + lang + ' (node, python ou powershell)');
}
// 4.11.0 : erreurs de compilation condensées en fichier:ligne (javac, gcc, tsc, rustc, python) avant la sortie complète
// 5.1.0 : extrait de code (±4 lignes) autour des 3 premières erreurs : l'IA n'a plus besoin d'un tour de lecture pour les comprendre
function cerrCode(P, root) {
  if (!root || !P.length) return '';
  let sn = ''; try {
    const base = fs.realpathSync(root);
    for (const [f, ln] of P.slice(0, 3)) {
      const full = path.resolve(base, f);
      if (!full.startsWith(base + path.sep) || !fs.existsSync(full) || fs.statSync(full).size > 400000) continue;
      const Ls = fs.readFileSync(full, 'utf8').split(/\r?\n/), a = Math.max(0, ln - 4), b = Math.min(Ls.length, ln + 3);
      sn += '--- ' + path.relative(base, full).replace(/\\/g, '/') + ' ' + (a + 1) + '-' + b + ' ---\n' + Ls.slice(a, b).map((x, i) => (a + i + 1 === ln ? '>' : ' ') + (a + i + 1) + ' ' + x.slice(0, 200)).join('\n') + '\n';
    }
  } catch {}
  return sn;
}
function cerrSum(out, ok, root) {
  if (ok) return '';
  const seen = new Set(), L = [], P = [], res = [/^\s*([^\s:()"]+\.[A-Za-z]{1,6}):(\d+)(?::\d+)?:\s*(?:fatal\s+)?error\b[:\s]*(.*)$/i, /^\s*([^\s:()"]+\.[A-Za-z]{1,6})\((\d+)(?:,\d+)?\):\s*error\s*(.*)$/i, /^\s*-->\s*([^\s:]+):(\d+)(?::\d+)?()/, /^\s*File "([^"]+)", line (\d+)()/];
  for (const l of String(out || '').split('\n')) for (const re of res) { const m = re.exec(l); if (m) { const k = m[1] + ':' + m[2]; if (!seen.has(k)) { seen.add(k); P.push([m[1], +m[2]]); L.push(k + (m[3] ? ' ' + m[3].trim().slice(0, 140) : '')); } break; } }
  return L.length ? 'ERREURS À CORRIGER (' + L.length + ') fichier:ligne :\n' + L.slice(0, 15).join('\n') + (L.length > 15 ? '\n…' : '') + '\n' + cerrCode(P, root) + '---\n' : '';
}
const cmdOut = (r, t, name, root) => {
  const ok = r.code === 0 && !r.timedOut, lab = r.timedOut ? 'délai dépassé' : 'code ' + r.code;
  const sm = locSmart(r.out, ok ? 6000 : 9000);      // 4.2.0 : sans bruit (npm WARN, barres de progression, lignes répétées), erreurs et fin gardées
  return { ok, title: name + ' (' + lab + ', ' + locSec(r.ms) + ')', out: (cerrSum(r.out, ok, root) + sm.out.trim()) || '(aucune sortie)', changed: true, saved: sm.saved };
};

// ---- 3.7.0 : suivi des lectures, diff, vérification automatique, carte du projet ----
// Suivi des lectures : AI Hub retient la version (date + taille) que l'IA a lue en dernier. Si le fichier a changé depuis
// (modification à la main, commande), @edit et @write refusent d'écraser et demandent une relecture.
const LOC_SEEN = new Map();
const realBase = (root) => { try { return fs.realpathSync(root); } catch { return String(root); } };
const seenKey = (root, rel) => realBase(root) + '|' + rel;
function seenMark(root, rel, full) { try { const st = fs.statSync(full); LOC_SEEN.set(seenKey(root, rel), { m: st.mtimeMs, s: st.size }); } catch {} }
function seenStale(root, rel, full) { const o = LOC_SEEN.get(seenKey(root, rel)); if (!o) return false; try { const st = fs.statSync(full); return st.mtimeMs !== o.m || st.size !== o.s; } catch { return false; } }
function seenClear(root) { const b = realBase(root) + '|'; for (const k of [...LOC_SEEN.keys()]) if (k.startsWith(b)) LOC_SEEN.delete(k); }
const staleMsg = (rel) => rel + ' a changé depuis ta dernière lecture (modification à la main ou par une commande) : rien n\'a été modifié, relis-le avec @read ' + rel + ' puis recommence';
// numéros de lignes (1, 2, 3…) de toutes les occurrences d'un texte
function occLines(h, n) { const out = []; let i = 0; while ((i = h.indexOf(n, i)) !== -1) { out.push(h.slice(0, i).split('\n').length); i += Math.max(1, n.length); if (out.length >= 50) break; } return out; }

// Diff ligne par ligne (contexte de 2 lignes). Renvoie { diff, add, del } ; diff = lignes préfixées « + », « - » ou « 2 espaces ».
function lineDiff(a, b, ctx) {
  ctx = ctx == null ? 2 : ctx;
  const sp = (x) => { x = String(x == null ? '' : x).replace(/\r\n/g, '\n'); return x === '' ? [] : x.split('\n'); };
  const A = sp(a), B = sp(b);
  let s = 0; while (s < A.length && s < B.length && A[s] === B[s]) s++;
  let ea = A.length, eb = B.length; while (ea > s && eb > s && A[ea - 1] === B[eb - 1]) { ea--; eb--; }
  const a2 = A.slice(s, ea), b2 = B.slice(s, eb), ops = [];
  for (let i = 0; i < s; i++) ops.push([' ', A[i]]);
  const n = a2.length, m = b2.length;
  if (n * m <= 4000000) {
    const W = m + 1, dp = new Uint32Array((n + 1) * W);
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) dp[i * W + j] = a2[i] === b2[j] ? dp[(i + 1) * W + j + 1] + 1 : Math.max(dp[(i + 1) * W + j], dp[i * W + j + 1]);
    let i = 0, j = 0;
    while (i < n && j < m) { if (a2[i] === b2[j]) { ops.push([' ', a2[i]]); i++; j++; } else if (dp[(i + 1) * W + j] >= dp[i * W + j + 1]) { ops.push(['-', a2[i]]); i++; } else { ops.push(['+', b2[j]]); j++; } }
    while (i < n) ops.push(['-', a2[i++]]); while (j < m) ops.push(['+', b2[j++]]);
  } else { for (const x of a2) ops.push(['-', x]); for (const x of b2) ops.push(['+', x]); }
  for (let i = ea; i < A.length; i++) ops.push([' ', A[i]]);
  let add = 0, del = 0; const show = new Uint8Array(ops.length);
  ops.forEach((o, i) => { if (o[0] !== ' ') { if (o[0] === '+') add++; else del++; for (let k = Math.max(0, i - ctx); k <= Math.min(ops.length - 1, i + ctx); k++) show[k] = 1; } });
  if (!add && !del) return { diff: '', add: 0, del: 0 };
  const out = []; let ln = 0, gap = true, shown = 0;
  ops.forEach((o, i) => {
    if (o[0] !== '-') ln++;
    if (!show[i]) { gap = true; return; }
    if (shown >= 220) return;
    if (gap) { out.push('@@ ligne ' + (o[0] === '-' ? ln + 1 : ln) + ' @@'); gap = false; }
    out.push(o[0] + ' ' + String(o[1]).slice(0, 220)); shown++;
  });
  if (shown >= 220) out.push('@@ … diff coupé à 220 lignes @@');
  return { diff: out.join('\n'), add, del };
}

// Vérification de syntaxe après chaque @write / @edit / @append. Renvoie null si rien à vérifier.
async function locVerify(root, rel, full) {
  const ext = path.extname(rel).toLowerCase(), base = path.basename(rel).toLowerCase();
  const lineOf = (n) => { try { return fs.readFileSync(full, 'utf8').split(/\r?\n/)[n - 1]; } catch { return ''; } };
  const fail = (what, msg, line) => { let m = String(msg).replace(/\s+/g, ' ').trim().slice(0, 240); if (line) { const src = String(lineOf(line) || '').trim().slice(0, 140); if (src) m += ' | ligne ' + line + ' : ' + src; } return { ok: false, what, msg: m, line: line || 0 }; };
  try {
    if (ext === '.json') {
      if (/^(tsconfig|jsconfig).*\.json$|^\.(babelrc|eslintrc|prettierrc)/.test(base)) return null;     // JSON avec commentaires toléré par ces outils
      const t = fs.readFileSync(full, 'utf8').replace(/^\uFEFF/, '');
      try { JSON.parse(t); return { ok: true, what: 'JSON valide' }; }
      catch (e) { const m = /position (\d+)/.exec(e.message); return fail('JSON.parse', e.message, m ? t.slice(0, +m[1]).split('\n').length : 0); }
    }
    if (/^\.(js|mjs|cjs)$/.test(ext)) {
      const it = interp('node'), r = await locProc(it.file, it.pre.concat(['--check', full]), { cwd: realBase(root), timeout: 15000, env: it.env });
      if (r.code === 0 && !r.timedOut) return { ok: true, what: 'node --check' };
      if (r.timedOut || r.spawnErr) return null;
      const o = String(r.out || ''), lm = /:(\d+)\s*$/m.exec(o), em = /^\s*(?:\w*Error): .*$/m.exec(o);
      return fail('node --check', em ? em[0] : o.split('\n').find(l => l.trim()) || 'erreur de syntaxe', lm ? +lm[1] : 0);
    }
    if (ext === '.py') {
      let it; try { it = interp('python'); } catch { return null; }
      const code = 'import ast,sys\ntry:\n    ast.parse(open(sys.argv[1],encoding="utf-8-sig").read(),sys.argv[1])\nexcept SyntaxError as e:\n    print("SyntaxError: %s|%s"%(e.msg,e.lineno)); sys.exit(1)\n';
      const r = await locProc(it.file, it.pre.concat(['-c', code, full]), { cwd: realBase(root), timeout: 15000, env: it.env });
      if (r.code === 0 && !r.timedOut) return { ok: true, what: 'syntaxe Python' };
      const m = /SyntaxError: (.*)\|(\d+)/.exec(r.out || ''); if (!m) return null;
      return fail('syntaxe Python', 'SyntaxError: ' + m[1], +m[2]);
    }
    if (/^\.(html?|xhtml)$/.test(ext)) {
      const vm = require('vm'), t = fs.readFileSync(full, 'utf8'), re = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi; let m, n = 0;
      while ((m = re.exec(t))) {
        const at = m[1]; if (/\bsrc\s*=/i.test(at) || !m[2].trim()) continue;
        const ty = /\btype\s*=\s*["']?([^"'\s>]+)/i.exec(at); if (ty && !/^(text|application)\/(x-)?(javascript|ecmascript)$/i.test(ty[1])) continue;
        n++; const startLine = t.slice(0, m.index + m[0].indexOf('>') + 1).split('\n').length;
        try { new vm.Script(m[2], { filename: rel, lineOffset: startLine - 1 }); }
        catch (e) { const lm = /:(\d+)\s*$/.exec(String(e.stack || '').split('\n')[0]); return fail('<script> n°' + n, e.message, lm ? +lm[1] : startLine); }
      }
      return n ? { ok: true, what: n + ' <script> contrôlé' + (n > 1 ? 's' : '') } : null;
    }
  } catch { return null; }
  return null;
}

// ---- carte du projet (.aihub/index.json) : fichiers, tailles, dates, fonctions / classes / titres. Sans IA, sans embeddings. ----
const IDX_SKIP = /(^|\/)(package-lock\.json|yarn\.lock|pnpm-lock\.yaml|composer\.lock)$|\.(lock|min\.js|min\.css|map|png|jpe?g|gif|webp|ico|bmp|svg|woff2?|ttf|otf|eot|mp[34]|webm|mov|zip|gz|7z|rar|pdf|exe|dll|bin|sqlite|db|psd|aihubupdate)$/i;
const GEN_NAME = /^(package-lock\.json|yarn\.lock|pnpm-lock\.yaml|composer\.lock)$|\.(lock|min\.js|min\.css|map|png|jpe?g|gif|webp|ico|bmp|svg|woff2?|ttf|otf|eot|mp[34]|webm|mov|zip|gz|7z|rar|pdf)$/i;
const IDX_KIND = { '.js': 'js', '.mjs': 'js', '.cjs': 'js', '.jsx': 'js', '.ts': 'js', '.tsx': 'js', '.vue': 'js', '.svelte': 'js', '.html': 'js', '.htm': 'js', '.py': 'py', '.go': 'go', '.rs': 'rs', '.java': 'cls', '.cs': 'cls', '.kt': 'cls', '.swift': 'cls', '.php': 'php', '.rb': 'rb', '.md': 'md' };
function idxSymbols(kind, text, max) {
  const L = text.split('\n'), out = [], seen = new Set(); const add = (n, i) => { if (n && out.length < (max || 80) && !seen.has(n)) { seen.add(n); out.push([n, i + 1]); } };
  for (let i = 0; i < L.length; i++) {
    const l = L[i]; if (l.length > 3000) continue; let m;
    if (kind === 'js') {
      if ((m = /^\s*(?:export\s+(?:default\s+)?)?(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)/.exec(l))) add(m[1], i);
      else if ((m = /^\s*(?:export\s+(?:default\s+)?)?(?:abstract\s+)?class\s+([A-Za-z_$][\w$]*)/.exec(l))) add(m[1], i);
      else if ((m = /^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*=>|[A-Za-z_$][\w$]*\s*=>)/.exec(l))) add(m[1], i);
      else if ((m = /^\s*(?:module\.)?exports\.([A-Za-z_$][\w$]*)\s*=/.exec(l))) add(m[1], i);
      else if ((m = /^\s*(?:export\s+)?(?:interface|type|enum)\s+([A-Za-z_$][\w$]*)/.exec(l))) add(m[1], i);
      else if ((m = /^(?:export\s+)?const\s+([A-Z][A-Z0-9_]{2,})\s*=/.exec(l))) add(m[1], i);
      else if ((m = /^\s{0,4}(?:async\s+)?([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{\s*$/.exec(l)) && !/^(if|for|while|switch|catch|function|return|else|with)$/.test(m[1])) add(m[1], i);
      else if (l.length > 120) for (const mm of l.matchAll(/\bfunction\s+([A-Za-z_$][\w$]*)\s*\(/g)) add(mm[1], i);     // code écrit sur de très longues lignes
    } else if (kind === 'py') { if ((m = /^\s*(?:async\s+)?def\s+(\w+)/.exec(l)) || (m = /^\s*class\s+(\w+)/.exec(l))) add(m[1], i); }
    else if (kind === 'go') { if ((m = /^func\s+(?:\([^)]*\)\s*)?(\w+)/.exec(l)) || (m = /^type\s+(\w+)/.exec(l))) add(m[1], i); }
    else if (kind === 'rs') { if ((m = /^\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+(\w+)/.exec(l)) || (m = /^\s*(?:pub\s+)?(?:struct|enum|trait)\s+(\w+)/.exec(l))) add(m[1], i); }
    else if (kind === 'cls') { if ((m = /\b(?:class|interface|enum|struct|record|object)\s+([A-Za-z_]\w*)/.exec(l))) add(m[1], i); else if ((m = /^\s*(?:public|private|protected|internal|static|override|fun|func)\b[^=;(]*?\s(\w+)\s*\(/.exec(l))) add(m[1], i); }
    else if (kind === 'php') { if ((m = /\bfunction\s+(\w+)/.exec(l)) || (m = /^\s*(?:abstract\s+|final\s+)?class\s+(\w+)/.exec(l))) add(m[1], i); }
    else if (kind === 'rb') { if ((m = /^\s*def\s+([\w.?!]+)/.exec(l)) || (m = /^\s*(?:class|module)\s+(\w+)/.exec(l))) add(m[1], i); }
    else if (kind === 'md') { if ((m = /^#{1,3}\s+(.{2,60})$/.exec(l))) add(m[1].trim(), i); }
  }
  return out;
}
function idxRole(text, kind) {
  if (kind === 'js' && /<title>/i.test(text.slice(0, 4000))) { const t = /<title>([^<]{3,70})/i.exec(text); if (t) return t[1].trim(); }
  for (const l0 of text.split('\n').slice(0, 14)) {
    const l = l0.trim(); let m;
    if (kind === 'md' && (m = /^#\s+(.+)$/.exec(l))) return m[1].slice(0, 70);
    if ((m = /^(?:\/\/+|#(?!!)|--|;|\*|\/\*+!?|<!--)\s*(.{8,})$/.exec(l))) { const r = m[1].replace(/\*\/\s*$|-->\s*$/, '').trim(); if (r.length >= 8 && !/^(use strict|eslint|@ts-|global |-\*-|vim:|shellcheck|copyright|license|tslint|prettier)/i.test(r)) return r.slice(0, 70); }
    if (kind === 'py' && (m = /^"""\s*(.{8,}?)\s*("""|$)/.exec(l))) return m[1].slice(0, 70);
  }
  return '';
}
const idxPath = (root) => path.join(aihDir(root), 'index.json');
function idxLoad(root) { try { const j = JSON.parse(fs.readFileSync(idxPath(root), 'utf8')); if (j && j.v === 1 && j.files && typeof j.files === 'object') return j; } catch {} return { v: 1, files: {} }; }
function idxUpdate(root) {
  const base = realBase(root), idx = idxLoad(root), seen = new Set(); let n = 0, changed = false, budget = 60 * 1024 * 1024;
  for (const x of locWalk(base, base, 10)) {
    if (x.e.isDirectory()) continue; if (++n > 4000) break;
    if (IDX_SKIP.test(x.rel)) continue;
    let st; try { st = fs.statSync(x.full); } catch { continue; }
    const old = idx.files[x.rel], m = Math.floor(st.mtimeMs);
    if (old && old.m === m && old.s === st.size) { seen.add(x.rel); continue; }
    if (budget <= 0) continue;                       // gros dossier : le reste sera indexé à la prochaine demande
    seen.add(x.rel);
    const e = { m, s: st.size, y: [], r: '', l: 0 };
    if (st.size <= 400 * 1024) {
      if (locIsBinary(x.full)) e.b = 1;
      else { let text = ''; try { text = fs.readFileSync(x.full, 'utf8'); budget -= text.length; } catch {} const kind = IDX_KIND[path.extname(x.rel).toLowerCase()]; if (kind) e.y = idxSymbols(kind, text); e.r = idxRole(text, kind); e.l = nLines(text); }
    }
    idx.files[x.rel] = e; changed = true;
  }
  for (const k of Object.keys(idx.files)) if (!seen.has(k)) { delete idx.files[k]; changed = true; }
  if (changed) { try { const d = aihDir(root); fs.mkdirSync(d, { recursive: true }); const tmp = idxPath(root) + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(idx)); fs.renameSync(tmp, idxPath(root)); } catch {} }
  return idx;
}
const IDX_STOP = new Set('le la les un une des de du et ou en dans sur pour par avec sans que qui est sont fais fait faire peux peut veux voudrais merci stp svp ce cet cette ces mon ma mes ton ta tes son sa ses notre votre leur leurs nous vous ils elles mais donc car ni ne pas plus tres aussi comme tout tous toute toutes fichier fichiers code projet dossier modifie modifier corrige corriger ajoute ajouter cree creer supprime supprimer change changer the and for with that this from into please can you make fix add create update remove file files folder'.split(' '));
const idxNorm = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
function idxTokens(q) {
  const out = new Set();
  for (const w of String(q || '').split(/[^\p{L}\p{N}_.\/-]+/u)) {
    if (!w) continue; const n = idxNorm(w); if (n.length >= 3 && !IDX_STOP.has(n)) out.add(n);
    for (const p of w.replace(/([a-z0-9])([A-Z])/g, '$1 $2').split(/[_.\/\- ]+/)) { const pn = idxNorm(p); if (pn.length >= 3 && !IDX_STOP.has(pn)) out.add(pn); }
  }
  return [...out].slice(0, 24);
}
function idxScore(rel, e, toks, qn) {
  if (e.b) return 0;
  const rl = rel.toLowerCase(), bn = path.basename(rl); let s = 0;
  if (qn.includes(rl) || (bn.length >= 4 && bn.includes('.') && qn.includes(bn))) s += 20;
  for (const t of toks) {
    if (bn.includes(t)) s += 5; else if (rl.includes(t)) s += 2;
    for (const [nm] of (e.y || [])) { const n = nm.toLowerCase(); if (n === t) { s += 6; break; } if (t.length >= 4 && n.includes(t)) { s += 3; break; } }
  }
  return s;
}
function idxMap(idx, n) {
  const now = Date.now(), ent = [];
  for (const [rel, e] of Object.entries(idx.files)) {
    if (e.b || /^(license|licence|changelog|\.gitignore|\.gitattributes)/i.test(path.basename(rel))) continue;
    const depth = rel.split('/').length - 1, bn = path.basename(rel).toLowerCase(); let sc = -10 * depth;
    if (/^(package\.json|readme|main\.|index\.|app\.|server\.|manifest|pyproject|cargo\.toml|go\.mod)/.test(bn)) sc += 50;
    if (IDX_KIND[path.extname(bn)]) sc += 10;
    if (now - e.m < 7 * 864e5) sc += 8;
    sc += Math.min(8, Math.log2(1 + (e.l || 0)));
    ent.push([rel, e, sc]);
  }
  ent.sort((a, b) => b[2] - a[2]);
  return ent.slice(0, n).map(([rel, e]) => { const role = e.r || (e.y || []).slice(0, 4).map(x => x[0]).join(', ') || (e.l ? e.l + ' lignes' : ''); return (rel + (role ? ' — ' + role : '')).slice(0, 120); }).join('\n');
}
function idxPre(root, idx, q, cap) {
  const toks = idxTokens(q), qn = idxNorm(q), base = realBase(root), files = []; let used = 0, pre = '';
  if (!toks.length || cap < 800) return { pre: '', files: [] };
  if (CTX_ON) { try { const r = ctxPre(root, q, cap); if (r) return r; } catch {} }
  const ranked = Object.entries(idx.files).map(([rel, e]) => [rel, e, idxScore(rel, e, toks, qn)]).filter(x => x[2] >= 4).sort((a, b) => b[2] - a[2]).slice(0, 4);
  for (const [rel, e] of ranked) {
    const remain = cap - used; if (remain < 600) break;
    if (e.s > 400 * 1024) continue;
    let text; try { text = fs.readFileSync(path.join(base, rel), 'utf8'); } catch { continue; }
    const L = text.split('\n'), N = L.length; let block = '';
    if (text.length <= Math.min(remain - 120, Math.max(2500, Math.floor(cap / 3)))) block = '=== ' + rel + ' (' + N + ' lignes, fichier entier) ===\n' + text;
    else {
      const hit = new Set(); const win = (a, b) => { for (let i = Math.max(0, a); i < Math.min(N, b); i++) hit.add(i); };
      for (const [nm, ln] of (e.y || [])) { const n = nm.toLowerCase(); if (toks.some(t => n === t || (t.length >= 4 && n.includes(t)))) win(ln - 3, ln + 28); }
      if (!hit.size) { let c = 0; for (let i = 0; i < N && c < 3; i++) { const l = L[i].toLowerCase(); if (L[i].length < 600 && toks.some(t => t.length >= 4 && l.includes(t))) { win(i - 8, i + 12); c++; } } }
      if (!hit.size) win(0, 40);
      const idxs = [...hit].sort((a, b) => a - b), parts = []; let a0 = -1, prev = -2;
      for (const i of idxs) { if (i !== prev + 1) { if (a0 >= 0) parts.push([a0, prev]); a0 = i; } prev = i; } if (a0 >= 0) parts.push([a0, prev]);
      const segs = []; let room = remain - 140;
      for (const [a, b] of parts) { let seg = L.slice(a, b + 1).join('\n'); if (seg.length > room) seg = seg.slice(0, Math.max(0, room)); if (seg.length < 80) break; segs.push('=== ' + rel + ' (lignes ' + (a + 1) + '-' + (b + 1) + ' sur ' + N + ') ===\n' + seg); room -= seg.length + 60; if (room < 200) break; }
      block = segs.join('\n');
    }
    if (!block) continue;
    pre += (pre ? '\n' : '') + block; used += block.length; files.push(rel); seenMark(root, rel, path.join(base, rel));
  }
  return { pre: pre ? 'PRÉ-LECTURE (extraits des fichiers les plus probables, déjà lus : ne les relis pas avec @read, utilise-les directement) :\n' + pre + '\n' : '', files };
}
function projHasTest(root) {
  try { const j = JSON.parse(fs.readFileSync(path.join(realBase(root), 'package.json'), 'utf8')), t = j && j.scripts && j.scripts.test; return !!t && !/no test specified/i.test(t); } catch { return false; }
}

// Remplacement d'un texte dans un fichier (@edit CHERCHE / REMPLACE) : exact d'abord, puis comparaison normalisée
// (indentation, espaces de fin de ligne) avec réécriture à l'indentation du fichier ; si plusieurs endroits : numéros de lignes.
function editPair(txt, p, i, rel) {
  const n = countOcc(txt, p.s), nb = 'n°' + (i + 1);
  if (n === 1) return txt.replace(p.s, () => p.r);
  if (n > 1) { const ls = occLines(txt, p.s); throw new Error('texte CHERCHE ' + nb + ' apparaît ' + n + ' fois dans ' + rel + ' (lignes ' + ls.slice(0, 8).join(', ') + (n > 8 ? '…' : '') + ') (aucun fichier modifié) : ajoute des lignes autour pour le rendre unique, ou @read la zone puis @edit ' + rel + ' lignes ' + ls[0] + '-' + (ls[0] + nLines(p.s) - 1)); }
  const F = txt.split('\n'), S = p.s.replace(/\r/g, '').split('\n');
  while (S.length && !S[0].trim()) S.shift(); while (S.length && !S[S.length - 1].trim()) S.pop();
  const nz = (x) => x.trim().replace(/\s+/g, ' '), Sn = S.map(nz), hits = [];
  for (let i0 = 0; S.length && i0 + S.length <= F.length; i0++) { let ok = true; for (let j = 0; j < S.length; j++) if (nz(F[i0 + j]) !== Sn[j]) { ok = false; break; } if (ok) hits.push(i0); }
  if (!hits.length) throw new Error('texte CHERCHE ' + nb + ' introuvable dans ' + rel + ' (aucun fichier modifié) : relis la zone avec @read puis recopie le texte exactement, ou utilise @edit ' + rel + ' lignes début-fin');
  if (hits.length > 1) throw new Error('texte CHERCHE ' + nb + ' apparaît ' + hits.length + ' fois dans ' + rel + ' (indentation ignorée ; lignes ' + hits.slice(0, 8).map(h => h + 1).join(', ') + ') (aucun fichier modifié) : ajoute des lignes autour pour le rendre unique');
  const h = hits[0], ind = (x) => /^[ \t]*/.exec(x)[0], fInd = ind(F[h]), sInd = ind(S.find(x => x.trim()));
  // correspondance indentation de la recherche -> indentation réelle du fichier (ligne par ligne)
  const mp = new Map(); for (let j = 0; j < S.length; j++) { if (!S[j].trim()) continue; const si = ind(S[j]); if (!mp.has(si)) mp.set(si, ind(F[h + j])); }
  const keys = [...mp.keys()].sort((x, y) => y.length - x.length);
  let R = p.r.replace(/\r/g, '').split('\n'); while (R.length && !R[0].trim()) R.shift(); while (R.length && !R[R.length - 1].trim()) R.pop();
  R = R.map(l => { if (!l.trim()) return ''; const li = ind(l), rest = l.slice(li.length); if (mp.has(li)) return mp.get(li) + rest; const k = keys.find(x => li.startsWith(x)); return k !== undefined ? mp.get(k) + li.slice(k.length) + rest : fInd + li + rest; });
  F.splice(h, S.length, ...R);
  return F.join('\n');
}

// ---- 4.2.0 : économie de crédits ----
// Lectures groupées, plan de fichier (@outline), lecture d'une seule fonction (fn:nom), cache « déjà lu, inchangé »,
// recherche groupée par fichier, remplacement multi-fichiers (@replace), sorties de commandes compactées.
const LOC_RCACHE = new Map();
const LOC_ANSI = /\x1b\[[0-9;?]*[ -\/]*[@-~]/g;
const cutTxt = (x, n) => { x = String(x == null ? '' : x).trim().replace(/\s+/g, ' '); return x.length > n ? x.slice(0, n - 1) + '…' : x; };
// Nettoie la sortie d'une commande : couleurs, barres de progression, avertissements npm, lignes identiques répétées.
// Au-delà de cap : on garde le début, la FIN (le résumé y est presque toujours) et les lignes d'erreur avec leur contexte.
function locSmart(out, cap) {
  let s = String(out == null ? '' : out).replace(LOC_ANSI, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const before = s.length;
  const NOISE = /^\s*(npm (WARN|warn|notice)\b|\(node:\d+\) |[⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏]|\d{1,3}%\s)/;
  const L = [];
  for (const l0 of s.split('\n')) {
    const l = l0.replace(/[ \t]+$/, '');
    if (NOISE.test(l)) continue;
    const last = L.length - 1;
    if (last >= 0 && l && L[last].t === l) { L[last].n++; continue; }
    L.push({ t: l, n: 1 });
  }
  let lines = L.map(x => x.n > 1 ? x.t + '  (×' + x.n + ')' : x.t);
  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
  const prev = lines; lines = prev.filter((l, i) => l.trim() || (i && prev[i - 1].trim()));
  let res = lines.join('\n');
  if (res.length > cap) {
    const ln = res.split('\n'), N = ln.length, keep = new Set();
    const add = (a, b) => { for (let i = Math.max(0, a); i < Math.min(N, b); i++) keep.add(i); };
    let tn = 0, tl = 0; while (tn < N && tl < cap * .35) { tl += ln[N - 1 - tn].length + 1; tn++; } add(N - tn, N);
    let hn = 0, hl = 0; while (hn < N && hl < cap * .2) { hl += ln[hn].length + 1; hn++; } add(0, hn);
    let used = 0; for (const i of keep) used += ln[i].length + 1;
    const ERR = /(error|erreur|fail|✕|✖|exception|traceback|assert|expected|received|cannot |can't |not found|undefined|warning:|\bat .*:\d+:\d+)/i;
    for (let i = 0; i < N && used < cap * .95; i++) { if (keep.has(i) || !ERR.test(ln[i])) continue; for (let k = Math.max(0, i - 1); k <= Math.min(N - 1, i + 1); k++) if (!keep.has(k)) { keep.add(k); used += ln[k].length + 1; } }
    const o = []; let last = -1;
    for (let i = 0; i < N; i++) { if (!keep.has(i)) continue; if (i !== last + 1) o.push('[… ' + (i - last - 1) + ' lignes omises …]'); o.push(ln[i].length > 400 ? ln[i].slice(0, 400) + '…' : ln[i]); last = i; }
    if (last < N - 1) o.push('[… ' + (N - 1 - last) + ' lignes omises …]');
    res = o.join('\n');
  }
  return { out: res, saved: Math.max(0, before - res.length) };
}
// Fichiers protégés par les règles du projet (même logique que côté interface) : @replace ne touche jamais à un fichier interdit.
function locForbid(forbid, rel) {
  const L = String(forbid || '').split(/[\n,;]+/).map(x => x.trim().replace(/\\/g, '/').replace(/^\.\//, '')).filter(Boolean); if (!L.length) return '';
  const p = String(rel || '').trim().replace(/\\/g, '/').replace(/^\.\//, ''); if (!p) return '';
  const segs = p.split('/'), bn = segs[segs.length - 1];
  const gre = g => new RegExp('^' + String(g).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*/g, '\u0001').replace(/\*/g, '[^/]*').replace(/\u0001/g, '.*').replace(/\?/g, '[^/]') + '$', 'i');
  for (const g of L) {
    const dir = g.endsWith('/'), gg = dir ? g.slice(0, -1) : g;
    if (dir) { if (p === gg || p.startsWith(gg + '/') || (!gg.includes('/') && segs.includes(gg))) return g; }
    else if (gg.includes('/')) { if (gre(gg).test(p) || p.startsWith(gg + '/')) return g; }
    else if (gre(gg).test(bn) || segs.includes(gg)) return g;
  }
  return '';
}
// Motif de définition d'un symbole (fonction, classe, constante, titre markdown…) pour @read chemin fn:nom
function locSymRe(name) {
  const n = String(name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(
    '(?:\\b(?:function\\*?|class|interface|enum|struct|trait|type|def|func|fn|object|record|module)\\s+(?:\\([^)]*\\)\\s*)?' + n + '\\b)' +
    '|(?:\\b(?:const|let|var)\\s+' + n + '\\s*=)' +
    '|(?:^\\s*(?:export\\s+)?(?:async\\s+)?(?:static\\s+)?' + n + '\\s*(?:=\\s*(?:async\\s*)?(?:function\\b|\\([^)]*\\)\\s*=>|[\\w$]+\\s*=>)|\\([^)]*\\)\\s*(?::\\s*[\\w<>\\[\\], |]+)?\\s*\\{))' +
    '|(?:^\\s*#{1,6}\\s+.*\\b' + n + '\\b)' +
    '|(?:\\b' + n + '\\s*[:=]\\s*(?:async\\s*)?function\\b)' +
    '|(?:^\\s*(?:module\\.)?exports\\.' + n + '\\s*=)');
}
// Dernière ligne du bloc qui commence à la ligne i (indentation pour Python, titres pour Markdown, accolades sinon)
function locSymEnd(L, i, ext) {
  const ind = x => /^[ \t]*/.exec(x)[0].replace(/\t/g, '    ').length, first = L[i];
  if (ext === '.py' || (/^\s*(async\s+)?(def|class)\b/.test(first) && !first.includes('{'))) {
    const base = ind(first); let last = i;
    for (let j = i + 1; j < L.length; j++) { if (!L[j].trim()) continue; if (ind(L[j]) <= base && !/^\s*[)\]}]/.test(L[j])) break; last = j; }
    return last;
  }
  if (ext === '.md' || /^\s*#{1,6}\s/.test(first)) {
    const lv = (/^\s*(#+)/.exec(first) || ['', '#'])[1].length; let j = i + 1;
    for (; j < L.length; j++) { const m = /^\s*(#+)\s/.exec(L[j]); if (m && m[1].length <= lv) break; }
    return j - 1;
  }
  let depth = 0, seen = false;
  for (let j = i; j < Math.min(L.length, i + 600); j++) {
    const l = L[j].length > 3000 ? '' : L[j].replace(/(["'`])(?:\\.|(?!\1).)*\1/g, '""').replace(/\/\/.*$/, '');
    for (const ch of l) { if (ch === '{') { depth++; seen = true; } else if (ch === '}') { depth--; if (seen && depth <= 0) return j; } }
    if (!seen && j >= i + 6) break;
  }
  return Math.min(L.length - 1, i + 40);
}
// Lecture d'un fichier : plage début-fin, fonction (spec.sym) ou entier ; cache « déjà lu, inchangé » par conversation.
// 5.1.0 : @read joint les définitions des fonctions appelées (index local) : l'IA n'a plus besoin d'un tour de lecture de suivi. Désactivable : créer .aihub/deps-off
const DEP_KIND = { js: 'js', mjs: 'js', cjs: 'js', jsx: 'js', ts: 'js', tsx: 'js', py: 'py', go: 'go', rs: 'rs', java: 'cls', kt: 'cls', cs: 'cls', php: 'php', rb: 'rb' };
const DEP_MAP = new Map();
function depMap(root) {
  const base = realBase(root), c0 = DEP_MAP.get(base);
  if (c0 && Date.now() - c0.at < 30000) return c0.map;
  const map = new Map(); let bytes = 0, n = 0;
  try {
    for (const rel of Object.keys(idxLoad(root).files)) {
      const k = DEP_KIND[path.extname(rel).slice(1).toLowerCase()]; if (!k) continue;
      if (++n > 1500 || bytes > 30e6) break;
      let t; try { const full = path.join(base, rel), st = fs.statSync(full); if (st.size > 300000) continue; bytes += st.size; t = fs.readFileSync(full, 'utf8'); } catch { continue; }
      for (const [nm, ln] of idxSymbols(k, t, 300)) if (!map.has(nm)) map.set(nm, [rel, ln]);
    }
  } catch {}
  DEP_MAP.set(base, { at: Date.now(), map }); return map;
}
const DEP_KW = new Set(['if', 'for', 'while', 'switch', 'catch', 'function', 'return', 'else', 'with', 'new', 'typeof', 'await', 'async', 'require', 'console', 'push', 'join', 'map', 'filter', 'forEach', 'slice', 'split', 'test', 'exec', 'replace', 'includes', 'indexOf', 'trim', 'toString', 'String', 'Number', 'Boolean', 'Array', 'Object', 'Promise', 'Error', 'JSON', 'Math', 'Date', 'Set', 'Map', 'parseInt', 'parseFloat', 'setTimeout', 'setInterval', 'print', 'range', 'len', 'self', 'super', 'this']);
function locDeps(root, rel, body, from, to, zone) {
  try {
    if (!zone || body.length > 12000) return '';
    const k = DEP_KIND[path.extname(rel).slice(1).toLowerCase()]; if (!k) return '';
    if (fs.existsSync(path.join(aihDir(root), 'deps-off'))) return '';
    const own = new Set(idxSymbols(k, body, 300).map(x => x[0])), map = depMap(root), seen = new Set(), parts = []; let size = 0;
    for (const mm of body.matchAll(/\b([A-Za-z_$][\w$]{3,})\s*\(/g)) {
      const nm = mm[1]; if (seen.has(nm) || own.has(nm) || DEP_KW.has(nm)) continue; seen.add(nm);
      const d = map.get(nm); if (!d) continue; if (d[0] === rel && d[1] >= from && d[1] <= to) continue;
      let t; try { t = fs.readFileSync(path.join(realBase(root), d[0]), 'utf8').split(/\r?\n/); } catch { continue; }
      const chunk = t.slice(d[1] - 1, d[1] + 7).map(x => x.slice(0, 160)).join('\n');
      if (size + chunk.length > 1800) break; size += chunk.length; parts.push('--- ' + nm + ' : ' + d[0] + ':' + d[1] + ' ---\n' + chunk);
      if (parts.length >= 6) break;
    }
    return parts.length ? '\n\n[DÉFINITIONS LIÉES (jointes par AI Hub, ne les relis pas)]\n' + parts.join('\n') : '';
  } catch { return ''; }
}
function locReadFile(root, relArg, spec, c, force) {
  const s = locSafe(root, relArg); let st; try { st = fs.statSync(s.full); } catch { throw new Error(s.rel + ' n\'existe pas'); }
  if (st.isDirectory()) throw new Error('c\'est un dossier : utilise @tree ' + s.rel);
  if (locIsBinary(s.full)) throw new Error('fichier binaire (' + st.size + ' octets) : lecture refusée, utilise @stat');
  const rg = /^(\d+)?-(\d+)?$/.exec(spec.range || ''), single = /^\d+$/.test(spec.range || ''), range = !!rg || single;
  if (st.size > LOC_MAXFILE * 5 && !rg && !spec.sym) throw new Error('fichier trop gros (' + Math.round(st.size / 1024) + ' Ko) : utilise @outline ' + s.rel + ' puis @read ' + s.rel + ' début-fin (ou fn:nom), ou @grep');
  const sess = c && c.opts && c.opts.sess, tag = spec.sym ? 'fn:' + spec.sym : (spec.range || '');
  const ck = sess ? sess + '|' + realBase(root) + '|' + s.rel + '|' + (tag || '*') : '';
  if (ck && !force) {
    const o = LOC_RCACHE.get(ck);
    if (o && o.m === st.mtimeMs && o.s === st.size) {
      seenMark(root, s.rel, s.full);
      return { title: 'read ' + s.rel + (tag ? ' ' + tag : '') + ' (déjà lu, inchangé)', out: '(identique à ta lecture précédente dans cette conversation, fichier inchangé : réutilise ce que tu as déjà. Pour le recevoir à nouveau : @read -f ' + s.rel + (spec.range ? ' ' + spec.range : '') + ')', saved: o.len };
    }
  }
  const lines = fs.readFileSync(s.full, 'utf8').split(/\r?\n/);
  let from = 1, to = lines.length, cond = '', label = '';
  if (spec.sym) {
    const re = locSymRe(spec.sym), ext = path.extname(s.rel).toLowerCase(), hits = [];
    for (let i = 0; i < lines.length; i++) { if (lines[i].length > 4000) continue; if (re.test(lines[i])) hits.push(i); }
    if (!hits.length) throw new Error('« ' + spec.sym + ' » introuvable dans ' + s.rel + ' : essaie @outline ' + s.rel + ' ou @grep ' + spec.sym);
    const i0 = hits[0], e0 = Math.min(locSymEnd(lines, i0, ext), i0 + 399);
    from = i0 + 1; to = e0 + 1; label = ', ' + spec.sym + (hits.length > 1 ? ', autres définitions : lignes ' + hits.slice(1, 6).map(x => x + 1).join('/') : '');
  } else if (rg) { from = Math.max(1, parseInt(rg[1], 10) || 1); to = Math.min(lines.length, parseInt(rg[2], 10) || lines.length); }
  else if (single) { from = Math.max(1, parseInt(spec.range, 10)); }
  if (from > lines.length) throw new Error('ligne ' + from + ' hors du fichier (' + lines.length + ' lignes)');
  let body = lines.slice(from - 1, to).join('\n');
  // fichier long lu en entier : on garde le début, la fin et les lignes qui contiennent les mots de la demande
  const toks = ((c && c.opts && c.opts.focus) || []).map(x => String(x).toLowerCase()).filter(x => x.length >= 3).slice(0, 12);
  if (!range && !spec.sym && body.length > 20000 && toks.length) {
    const keep = new Set(), win = (x, y) => { for (let i = Math.max(0, x); i < Math.min(lines.length, y); i++) keep.add(i); };
    win(0, 60); win(lines.length - 40, lines.length); let size = 0; for (const i of keep) size += lines[i].length + 1;
    for (let i = 0; i < lines.length && size < 16000; i++) { if (keep.has(i) || lines[i].length > 800) continue; const l = lines[i].toLowerCase(); if (toks.some(x => l.includes(x))) { const add = []; for (let k = Math.max(0, i - 3); k < Math.min(lines.length, i + 4); k++) if (!keep.has(k)) add.push(k); for (const k of add) { keep.add(k); size += lines[k].length + 1; } } }
    const out = []; let last = -1;
    for (let i = 0; i < lines.length; i++) { if (!keep.has(i)) continue; if (i !== last + 1) out.push('[… lignes ' + (last + 2) + '-' + i + ' omises …]'); out.push(lines[i]); last = i; }
    if (last < lines.length - 1) out.push('[… lignes ' + (last + 2) + '-' + lines.length + ' omises …]');
    body = '[fichier long : début, fin et lignes proches de la demande. Pour une zone précise : @outline ' + s.rel + ' puis @read ' + s.rel + ' début-fin ou fn:nom]\n' + out.join('\n'); cond = ', condensé';
  }
  seenMark(root, s.rel, s.full);
  const deps = locDeps(root, s.rel, body, from, to, !!(range || spec.sym)); if (ck) { LOC_RCACHE.set(ck, { m: st.mtimeMs, s: st.size, len: body.length }); if (LOC_RCACHE.size > 600) LOC_RCACHE.delete(LOC_RCACHE.keys().next().value); }
  return { title: 'read ' + s.rel + ' (' + (to - from + 1) + ' lignes' + (range || spec.sym ? ', ' + from + '-' + to : '') + ' sur ' + lines.length + cond + label + ')', out: body + deps };
}
// Plan d'un fichier : une ligne par fonction / classe / titre / clé, avec son numéro de ligne.
function locOutline(root, relArg) {
  const s = locSafe(root, relArg); let st; try { st = fs.statSync(s.full); } catch { throw new Error(s.rel + ' n\'existe pas'); }
  if (st.isDirectory()) throw new Error(s.rel + ' est un dossier : utilise @tree ' + s.rel);
  if (locIsBinary(s.full)) throw new Error(s.rel + ' est binaire');
  if (st.size > 3 * 1024 * 1024) throw new Error(s.rel + ' est trop gros (' + Math.round(st.size / 1024) + ' Ko) : utilise @grep');
  const text = fs.readFileSync(s.full, 'utf8'), L = text.split(/\r?\n/), ext = path.extname(s.rel).toLowerCase(), kind = IDX_KIND[ext], out = [];
  let n = 0;
  if (ext === '.json') {
    try { const j = JSON.parse(text.replace(/^\uFEFF/, '')); const ks = Array.isArray(j) ? ['(tableau de ' + j.length + ' éléments)'] : Object.keys(j).slice(0, 80).map(k => k + ' : ' + (Array.isArray(j[k]) ? 'tableau[' + j[k].length + ']' : j[k] && typeof j[k] === 'object' ? 'objet{' + Object.keys(j[k]).length + '}' : typeof j[k])); for (const k of ks) { out.push(k); n++; } }
    catch (e) { out.push('(JSON invalide : ' + cutTxt(e.message, 100) + ')'); }
  } else if (ext === '.css' || ext === '.scss' || ext === '.less') {
    for (let i = 0; i < L.length && n < 160; i++) { const m = /^([^\s@}{/*][^{]{0,100})\{\s*/.exec(L[i]) || /^(@(?:media|keyframes|font-face)[^{]{0,80})\{/.exec(L[i]); if (m) { out.push((i + 1) + '  ' + cutTxt(m[1], 90)); n++; } }
  } else if (kind) {
    for (const [nm, ln] of idxSymbols(kind, text, 220)) { const src = L[ln - 1] || ''; out.push(ln + '  ' + (src.length > 170 ? nm + '  (ligne très longue)' : cutTxt(src, 100))); n++; }
    out.sort((x, y) => parseInt(x, 10) - parseInt(y, 10));
    if (/^\.(html?|vue|svelte)$/.test(ext)) for (let i = 0; i < L.length; i++) { const m = /<(script|style)\b/i.exec(L[i]); if (m) { let j = i; const cl = new RegExp('</' + m[1] + '>', 'i'); while (j < L.length && !cl.test(L[j])) j++; out.unshift('<' + m[1].toLowerCase() + '> lignes ' + (i + 1) + '-' + (j + 1)); i = j; } }
  }
  const total = out.length, shown = out.slice(0, 170);
  if (total > 170) shown.push('… (+' + (total - 170) + ' autres)');
  return { rel: s.rel, text: '=== ' + s.rel + ' (' + L.length + ' lignes, ' + Math.round(st.size / 1024 * 10) / 10 + ' Ko, ' + total + ' repères) ===\n' + (shown.join('\n') || 'aucun repère détecté : @read ' + s.rel + ' 1-60 ou @grep texte ' + s.rel), n: total };
}

// <CTX> Contexte ULTRA (4.10) : index local BM25 + vecteurs hachés + synonymes FR/EN. Aucun réseau, aucun crédit. Données : .aihub/ctx.json (v:2)
const CTX_DIM = 128, CTX_MAXCHUNKS = 60000, CTX_FILE_MAX = 1536 * 1024;   // plus large que l'ancien index (400 Ko) : les gros fichiers d'interface sont découpés en blocs
const CTX_GROUPS = [
  ['connexion', 'login', 'signin', 'auth', 'authentification', 'authenticate', 'session', 'logout', 'deconnexion'],
  ['supprimer', 'delete', 'remove', 'effacer', 'suppression', 'retirer'],
  ['erreur', 'error', 'bug', 'exception', 'echec', 'fail', 'failure', 'crash', 'plantage'],
  ['dossier', 'folder', 'directory', 'repertoire'],
  ['envoyer', 'send', 'envoi', 'submit', 'poster', 'post'],
  ['lire', 'read', 'lecture', 'charger', 'load', 'ouvrir', 'open'],
  ['ecrire', 'write', 'ecriture', 'sauvegarder', 'save', 'enregistrer', 'sauvegarde'],
  ['chercher', 'search', 'find', 'recherche', 'trouver', 'grep'],
  ['compte', 'account', 'cle', 'key', 'token'],
  ['limite', 'limit', 'quota', 'plafond'],
  ['afficher', 'display', 'show', 'render', 'dessiner', 'draw', 'affichage'],
  ['message', 'msg', 'chat', 'conversation', 'discussion'],
  ['maj', 'update', 'upgrade', 'miseajour', 'patch', 'version'],
  ['reponse', 'response', 'reply', 'answer', 'resultat', 'result'],
  ['parametre', 'setting', 'settings', 'config', 'configuration', 'option', 'reglage', 'preference'],
  ['fenetre', 'window', 'dialog', 'dialogue', 'popup', 'modal'],
  ['bouton', 'button', 'btn', 'clic', 'click'],
  ['image', 'img', 'photo', 'picture', 'capture', 'screenshot'],
  ['piece', 'attach', 'attachment', 'joint', 'upload', 'televerser'],
  ['file', 'queue', 'attente', 'pending'],
  ['style', 'css', 'couleur', 'color', 'theme', 'design'],
  ['test', 'verifier', 'verify', 'check', 'controle', 'validation', 'valider'],
];
const CTX_GRP = new Map(); CTX_GROUPS.forEach((g, i) => g.forEach(w => { if (!CTX_GRP.has(w)) CTX_GRP.set(w, '~g' + i); }));
const ctxH = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
function ctxStem(w) { if (w.length <= 4) return w; const r = w.replace(/(ements|ement|ations|ation|ings|ing|ed|es|s)$/, ''); return r.length >= 4 ? r : w; }
function ctxTokens(text, max) {
  const out = [], s = String(text || '').slice(0, max || 8000).replace(/([a-z0-9])([A-Z])/g, '$1 $2');
  for (const w0 of s.split(/[^\p{L}\p{N}]+/u)) {
    if (!w0) continue; const w = idxNorm(w0); if (w.length < 2 || w.length > 40 || IDX_STOP.has(w)) continue;
    const st = ctxStem(w); out.push(st); const g = CTX_GRP.get(w) || CTX_GRP.get(st); if (g) out.push(g);
  }
  return out;
}
function ctxVec(toks) {
  const v = new Float32Array(CTX_DIM), tf = new Map();
  for (const t of toks) tf.set(t, (tf.get(t) || 0) + 1);
  for (const [t, c] of tf) { const h = ctxH(t); v[h % CTX_DIM] += ((h >>> 16) & 1 ? -1 : 1) * (1 + Math.log(c)); }
  for (let i = 0; i + 1 < Math.min(toks.length, 400); i++) { const h = ctxH(toks[i] + '_' + toks[i + 1]); v[h % CTX_DIM] += ((h >>> 16) & 1 ? -0.5 : 0.5); }
  let mx = 0; for (let i = 0; i < CTX_DIM; i++) mx = Math.max(mx, Math.abs(v[i]));
  const q = new Int8Array(CTX_DIM); if (mx > 0) for (let i = 0; i < CTX_DIM; i++) q[i] = Math.round(v[i] / mx * 127);
  return Buffer.from(q.buffer).toString('base64');
}
const ctxUnpack = (b64) => { const b = Buffer.from(b64 || '', 'base64'); return new Int8Array(b.buffer, b.byteOffset, Math.min(b.length, CTX_DIM)); };
function ctxCos(a, b) { let d = 0, na = 0, nb = 0; const n = Math.min(a.length, b.length); for (let i = 0; i < n; i++) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; } return na && nb ? d / Math.sqrt(na * nb) : 0; }
// Découpage : un bloc par fonction/classe (si le fichier en a au moins 2), sinon fenêtres de 40 lignes qui se chevauchent
function ctxChunk(rel, text, kind) {
  const L = text.split('\n'), N = L.length, syms = kind ? idxSymbols(kind, text, 200) : [], pieces = [];
  const windows = (a, b, sym) => { for (let s = a; s <= b; s += 32) { pieces.push({ a: s, b: Math.min(b, s + 39), y: sym || '' }); if (s + 39 >= b) break; } };
  if (syms.length >= 2) {
    const S = syms.map(x => [x[0], x[1] - 1]).sort((p, q) => p[1] - q[1]);
    if (S[0][1] > 0) windows(0, S[0][1] - 1, '');
    for (let i = 0; i < S.length; i++) { const a = S[i][1], b = (i + 1 < S.length ? S[i + 1][1] : N) - 1; if (b < a) continue; if (b - a > 70) windows(a, b, S[i][0]); else pieces.push({ a, b, y: S[i][0] }); }
  } else windows(0, N - 1, '');
  const pt = ctxTokens(rel, 300), out = [];
  for (const p of pieces.slice(0, 600)) {
    const body = L.slice(p.a, p.b + 1).join('\n'), toks = ctxTokens(body, 6000).concat(pt, ctxTokens(p.y, 100), ctxTokens(p.y, 100)), tf = {};
    for (const t of toks) tf[t] = (tf[t] || 0) + 1;
    const top = Object.entries(tf).sort((x, y) => y[1] - x[1]).slice(0, 80), t = {}; for (const [k, c] of top) t[k] = c;
    out.push({ a: p.a + 1, b: p.b + 1, y: p.y, n: toks.length, t, v: ctxVec(toks) });
  }
  return out;
}
const ctxPath = (root) => path.join(aihDir(root), 'ctx.json');
const CTX_MEM = new Map();
function ctxBuild(root, mem) {
  const base = realBase(root); let idx = mem && mem.idx;
  if (!idx) { try { const j = JSON.parse(fs.readFileSync(ctxPath(root), 'utf8')); if (j && j.v === 2 && j.files) idx = j; } catch {} }
  if (!idx) idx = { v: 2, files: {} };
  const seen = new Set(); let n = 0, changed = false, budget = 60 * 1024 * 1024, total = 0;
  for (const x of locWalk(base, base, 10)) {
    if (x.e.isDirectory()) continue; if (++n > 4000) break;
    if (IDX_SKIP.test(x.rel)) continue;
    let st; try { st = fs.statSync(x.full); } catch { continue; }
    if (st.size > CTX_FILE_MAX) continue;
    const old = idx.files[x.rel], m = Math.floor(st.mtimeMs);
    if (old && old.m === m && old.s === st.size) { seen.add(x.rel); total += old.c.length; continue; }
    if (budget <= 0 || total >= CTX_MAXCHUNKS) continue;
    if (locIsBinary(x.full)) continue;
    let text = ''; try { text = fs.readFileSync(x.full, 'utf8'); budget -= text.length; } catch { continue; }
    const kind = IDX_KIND[path.extname(x.rel).toLowerCase()], c = ctxChunk(x.rel, text, kind);
    idx.files[x.rel] = { m, s: st.size, l: nLines(text), c }; seen.add(x.rel); total += c.length; changed = true;
  }
  for (const k of Object.keys(idx.files)) if (!seen.has(k)) { delete idx.files[k]; changed = true; }
  if (changed) { try { fs.mkdirSync(aihDir(root), { recursive: true }); const tmp = ctxPath(root) + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(idx)); fs.renameSync(tmp, ctxPath(root)); } catch {} }
  const df = Object.create(null); let N = 0, len = 0;
  for (const e of Object.values(idx.files)) for (const c of e.c) { N++; len += c.n; for (const k in c.t) df[k] = (df[k] || 0) + 1; }
  const by = {};
  for (const rel of Object.keys(idx.files)) (by[path.basename(rel)] = by[path.basename(rel)] || []).push(rel);
  const groups = Object.values(by).filter(g => g.length > 1 && g.length <= 6);
  const gk = groups.map(g => g.map(r => r + '@' + idx.files[r].m).sort().join(',')).sort().join(';');
  let dup = mem && mem.gk === gk && mem.dup;
  if (!dup) {
    dup = new Set();   // copies anciennes d'un même fichier (au moins 60 % de lignes communes avec une copie plus récente) : ignorées par la recherche
    const sig = (rel) => { const s = new Set(); try { for (const l of fs.readFileSync(path.join(base, rel), 'utf8').split('\n')) { const t = l.trim(); if (t.length > 20) s.add(t); } } catch {} return s; };
    for (const g0 of groups) {
      const g = g0.slice().sort((a, b) => idx.files[b].m - idx.files[a].m), S = g.map(sig);
      for (let i = 1; i < g.length; i++) for (let j = 0; j < i; j++) {
        if (S[i].size < 5) break; let c = 0; for (const t of S[i]) if (S[j].has(t)) c++;
        if (c / S[i].size >= 0.6) { dup.add(g[i]); break; }
      }
    }
  }
  return { idx, df, N, avg: N ? len / N : 1, at: Date.now(), gk, dup };
}
function ctxLoad(root) {
  const base = realBase(root); let m = CTX_MEM.get(base);
  if (m && Date.now() - m.at < 15000) return m;
  m = ctxBuild(root, m); CTX_MEM.set(base, m); return m;
}
// Recherche : BM25 + cosinus des vecteurs + bonus (symbole, chemin, fichier récent) ; au plus 2 blocs par fichier
function ctxSearch(root, q, n, extra) {
  const M = ctxLoad(root), toks = [...new Set(ctxTokens(q, 600))], now = Date.now();
  if (!toks.length || !M.N) return [];
  const qv = ctxUnpack(ctxVec(ctxTokens(q, 600))), K1 = 1.2, B = 0.75, hits = [];
  for (const [rel, e] of Object.entries(M.idx.files)) {
    if (M.dup && M.dup.has(rel)) continue;
    const rl = idxNorm(rel), rec = now - e.m < 7 * 864e5 ? 0.5 : 0, ex = (extra && extra.has && extra.has(rel)) ? 2 : 0;
    for (const c of e.c) {
      let bm = 0;
      for (const t of toks) { const f = c.t[t]; if (!f) continue; const d = M.df[t] || 1, idf = Math.log(1 + (M.N - d + 0.5) / (d + 0.5)); bm += idf * (f * (K1 + 1)) / (f + K1 * (1 - B + B * c.n / M.avg)); }
      const cos = ctxCos(qv, c._v || (c._v = ctxUnpack(c.v)));
      let sc = bm + 6 * Math.max(0, cos) + rec + ex;
      if (c.y) { const yn = idxNorm(c.y); if (toks.some(t => yn === t || (t.length >= 4 && yn.includes(t)))) sc += 3; }
      if (toks.some(t => t.length >= 4 && rl.includes(t))) sc += 1.5;
      if (sc > 1.5) hits.push({ rel, a: c.a, b: c.b, y: c.y, score: sc, m: e.m, bn: path.basename(rel) });
    }
  }
  hits.sort((x, y) => y.score - x.score);
  const per = {}, out = [];
  // copies d'un même fichier (ancienne version dans un autre dossier) : on ne garde que la plus récente
  const tw = new Map(), uniq = [];
  for (const h of hits) {
    const k = h.bn + '|' + h.y + '|' + (h.b - h.a) + (h.y ? '' : '|' + h.a), o = tw.get(k);
    if (o && o.rel !== h.rel) { if (h.m > o.m) { const i = uniq.indexOf(o); if (i >= 0) uniq[i] = h; tw.set(k, h); } continue; }
    if (!o) tw.set(k, h); uniq.push(h);
  }
  for (const h of uniq) { if ((per[h.rel] = (per[h.rel] || 0) + 1) > 2) continue; out.push(h); if (out.length >= (n || 6)) break; }
  return out;
}
function ctxSnippet(root, h, maxChars) {
  try { const L = fs.readFileSync(path.join(realBase(root), h.rel), 'utf8').split('\n'); let s = L.slice(h.a - 1, h.b).join('\n'); if (s.length > maxChars) s = s.slice(0, Math.max(0, maxChars - 1)) + '…'; return s; } catch { return ''; }
}
// ---- 5 : contexte git (fichiers non commités, branche), cache 60 s, 0 réseau ----
let CTX_ON = true;
const CTX_GIT = new Map();
function ctxGitRun(root, args, ms) {
  try { return cp.execFileSync('git', ['-c', 'core.quotepath=false'].concat(args), { cwd: realBase(root), windowsHide: true, timeout: ms || 6000, maxBuffer: 4 * 1024 * 1024, stdio: ['ignore', 'pipe', 'ignore'], encoding: 'utf8' }); } catch { return null; }
}
function ctxGit(root) {
  const base = realBase(root), c = CTX_GIT.get(base);
  if (c && Date.now() - c.at < 60000) return c.v;
  const v = { ok: false, dirty: new Set(), branch: '' };
  const top = ctxGitRun(root, ['rev-parse', '--show-prefix'], 3000);
  if (top !== null) {
    v.ok = true; const pre = top.trim();
    const st = ctxGitRun(root, ['status', '--porcelain', '-uall'], 8000) || '';
    for (const l of st.split('\n')) {
      if (l.length < 4) continue; let p = l.slice(3).trim(); const ar = p.indexOf(' -> '); if (ar >= 0) p = p.slice(ar + 4);
      p = p.replace(/^"|"$/g, ''); if (pre) { if (!p.startsWith(pre)) continue; p = p.slice(pre.length); } v.dirty.add(p);
    }
    v.branch = (ctxGitRun(root, ['rev-parse', '--abbrev-ref', 'HEAD'], 3000) || '').trim();
  }
  CTX_GIT.set(base, { at: Date.now(), v }); return v;
}
function ctxLog(root, rel, n) {
  const out = ctxGitRun(root, ['log', '-n', String(n || 8), '--date=short', '--pretty=format:%h  %ad  %an  %s'].concat(rel ? ['--', rel] : []), 8000);
  return out === null ? null : out.trim();
}
// ---- 7 : pré-lecture par blocs pertinents (BM25 + vecteurs + git) ; null = repli sur l'ancien classement ----
function ctxPre(root, q, cap) {
  const g = ctxGit(root), hits = ctxSearch(root, q, 8, g.dirty); if (!hits.length) return null;
  let used = 0, pre = ''; const files = [];
  for (const h of hits) {
    const remain = cap - used - 160; if (remain < 300) break;
    if (LOC_SEEN.has(seenKey(root, h.rel)) && !g.dirty.has(h.rel)) continue;      // 4.12 (J2) : fichier déjà lu et inchangé : pas de doublon dans la pré-lecture
    const snip = ctxSnippet(root, h, Math.min(remain, 1800)); if (!snip) continue;
    pre += (pre ? '\n' : '') + '=== ' + h.rel + ' (lignes ' + h.a + '-' + h.b + (h.y ? ', ' + h.y : '') + (g.dirty.has(h.rel) ? ', modifié non commité' : '') + ') ===\n' + snip;
    used += snip.length + 90; if (!files.includes(h.rel)) files.push(h.rel);
  }
  if (!pre) return null;
  return { pre: 'PRÉ-LECTURE CONTEXTE (blocs les plus pertinents de l\'index local, extraits seulement : @read la zone si tu as besoin du fichier complet) :\n' + pre + '\n', files };
}
// ---- 8 : résumé compact et STABLE du projet, ajouté à la CARTE (aucune heure, aucun git, chiffres arrondis : la CARTE reste « inchangée » d'un tour à l'autre) ----
function ctxDigest(idx) {
  const dirs = new Map(), ext = new Map(), keys = []; let nf = 0, nl = 0;
  for (const [rel, e] of Object.entries(idx.files)) {
    if (e.b) continue;
    nf++; nl += e.l || 0;
    const parts = rel.split('/'), top = parts.length > 1 ? parts.slice(0, Math.min(2, parts.length - 1)).join('/') : '.';
    const d = dirs.get(top) || { n: 0, l: 0 }; d.n++; d.l += e.l || 0; dirs.set(top, d);
    const x = path.extname(rel).slice(1).toLowerCase(); if (x) ext.set(x, (ext.get(x) || 0) + (e.l || 0));
    if (parts.length <= 2 && /^(readme|plan|package\.json|pyproject|build\.|manifest|cargo\.toml|go\.mod|makefile)/i.test(parts[parts.length - 1])) keys.push(rel);
  }
  if (!nf) return '';
  const tl = [...ext.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(([x, l]) => x + ' ' + (5 * Math.round(20 * l / Math.max(1, nl))) + '%').join(', ');
  const dl = [...dirs.entries()].sort((a, b) => b[1].l - a[1].l).slice(0, 6).map(([d, v]) => (d === '.' ? 'racine' : d + '/') + ' (' + v.n + ' f)').join(', ');
  return ('RÉSUMÉ : ' + nf + ' fichiers texte, ~' + Math.max(1, Math.round(nl / 1000)) + 'k lignes (' + tl + '). Dossiers : ' + dl + '.' + (keys.length ? ' Clés : ' + keys.slice(0, 6).join(', ') + '.' : '') + ' @ctx question = recherche par sens dans tout le projet.').slice(0, 700);
}
// </CTX>
const LOC_VERBS = {
  ctx(root, a) {
    let n = 6; const q = String(a || '').replace(/(?:^|\s)-n\s*(\d+)/, (m, d) => { n = Math.max(1, Math.min(12, +d)); return ' '; }).trim();
    if (!q) throw new Error('question manquante, exemple : @ctx où gère-t-on la connexion ?');
    const g = ctxGit(root), hits = ctxSearch(root, q, n, g.dirty);
    if (!hits.length) return { title: 'ctx (0 résultat)', out: 'aucun bloc pertinent : reformule avec d\'autres mots, ou @grep un mot précis' };
    const per = Math.max(500, Math.floor(9000 / hits.length));
    const parts = hits.map(h => '=== ' + h.rel + ' (lignes ' + h.a + '-' + h.b + (h.y ? ', ' + h.y : '') + (g.dirty.has(h.rel) ? ', modifié non commité' : '') + ', score ' + h.score.toFixed(1) + ') ===\n' + ctxSnippet(root, h, per));
    return { title: 'ctx ' + q.slice(0, 50) + ' (' + hits.length + ' blocs)', out: parts.join('\n') };
  },
  refs(root, a) {
    const t = locArgs(a).filter(x => !x.startsWith('-')), sym = (t[0] || '').trim();
    if (!/^[\w$.]{2,60}$/.test(sym)) throw new Error('symbole manquant ou invalide, exemple : @refs maFonction');
    const M = ctxLoad(root), base = realBase(root), esc = sym.replace(/[.$]/g, '\\$&');
    const re = new RegExp('(^|[^\\w$])' + esc + '(?![\\w$])');
    const def = new RegExp('^\\s*(?:export\\s+)?(?:default\\s+)?(?:async\\s+)?(?:function\\*?|class|const|let|var|def|interface|type|enum|struct|fn|func)\\s+' + esc + '(?![\\w$])|^\\s*(?:async\\s+|static\\s+|get\\s+|set\\s+)*' + esc + '\\s*\\([^)]*\\)\\s*\\{|(?:^|[\\s,{])' + esc + '\\s*[:=]\\s*(?:async\\s*)?(?:function|\\(|[\\w$]+\\s*=>)');
    const defs = [], refs = {}; let nRef = 0, cut = false; const t0 = Date.now();
    for (const rel of Object.keys(M.idx.files)) {
      if (Date.now() - t0 > 4000) { cut = true; break; }
      let text; try { text = fs.readFileSync(path.join(base, rel), 'utf8'); } catch { continue; }
      if (!text.includes(sym)) continue;
      const L = text.split('\n');
      for (let i = 0; i < L.length; i++) {
        const l = L[i]; if (l.length > 400 || !l.includes(sym) || !re.test(l)) continue;
        const row = rel + ':' + (i + 1) + '  ' + l.trim().slice(0, 140);
        if (def.test(l)) { if (defs.length < 8) defs.push(row); } else { (refs[rel] = refs[rel] || []).push(row); nRef++; }
      }
    }
    const out = ['DÉFINITIONS (' + defs.length + ') :'].concat(defs.length ? defs.map(x => '  ' + x) : ['  (aucune trouvée)']);
    const files = Object.keys(refs).sort((x, y) => refs[y].length - refs[x].length); out.push('RÉFÉRENCES : ' + nRef + ' dans ' + files.length + ' fichier(s)');
    let shown = 0;
    for (const f of files) { const r = refs[f]; for (const row of r.slice(0, 3)) { out.push('  ' + row); shown++; } if (r.length > 3) out.push('  … +' + (r.length - 3) + ' autres dans ' + f); if (shown >= 30) { out.push('  … (liste coupée : précise avec @grep ' + sym + ' chemin)'); break; } }
    if (cut) out.push('(analyse interrompue après 4 s : résultats partiels)');
    return { title: 'refs ' + sym + ' (' + defs.length + ' déf., ' + nRef + ' réf.)', out: out.join('\n') };
  },
  diff(root, a) { // 4.11.0 : modifications non commitées (git diff)
    const t = locArgs(a).filter(x => !x.startsWith('-')), g = ctxGit(root);
    if (!g.ok) throw new Error('ce dossier n\'est pas un dépôt git');
    const args = ['diff', '--no-color', '-U2']; if (t[0]) args.push('--', locSafe(root, t[0]).rel);
    const r = cp.spawnSync('git', args, { cwd: realBase(root), encoding: 'utf8', timeout: 20000, windowsHide: true, maxBuffer: 8e6 }), out = String(r.stdout || '').trim();
    return { title: 'diff ' + (t[0] || '(tout)'), out: out ? locCap(out, 9000) : '(aucune différence non commitée)' };
  },
  async test(root, a, c) { // 4.11.0 : détecte et lance les tests du projet (300 s)
    const base = fs.realpathSync(root), has = (f) => fs.existsSync(path.join(base, f)), win = process.platform === 'win32', py = win ? 'python' : 'python3';
    let cmd = String(a || '').trim();
    if (!cmd) {
      let req = ''; try { req = fs.readFileSync(path.join(base, 'requirements.txt'), 'utf8'); } catch {}
      let top = []; try { top = fs.readdirSync(base); } catch {}
      if (projHasTest(root)) cmd = 'npm test';
      else if (has('pytest.ini') || has('conftest.py') || /pytest/i.test(req)) cmd = py + ' -m pytest -q';
      else if (top.some(f => /^test_.*\.py$/.test(f)) || has('tests')) cmd = py + ' -m unittest discover';
      else if (win && has('gradlew.bat')) cmd = 'gradlew.bat test';
      else if (has('gradlew')) cmd = './gradlew test';
      else if (has('pom.xml')) cmd = 'mvn -q test';
      else if (has('Cargo.toml')) cmd = 'cargo test';
      else if (has('go.mod')) cmd = 'go test ./...';
      else if (has('test') || top.some(f => /\.test\.js$/.test(f))) cmd = 'node --test';
    }
    if (!cmd) throw new Error('aucun test détecté : écris des tests (@scaffold node en crée un) ou @test commande');
    const r = await locProc(win ? 'chcp 65001>nul & ' + cmd : cmd, [], { cwd: base, shell: true, timeout: 300000 });
    return cmdOut(r, c, 'test ' + cmd.slice(0, 60), root);
  },
  scaffold(root, a) { // 4.11.0 : squelettes de projet (node, python, html, mc-fabric, mc-forge) ; ne remplace jamais un fichier existant
    const t = locArgs(a), kind = String(t[0] || '').toLowerCase(), nm = String(t[1] || '').replace(/[^\w.-]/g, ''), F = SCAF[kind];
    if (!F) throw new Error('@scaffold ' + Object.keys(SCAF).join(' | ') + ' [nom du dossier]');
    const pre = nm ? nm + '/' : '', files = F(nm || 'demo'), made = [];
    for (const rel of Object.keys(files)) { const s = locSafe(root, pre + rel); if (fs.existsSync(s.full)) continue; fs.mkdirSync(path.dirname(s.full), { recursive: true }); fs.writeFileSync(s.full, files[rel], 'utf8'); made.push(s.rel); }
    if (!made.length) throw new Error('rien créé : les fichiers existent déjà');
    return { title: 'scaffold ' + kind + ' (' + made.length + ' fichiers)', out: 'créés :\n' + made.join('\n') + (/^mc-/.test(kind) ? '\nvérifie les versions (Minecraft, loader, mappings) puis lance gradle wrapper si gradlew est absent' : ''), changed: true, rels: made };
  },
  history(root, a) {
    const raw = String(a || ''), nm = /(?:^|\s)-n\s*(\d+)/.exec(raw), n = nm ? Math.max(1, Math.min(30, +nm[1])) : 8;
    const t = locArgs(raw.replace(/(?:^|\s)-n\s*\d+/, ' ')).filter(x => !x.startsWith('-')), g = ctxGit(root);
    if (!g.ok) throw new Error('ce dossier n\'est pas un dépôt git');
    if (t[0]) { const s = locSafe(root, t[0]), log = ctxLog(root, s.rel, n); return { title: 'history ' + s.rel, out: (g.dirty.has(s.rel) ? '⚠ modifié, non commité\n' : '') + (log || '(aucun commit pour ce fichier)') }; }
    const dirty = [...g.dirty].slice(0, 40), log = ctxLog(root, '', n);
    return { title: 'history (' + (g.branch || 'git') + ')', out: 'NON COMMITÉS (' + g.dirty.size + ') :\n' + (dirty.length ? dirty.map(x => '  ' + x).join('\n') : '  (rien)') + (g.dirty.size > 40 ? '\n  …' : '') + '\n\nDERNIERS COMMITS :\n' + (log || '(aucun)') };
  },
  tree(root, a, c) {
    const t = locArgs(a), s = locSafe(root, t[0] || '.'), depth = Math.max(1, Math.min(6, parseInt(t[1], 10) || 2)), noGen = !!(c && c.opts && c.opts.noGen);
    if (!fs.statSync(s.full).isDirectory()) throw new Error('ce n\'est pas un dossier');
    const out = []; let n = 0;
    for (const x of locWalk(s.full, s.full, depth)) { if (noGen && !x.e.isDirectory() && GEN_NAME.test(x.e.name)) continue; if (++n > 200) { out.push('… (liste coupée à 200 entrées, précise un sous-dossier)'); break; }
      out.push('  '.repeat(x.depth) + x.e.name + (x.e.isDirectory() ? '/' : '')); }
    return { title: 'tree ' + s.rel + ' (' + Math.min(n, 200) + ' entrées)', out: out.join('\n') || '(dossier vide)' };
  },
  read(root, a, c) {
    let force = false;
    const t = locArgs(a).filter(x => { if (x === '-f' || x === '--force') { force = true; return false; } return true; });
    if (!t[0]) throw new Error('chemin manquant');
    const isRg = x => /^(\d+)?-(\d+)?$/.test(x || '') || /^\d+$/.test(x || '');
    const symM = /^(?:fn|sym|symbole|function|class|def):(.+)$/i.exec(t[1] || '');
    if (t.length === 1 || (t.length === 2 && (isRg(t[1]) || symM))) return locReadFile(root, t[0], symM ? { sym: symM[1] } : { range: isRg(t[1]) ? t[1] : '' }, c, force);
    // lecture groupée : @read a.js b.js:10-40 c.js#maFonction  (une seule instruction, un seul tour)
    const list = t.slice(0, 8), per = Math.floor(20000 / list.length), parts = [], names = []; let saved = 0, okN = 0;
    for (const x of list) {
      let m, p = x, spec = {};
      if ((m = /^(.+?):(\d*-\d*|\d+)$/.exec(x))) { p = m[1]; spec = { range: m[2] }; } else if ((m = /^(.+?)#([\w$.]+)$/.exec(x))) { p = m[1]; spec = { sym: m[2] }; }
      try { const r = locReadFile(root, p, spec, c, force); okN++; saved += r.saved || 0; names.push(p); parts.push('=== ' + r.title.replace(/^read /, '') + ' ===\n' + (r.out.length > per ? locCap(r.out, per) : r.out)); }
      catch (e) { parts.push('✕ ' + x + ' : ' + (e.message || e)); }
    }
    if (!okN) throw new Error(parts.join('\n'));
    if (t.length > 8) parts.push('(' + (t.length - 8) + ' fichiers en plus ignorés : 8 maximum par @read)');
    return { title: 'read ×' + okN + ' (' + names.join(', ').slice(0, 90) + ')', out: parts.join('\n'), saved };
  },
  outline(root, a) {
    const t = locArgs(a).filter(x => !x.startsWith('-')); if (!t[0]) throw new Error('chemin manquant');
    const parts = [], errs = []; let n = 0;
    for (const x of t.slice(0, 6)) { try { const r = locOutline(root, x); parts.push(r.text); n++; } catch (e) { errs.push('✕ ' + x + ' : ' + (e.message || e)); } }
    if (!n) throw new Error(errs.join('\n'));
    return { title: 'outline ' + t.slice(0, 3).join(' ') + (t.length > 3 ? '…' : ''), out: parts.concat(errs).join('\n') };
  },
  find(root, a) {
    const t = locArgs(a); if (!t[0]) throw new Error('motif manquant (ex. *.js)');
    const re = locGlob(t[0]), byPath = t[0].includes('/'), out = []; let seen = 0;
    for (const x of locWalk(root, root, 12)) { if (++seen > 8000) break; if (x.e.isDirectory()) continue;
      if (re.test(byPath ? x.rel : x.e.name)) { out.push(x.rel); if (out.length >= 80) { out.push('… (80 premiers résultats, précise le motif)'); break; } } }
    return { title: 'find ' + t[0] + ' (' + out.length + ' résultats)', out: out.join('\n') || 'aucun fichier' };
  },
  grep(root, a) {
    const tk = locArgs(a), t = []; let rx = false, cs = false, lo = false, ctx = 0, glob = '';
    for (let i = 0; i < tk.length; i++) {
      const x = tk[i];
      if (x === '-r') rx = true; else if (x === '-s') cs = true; else if (x === '-l') lo = true;
      else if (/^-C[0-3]$/.test(x)) ctx = +x.slice(2); else if (x === '-C' && /^[0-3]$/.test(tk[i + 1] || '')) ctx = +tk[++i];
      else if ((x === '-g' || x === '--include') && tk[i + 1]) glob = tk[++i];
      else t.push(x);
    }
    if (!t[0]) throw new Error('texte manquant');
    const s = locSafe(root, t[1] || '.');
    let test;
    if (rx) { let re; try { re = new RegExp(t[0].slice(0, 300), cs ? '' : 'i'); } catch (e) { throw new Error('expression régulière invalide : ' + e.message); } test = l => { const m = re.exec(l); return m ? m.index : -1; }; }
    else { const nd = cs ? t[0] : t[0].toLowerCase(); test = l => (cs ? l : l.toLowerCase()).indexOf(nd); }
    const gre = glob ? locGlob(glob) : null, groups = []; let files = 0, total = 0;
    const scan = (f, rel) => {
      if (gre && !gre.test(path.basename(rel))) return;
      try {
        const st = fs.statSync(f); if (st.size > 1024 * 1024 || locIsBinary(f)) return; files++;
        const Ls = fs.readFileSync(f, 'utf8').split(/\r?\n/), hits = [];
        for (let i = 0; i < Ls.length; i++) { const k = test(Ls[i]); if (k >= 0) hits.push([i, k]); }
        if (hits.length) { total += hits.length; groups.push({ rel, L: Ls, hits }); }
      } catch {}
    };
    const st0 = fs.statSync(s.full);
    if (st0.isDirectory()) { for (const x of locWalk(s.full, realBase(root), 12)) { if (!x.e.isDirectory() && files < 3000) scan(x.full, x.rel); } }
    else scan(s.full, s.rel);
    const win = (line, k) => { const l = String(line); if (l.length <= 170) return l.trim(); const a0 = Math.max(0, k - 60); return (a0 ? '…' : '') + l.slice(a0, a0 + 170).trim() + '…'; };
    let budget = 80, trunc = false; const out = [];
    for (const g of groups) {
      if (lo) { if (out.length >= 100) { trunc = true; break; } out.push(g.rel + ' (' + g.hits.length + ')'); continue; }
      if (budget <= 0) { trunc = true; break; }
      out.push('# ' + g.rel + (g.hits.length > 1 ? ' (' + g.hits.length + ')' : ''));
      const shown = new Set(); let last = -2;
      for (const [i, k] of g.hits) {
        if (budget <= 0) { trunc = true; break; }
        for (let j = Math.max(0, i - ctx); j <= Math.min(g.L.length - 1, i + ctx); j++) {
          if (shown.has(j)) continue; shown.add(j);
          if (ctx && last !== -2 && j !== last + 1) out.push('  --');
          out.push('  ' + (j + 1) + (j === i ? ': ' : '- ') + win(g.L[j], j === i ? k : 0)); last = j;
        }
        budget--;
      }
    }
    if (trunc) out.push('… (résultats coupés, ' + total + ' au total : précise le texte, le dossier, -g *.js ou -l)');
    return { title: 'grep ' + cutTxt(t[0], 40) + ' (' + total + ' résultat' + (total > 1 ? 's' : '') + ', ' + groups.length + ' fichier' + (groups.length > 1 ? 's' : '') + ')', out: out.join('\n') || 'aucun résultat dans ' + files + ' fichiers' };
  },
  stat(root, a) {
    const t = locArgs(a); if (!t[0]) throw new Error('chemin manquant');
    const s = locSafe(root, t[0]);
    let st; try { st = fs.statSync(s.full); } catch { return { title: 'stat ' + s.rel, out: 'n\'existe pas' }; }
    return { title: 'stat ' + s.rel, out: (st.isDirectory() ? 'dossier' : locIsBinary(s.full) ? 'fichier binaire' : 'fichier texte') + ' · ' + st.size + ' octets · modifié ' + st.mtime.toISOString().slice(0, 16).replace('T', ' ') };
  },

  // ----- écriture sûre : chaque modification sauvegarde l'ancienne version dans .aihub/undo -----
  write(root, a, c) {
    const t = locArgs(a); if (!t[0]) throw new Error('chemin manquant');
    if (c.body == null) throw new Error('contenu manquant : mets le texte entre <<< et >>> sur les lignes suivantes');
    if (Buffer.byteLength(c.body) > LOC_MAXFILE) throw new Error('contenu trop gros (> ' + (LOC_MAXFILE / 1024) + ' Ko) : écris le fichier en plusieurs fois (@write puis @append)');
    const s = locSafe(root, t[0]); let ex = false, old = null;
    try { const st = fs.statSync(s.full); if (st.isDirectory()) throw new Error(s.rel + ' est un dossier'); ex = true; if (st.size <= 1024 * 1024 && !locIsBinary(s.full)) old = fs.readFileSync(s.full, 'utf8'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    if (ex && seenStale(root, s.rel, s.full)) throw new Error(staleMsg(s.rel));
    const df = ex && old === null ? { diff: '', add: 0, del: 0 } : lineDiff(old || '', c.body);
    const title = 'write ' + s.rel + ' (' + nLines(c.body) + ' lignes, ' + (ex ? 'remplacé' : 'nouveau') + ')';
    if (c.opts && c.opts.dry) return { title, out: '', diff: df, dry: true, rels: [s.rel] };
    undoPush(root, c, 'write', s.rel, '', ex ? s.full : null);
    fs.mkdirSync(path.dirname(s.full), { recursive: true }); atomicWrite(s.full, c.body, 'utf8'); seenMark(root, s.rel, s.full);
    return { title, out: '', changed: true, rels: [s.rel], diff: df };
  },
  edit(root, a, c) {
    const t = locArgs(a); if (!t[0]) throw new Error('chemin manquant');
    if (c.body == null) throw new Error('bloc manquant : entre <<< et >>> mets CHERCHE, le texte à trouver, REMPLACE, le nouveau texte');
    const s = locSafe(root, t[0]);
    let st; try { st = fs.statSync(s.full); } catch { throw new Error(s.rel + ' n\'existe pas : utilise @write pour le créer'); }
    if (st.isDirectory()) throw new Error(s.rel + ' est un dossier'); if (locIsBinary(s.full)) throw new Error('fichier binaire : modification refusée');
    if (st.size > LOC_MAXFILE * 5) throw new Error('fichier trop gros pour @edit (' + Math.round(st.size / 1024) + ' Ko) : utilise @script');
    if (seenStale(root, s.rel, s.full)) throw new Error(staleMsg(s.rel));
    let txt = fs.readFileSync(s.full, 'utf8'); const crlf = txt.includes('\r\n'); if (crlf) txt = txt.replace(/\r\n/g, '\n');
    const old = txt; let what;
    if (/^(lignes|ligne|lines|line)$/i.test(t[1] || '')) {      // @edit chemin lignes 12-18 : remplace ces lignes par le texte du bloc
      const lm = /^(\d+)(?:-(\d+))?$/.exec(t[2] || ''); if (!lm) throw new Error('usage : @edit ' + s.rel + ' lignes 12-18 puis le nouveau texte entre <<< et >>>');
      if (!LOC_SEEN.has(seenKey(root, s.rel))) throw new Error('lis d\'abord ces lignes avec @read ' + s.rel + ' ' + lm[1] + '-' + (lm[2] || lm[1]) + ' (les numéros de lignes doivent venir d\'une lecture récente)');
      const hadNl = txt.endsWith('\n'), F = txt.split('\n'); if (hadNl) F.pop();
      const from = +lm[1], to = +(lm[2] || lm[1]);
      if (from < 1 || to < from || to > F.length) throw new Error('lignes ' + from + '-' + to + ' hors du fichier (' + F.length + ' lignes) : aucun fichier modifié');
      const R = c.body === '' ? [] : String(c.body).replace(/\r/g, '').split('\n');
      F.splice(from - 1, to - from + 1, ...R); txt = F.join('\n') + (hadNl ? '\n' : ''); what = 'lignes ' + from + '-' + to;
    } else {
      const pairs = parseEdit(c.body);
      pairs.forEach((p, i) => { if (!p.s.trim()) throw new Error('CHERCHE n°' + (i + 1) + ' est vide'); txt = editPair(txt, p, i, s.rel); });
      what = pairs.length + ' modification' + (pairs.length > 1 ? 's' : '');
    }
    const df = lineDiff(old, txt), title = 'edit ' + s.rel + ' (' + what + ')';
    if (c.opts && c.opts.dry) return { title, out: '', diff: df, dry: true, rels: [s.rel] };
    undoPush(root, c, 'edit', s.rel, '', s.full);
    atomicWrite(s.full, crlf ? txt.replace(/\n/g, '\r\n') : txt, 'utf8'); seenMark(root, s.rel, s.full);
    return { title, out: '', changed: true, rels: [s.rel], diff: df };
  },
  append(root, a, c) {
    const t = locArgs(a); if (!t[0]) throw new Error('chemin manquant');
    if (c.body == null) throw new Error('contenu manquant : mets le texte entre <<< et >>>');
    const s = locSafe(root, t[0]); let ex = false, cur = '';
    try { const st = fs.statSync(s.full); if (st.isDirectory()) throw new Error(s.rel + ' est un dossier'); if (st.size + Buffer.byteLength(c.body) > LOC_MAXFILE * 5) throw new Error('fichier trop gros'); ex = true; cur = fs.readFileSync(s.full, 'utf8'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    const piece = (cur && !/\n$/.test(cur) && !/^\r?\n/.test(c.body) ? '\n' : '') + c.body, df = lineDiff(cur, cur + piece), title = 'append ' + s.rel + ' (+' + nLines(c.body) + ' lignes)';
    if (c.opts && c.opts.dry) return { title, out: '', diff: df, dry: true, rels: [s.rel] };
    undoPush(root, c, 'append', s.rel, '', ex ? s.full : null);
    fs.mkdirSync(path.dirname(s.full), { recursive: true });
    fs.appendFileSync(s.full, piece, 'utf8'); seenMark(root, s.rel, s.full);
    return { title, out: '', changed: true, rels: [s.rel], diff: df };
  },
  async replace(root, a, c) {
    const t = [], tk = locArgs(a); let word = false, preview = false;
    for (const x of tk) { if (x === '-w') word = true; else if (x === '-n') preview = true; else t.push(x); }
    if (c.body == null) throw new Error('bloc manquant : entre <<< et >>> mets CHERCHE, le texte à trouver, REMPLACE, le nouveau texte (plusieurs paires possibles)');
    const trimNl = x => String(x).replace(/\r/g, '').replace(/^\n+|\n+$/g, '');
    const pairs = parseEdit(c.body).map(p => ({ s: trimNl(p.s), r: trimNl(p.r) }));
    pairs.forEach((p, i) => { if (!p.s.trim()) throw new Error('CHERCHE n°' + (i + 1) + ' est vide'); });
    const s = locSafe(root, t[0] || '.'), glob = t[1] ? locGlob(t[1]) : null, forbid = c.opts && c.opts.forbid, dry = !!(c.opts && c.opts.dry);
    const files = [], st0 = fs.statSync(s.full);
    if (st0.isDirectory()) { let n = 0; for (const x of locWalk(s.full, realBase(root), 12)) { if (x.e.isDirectory()) continue; if (++n > 4000) break; if (IDX_SKIP.test(x.rel)) continue; if (glob && !glob.test(x.e.name)) continue; files.push(x); } }
    else files.push({ full: s.full, rel: s.rel, e: { name: path.basename(s.rel) } });
    const esc = z => z.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), res = [], rels = [], diffs = []; let total = 0, add = 0, del = 0, skipped = 0;
    for (const x of files) {
      if (rels.length >= 60) { res.push('… limite de 60 fichiers par @replace : relance pour la suite'); break; }
      if (locForbid(forbid, x.rel)) { skipped++; continue; }
      let st; try { st = fs.statSync(x.full); } catch { continue; } if (st.size > 1024 * 1024 || locIsBinary(x.full)) continue;
      let txt = fs.readFileSync(x.full, 'utf8'); const crlf = txt.includes('\r\n'); if (crlf) txt = txt.replace(/\r\n/g, '\n');
      const old = txt; let n = 0;
      for (const p of pairs) {
        if (word) { const re = new RegExp('(?<![\\w$])' + esc(p.s) + '(?![\\w$])', 'g'); txt = txt.replace(re, () => { n++; return p.r; }); }
        else { const k = countOcc(txt, p.s); if (k) { n += k; txt = txt.split(p.s).join(p.r); } }
      }
      if (!n || txt === old) continue;
      total += n; const df = lineDiff(old, txt); add += df.add; del += df.del; res.push(x.rel + ' (×' + n + ')'); rels.push(x.rel);
      if (diffs.length < 3 && df.diff) diffs.push('--- ' + x.rel + '\n' + df.diff);
      if (!preview && !dry) { undoPush(root, c, 'edit', x.rel, '', x.full); atomicWrite(x.full, crlf ? txt.replace(/\n/g, '\r\n') : txt, 'utf8'); seenMark(root, x.rel, x.full); }
    }
    const lab = '“' + cutTxt(pairs[0].s, 28) + '” → “' + cutTxt(pairs[0].r, 28) + '”' + (pairs.length > 1 ? ' (+' + (pairs.length - 1) + ')' : '');
    if (!rels.length) throw new Error('replace ' + lab + ' : aucune occurrence' + (word ? ' (mot entier)' : '') + ' dans ' + files.length + ' fichiers examinés' + (skipped ? ' (' + skipped + ' protégés ignorés)' : '') + ' : rien n\'a été modifié');
    const list = res.length > 40 ? res.slice(0, 40).concat('… (+' + (res.length - 40) + ' autres fichiers)') : res, df2 = { diff: diffs.join('\n'), add, del };
    if (dry) return { title: 'replace ' + lab, out: '', diff: df2, dry: true, rels };
    if (preview) return { title: 'replace -n ' + lab + ' (aperçu : ' + total + ' remplacements, ' + rels.length + ' fichiers)', out: 'APERÇU, rien n\'a été écrit :\n' + list.join('\n') + (skipped ? '\n(' + skipped + ' fichiers protégés ignorés)' : '') };
    const bad = [];
    if (!(c.opts && c.opts.verify === false)) for (const rel of rels.slice(0, 15)) { const v = await locVerify(root, rel, locSafe(root, rel).full); if (v && !v.ok) bad.push('VÉRIF ✕ ' + rel + ' : ' + v.what + ' — ' + v.msg); }
    return { ok: !bad.length, title: 'replace ' + lab + ' (' + total + ' remplacement' + (total > 1 ? 's' : '') + ', ' + rels.length + ' fichier' + (rels.length > 1 ? 's' : '') + (bad.length ? ' · vérif ✕' : '') + ')',
      out: list.join('\n') + (skipped ? '\n(' + skipped + ' fichiers protégés ignorés)' : '') + (bad.length ? '\n' + bad.join('\n') + '\nCes fichiers contiennent une erreur après le remplacement : corrige-les tout de suite (@read puis @edit) ou annule avec @undo.' : ''),
      changed: true, rels, diff: df2 };
  },
  mkdir(root, a, c) {
    const t = locArgs(a); if (!t[0]) throw new Error('chemin manquant');
    const s = locSafe(root, t[0]);
    if (fs.existsSync(s.full)) { if (fs.statSync(s.full).isDirectory()) return { title: 'mkdir ' + s.rel + ' (existe déjà)', out: '' }; throw new Error(s.rel + ' est un fichier'); }
    undoPush(root, c, 'mkdir', s.rel, '', null); fs.mkdirSync(s.full, { recursive: true });
    return { title: 'mkdir ' + s.rel, out: '', changed: true, rels: [s.rel + '/'] };
  },
  move(root, a, c) {
    const t = locArgs(a); if (t.length < 2) throw new Error('usage : @move source cible');
    const s = locSafe(root, t[0]), d = locSafe(root, t[1]);
    if (s.rel === '.') throw new Error('impossible de déplacer le dossier du projet');
    if (!fs.existsSync(s.full)) throw new Error(s.rel + ' n\'existe pas');
    if (fs.existsSync(d.full)) throw new Error(d.rel + ' existe déjà : choisis un autre nom ou @delete d\'abord');
    if (d.full.startsWith(s.full + path.sep)) throw new Error('on ne peut pas déplacer un dossier dans lui-même');
    undoPush(root, c, 'move', s.rel, d.rel, null); fs.mkdirSync(path.dirname(d.full), { recursive: true });
    try { fs.renameSync(s.full, d.full); } catch { fs.cpSync(s.full, d.full, { recursive: true }); fs.rmSync(s.full, { recursive: true, force: true }); }
    return { title: 'move ' + s.rel + ' → ' + d.rel, out: '', changed: true, rels: [s.rel, d.rel] };
  },
  copy(root, a, c) {
    const t = locArgs(a); if (t.length < 2) throw new Error('usage : @copy source cible');
    const s = locSafe(root, t[0]), d = locSafe(root, t[1]);
    if (!fs.existsSync(s.full)) throw new Error(s.rel + ' n\'existe pas');
    const sd = fs.statSync(s.full).isDirectory();
    if (sd && (d.full === s.full || d.full.startsWith(s.full + path.sep))) throw new Error('on ne peut pas copier un dossier dans lui-même');
    let ex = false; if (fs.existsSync(d.full)) { if (sd || fs.statSync(d.full).isDirectory()) throw new Error(d.rel + ' existe déjà'); ex = true; }
    dirSize(s.full, LOC_MAXBACKUP);
    undoPush(root, c, 'copy', s.rel, d.rel, ex ? d.full : null); fs.mkdirSync(path.dirname(d.full), { recursive: true });
    fs.cpSync(s.full, d.full, { recursive: true, filter: (p) => !LOC_IGN.has(path.basename(p)) || p === s.full });
    return { title: 'copy ' + s.rel + ' → ' + d.rel + (ex ? ' (remplacé)' : ''), out: '', changed: true, rels: [d.rel] };
  },
  delete(root, a, c) {
    const t = locArgs(a); if (!t[0]) throw new Error('chemin manquant');
    const s = locSafe(root, t[0]);
    if (s.rel === '.') throw new Error('impossible de supprimer le dossier du projet');
    if (s.rel.split('/')[0].toLowerCase() === '.git') throw new Error('le dossier .git ne se supprime pas par @delete');
    if (!fs.existsSync(s.full)) throw new Error(s.rel + ' n\'existe pas');
    const dir = fs.statSync(s.full).isDirectory();
    undoPush(root, c, 'delete', s.rel, '', s.full);      // refuse si trop gros pour être sauvegardé
    fs.rmSync(s.full, { recursive: true, force: true });
    return { title: 'delete ' + s.rel + (dir ? '/ (dossier)' : ''), out: 'sauvegardé : récupérable avec @undo', changed: true, rels: [s.rel] };
  },
  undo(root, a) {
    const n = Math.max(1, Math.min(20, parseInt(locArgs(a)[0], 10) || 1)), idx = undoIndex(root);
    if (!idx.length) throw new Error('rien à annuler');
    const r = undoMany(root, idx.slice(-n).reverse()); seenClear(root);
    return { ok: r.ok > 0, title: 'undo ' + n + ' (' + r.ok + ' annulée' + (r.ok > 1 ? 's' : '') + ')', out: r.out.join('\n'), changed: true };
  },

  // ----- les passe-partout -----
  task(root, a, c) { // 4.3.0 : tableau de tâches partagé (.aihub/tasks.json), lu par toutes les clés : gros projets découpés et repris par n'importe quel compte
    const f = path.join(aihDir(root), 'tasks.json'); let T = [];
    try { T = JSON.parse(fs.readFileSync(f, 'utf8')); if (!Array.isArray(T)) T = []; } catch {}
    const m = String(a || '').trim().match(/^(\S+)\s*([\s\S]*)$/), op = m ? m[1].toLowerCase() : 'list', arg = m ? m[2].trim() : '';
    const save = () => { fs.mkdirSync(path.dirname(f), { recursive: true }); atomicWrite(f, JSON.stringify(T), 'utf8'); };
    const mark = { todo: '[ ]', doing: '[~]', done: '[x]', blocked: '[!]' };
    const show = (all) => { const nd = T.filter(x => x.s === 'done').length, o = ['TÂCHES ' + nd + '/' + T.length + ' faites'], todo = T.filter(x => x.s !== 'done');
      const lst = (all ? T : todo.slice(0, 14).concat(T.filter(x => x.s === 'done').slice(-3))).slice().sort((x, y) => x.id - y.id);
      lst.forEach(x => o.push(x.id + ' ' + mark[x.s] + ' ' + x.t + (x.d && x.d.length ? ' [après ' + x.d.join(',') + ']' : '') + (x.n ? ' → ' + x.n : '')));
      if (!all && todo.length > 14) o.push('… +' + (todo.length - 14) + ' autres à faire (@task list -a)'); return o.join('\n'); };
    if (op === 'list') return { title: 'task list (' + T.length + ')', out: T.length ? show(/-a\b/.test(arg)) : '(aucune tâche : découpe le projet avec @task add)' };
    if (op === 'add') {
      const items = (c.body != null ? String(c.body).split(/\r?\n/) : [arg]).map(s => s.trim().replace(/^([-*•]|\d+[.)])\s+/, '').slice(0, 160)).filter(Boolean);
      if (!items.length) throw new Error('tâche manquante : @task add titre (ou plusieurs lignes entre <<< et >>>)');
      if (T.length + items.length > 400) throw new Error('400 tâches maximum');
      let id = T.reduce((n, x) => Math.max(n, x.id), 0); items.forEach(t0 => { let d = [], p = 2; const t = t0.replace(/\s*\[(?:après|apres|after|dep)\s*:?\s*([\d,\s]+)\]/ig, (_m, g) => { d = d.concat(g.split(',').map(s => parseInt(s, 10)).filter(Boolean)); return ''; }).replace(/\s*\[p([123])\]/ig, (_m, g) => { p = +g; return ''; }).trim(); T.push({ id: ++id, t, s: 'todo', n: '', d, p }); }); save();
      return { title: 'task add (' + items.length + ' tâche' + (items.length > 1 ? 's' : '') + ')', out: show(false) };
    }
    if (op === 'next') { // 4.11.0 : prochaine tâche prête (dépendances faites, priorité p1 < p2 < p3)
      const dn = new Set(T.filter(x => x.s === 'done').map(x => x.id)), doing = T.filter(x => x.s === 'doing'), o = [];
      const ready = T.filter(x => x.s === 'todo' && (x.d || []).every(i => dn.has(i))).sort((x, y) => (x.p || 2) - (y.p || 2) || x.id - y.id);
      if (doing.length) o.push('EN COURS : ' + doing.map(x => x.id + ' ' + x.t).join(' | '));
      o.push(ready.length ? 'PROCHAINES (dépendances faites) :\n' + ready.slice(0, 5).map(x => x.id + ' ' + x.t).join('\n') : (T.some(x => x.s === 'todo') ? 'aucune tâche prête : des dépendances ne sont pas faites ou sont bloquées' : 'plus rien à faire'));
      return { title: 'task next', out: o.join('\n') };
    }
    if (op === 'clear') { T = []; save(); return { title: 'task clear', out: 'liste vidée' }; }
    if (op === 'start' || op === 'done' || op === 'block' || op === 'todo') {
      const mm = arg.match(/^(\d+(?:\s*,\s*\d+)*)\s*([\s\S]*)$/); if (!mm) throw new Error('numéro manquant : @task ' + op + ' N [note]');
      const ids = mm[1].split(',').map(x => parseInt(x, 10)), note = mm[2].trim().slice(0, 200), s = { start: 'doing', done: 'done', block: 'blocked', todo: 'todo' }[op];
      const miss = ids.filter(i => !T.some(x => x.id === i)); if (miss.length) throw new Error('tâche inconnue : ' + miss.join(', '));
      T.forEach(x => { if (ids.includes(x.id)) { x.s = s; if (note) x.n = note; } }); save();
      const left = T.filter(x => x.s !== 'done').length;
      return { title: 'task ' + op + ' ' + ids.join(','), out: left ? show(false) : 'TOUTES LES TÂCHES SONT FAITES (' + T.length + '/' + T.length + ') : vérifie le projet puis @done' };
    }
    throw new Error('@task add (ligne [après:3,4] [p1]) | next | start N | done N [note] | block N raison | list [-a] | clear');
  },
  async run(root, a, c) {
    const cmd = String(a || '').trim(); if (!cmd) throw new Error('commande manquante');
    const full = process.platform === 'win32' ? 'chcp 65001>nul & ' + cmd : cmd;
    const r = await locProc(full, [], { cwd: fs.realpathSync(root), shell: true, timeout: ((c.opts && c.opts.timeout) || 60) * 1000 });
    return cmdOut(r, c, 'run ' + cmd.slice(0, 70), root);
  },
  async build(root, a, c) { // 4.8.0 : détecte le système de build du projet et le lance (300 s) ; « auto » = après @task done, sans erreur si rien à construire
    const base = fs.realpathSync(root), has = (f) => fs.existsSync(path.join(base, f)), win = process.platform === 'win32', want = String(a || '').trim();
    let cmd = want && want !== 'auto' ? want : '';
    if (!cmd) {
      let pj = null; try { pj = JSON.parse(fs.readFileSync(path.join(base, 'package.json'), 'utf8')); } catch {}
      if (win && has('gradlew.bat')) cmd = 'gradlew.bat build';
      else if (has('gradlew')) cmd = './gradlew build';
      else if (has('build.gradle') || has('build.gradle.kts')) cmd = 'gradle build';
      else if (has('pom.xml')) cmd = 'mvn -q package';
      else if (has('Cargo.toml')) cmd = 'cargo build';
      else if (pj && pj.scripts && pj.scripts.build) cmd = 'npm run build';
      else if (projHasTest(root)) cmd = 'npm test';
      else if (has('pyproject.toml') || has('setup.py') || has('requirements.txt')) cmd = (win ? 'python' : 'python3') + ' -m compileall -q .';
    }
    if (!cmd) { if (want === 'auto') return { title: 'build (rien à construire)', out: 'aucun système de build détecté : ignoré' }; throw new Error('aucun système de build détecté (gradle, maven, npm, python, cargo) : @build commande pour en donner un'); }
    const full = win ? 'chcp 65001>nul & ' + cmd : cmd;
    const r = await locProc(full, [], { cwd: base, shell: true, timeout: 300000 });
    return cmdOut(r, c, 'build ' + cmd.slice(0, 60), root);
  },
  async script(root, a, c) {
    const lang = locArgs(a)[0]; if (!lang) throw new Error('langage manquant : @script node, python ou powershell');
    if (c.body == null || !String(c.body).trim()) throw new Error('programme manquant : mets le code entre <<< et >>>');
    const L = String(lang).toLowerCase().replace(/^(js|javascript)$/, 'node').replace(/^(py|python3)$/, 'python').replace(/^(ps|ps1|pwsh)$/, 'powershell'), it = interp(L);
    const ext = { node: '.js', python: '.py', powershell: '.ps1' }[L], tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'aihub-')), f = path.join(tmp, 'script' + ext);
    fs.writeFileSync(f, (L === 'powershell' && process.platform === 'win32' ? '\ufeff' : '') + c.body, 'utf8');
    try {
      const args = it.pre.concat(it.ps ? ['-File', f] : [f]), base = fs.realpathSync(root);
      const r = await locProc(it.file, args, { cwd: base, timeout: ((c.opts && c.opts.timeout) || 60) * 1000, env: Object.assign({ NODE_PATH: path.join(base, 'node_modules') }, it.env) });
      return cmdOut(r, c, 'script ' + L + ' (' + nLines(c.body) + ' lignes)', root);
    } finally { try { fs.rmSync(tmp, { recursive: true, force: true }); } catch {} }
  },
  open(root, a) {
    const t = String(a || '').trim(); if (!t) throw new Error('chemin ou adresse manquant');
    if (/^https?:\/\//i.test(t)) { let u; try { u = new URL(t); } catch { throw new Error('adresse invalide'); } shell.openExternal(u.href); return { title: 'open ' + u.href.slice(0, 80), out: 'ouvert dans le navigateur' }; }
    const s = locSafe(root, t.replace(/^"|"$/g, '')); if (!fs.existsSync(s.full)) throw new Error(s.rel + ' n\'existe pas');
    if (/\.(exe|bat|cmd|com|msi|ps1|psm1|vbs|vbe|js|jse|wsf|wsh|scr|lnk|hta|jar|sh|command|app|appimage|reg|dll|cpl)$/i.test(s.full)) throw new Error('ouvrir un programme est refusé : utilise @run (avec confirmation)');
    shell.openPath(s.full); return { title: 'open ' + s.rel, out: 'ouvert avec le programme par défaut' };
  },
  async web(root, a) {
    const url = locArgs(a)[0]; if (!url) throw new Error('adresse manquante');
    const r = await locFetch(/^https?:/i.test(url) ? url : 'https://' + url, 20000);
    const txt = /html|xml/i.test(r.ct) || /^\s*</.test(r.raw) ? htmlToText(r.raw) : r.raw.trim();
    if (r.status >= 400) throw new Error('la page répond ' + r.status);
    return { title: 'web ' + r.url.slice(0, 80) + ' (' + txt.length + ' caractères)', out: locCap(txt, 14000) || '(page vide)' };
  },
  async search(root, a) {
    const q = String(a || '').trim(); if (!q) throw new Error('texte de recherche manquant');
    const r = await locFetch('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(q), 20000), res = parseSearch(r.raw);
    if (!res.length) throw new Error('aucun résultat lisible (le moteur a peut-être refusé la requête) : réessaie avec d\'autres mots ou @web sur une adresse précise');
    return { title: 'search ' + q.slice(0, 60) + ' (' + res.length + ' résultats)', out: res.map((x, i) => (i + 1) + '. ' + x.t + ' — ' + x.u + (x.s ? '\n   ' + x.s : '')).join('\n') };
  }
};
// 4.11.0 : modèles de @scaffold
const SCAF = {
  node: (n) => ({ 'package.json': JSON.stringify({ name: n.toLowerCase(), version: '1.0.0', main: 'src/index.js', scripts: { start: 'node src/index.js', test: 'node --test' } }, null, 2) + '\n', 'src/index.js': "function hello(name) { return 'Bonjour ' + name; }\nmodule.exports = { hello };\nif (require.main === module) console.log(hello('monde'));\n", 'test/index.test.js': "const test = require('node:test');\nconst assert = require('node:assert');\nconst { hello } = require('../src/index.js');\ntest('hello', () => assert.strictEqual(hello('A'), 'Bonjour A'));\n", '.gitignore': 'node_modules\n' }),
  python: () => ({ 'main.py': "def hello(name):\n    return 'Bonjour ' + name\n\n\nif __name__ == '__main__':\n    print(hello('monde'))\n", 'test_main.py': "import unittest\nfrom main import hello\n\n\nclass T(unittest.TestCase):\n    def test_hello(self):\n        self.assertEqual(hello('A'), 'Bonjour A')\n\n\nif __name__ == '__main__':\n    unittest.main()\n", 'requirements.txt': '', '.gitignore': '__pycache__\n.venv\n' }),
  html: (n) => ({ 'index.html': '<!doctype html>\n<html lang="fr">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>' + n + '</title>\n<link rel="stylesheet" href="style.css">\n</head>\n<body>\n<h1>' + n + '</h1>\n<script src="script.js"></script>\n</body>\n</html>\n', 'style.css': 'body { font-family: system-ui, sans-serif; margin: 2rem; }\n', 'script.js': "console.log('prêt');\n" }),
  'mc-fabric': (n) => { const id = n.toLowerCase().replace(/[^a-z0-9_]/g, '_'), pk = 'com.example.' + id, cl = id.replace(/(^|_)(\w)/g, (_m, _a, b) => b.toUpperCase()) + 'Mod';
    return {
      'settings.gradle': "pluginManagement {\n    repositories {\n        maven { url = 'https://maven.fabricmc.net/' }\n        mavenCentral()\n        gradlePluginPortal()\n    }\n}\n",
      'gradle.properties': ['org.gradle.jvmargs=-Xmx2G', 'minecraft_version=1.21.1', 'yarn_mappings=1.21.1+build.3', 'loader_version=0.16.5', 'fabric_version=0.102.0+1.21.1', 'mod_version=1.0.0', 'maven_group=' + pk, 'archives_base_name=' + id, ''].join('\n'),
      'build.gradle': ["plugins {", "    id 'fabric-loom' version '1.7-SNAPSHOT'", "    id 'maven-publish'", "}", "version = project.mod_version", "group = project.maven_group", "base { archivesName = project.archives_base_name }", "dependencies {", "    minecraft \"com.mojang:minecraft:${project.minecraft_version}\"", "    mappings \"net.fabricmc:yarn:${project.yarn_mappings}:v2\"", "    modImplementation \"net.fabricmc:fabric-loader:${project.loader_version}\"", "    modImplementation \"net.fabricmc.fabric-api:fabric-api:${project.fabric_version}\"", "}", "processResources {", "    inputs.property 'version', project.version", "    filesMatching('fabric.mod.json') { expand 'version': project.version }", "}", "tasks.withType(JavaCompile).configureEach { it.options.release = 21 }", "java { withSourcesJar() }", ""].join('\n'),
      'src/main/resources/fabric.mod.json': JSON.stringify({ schemaVersion: 1, id, version: '${version}', name: n, description: '', authors: [], environment: '*', entrypoints: { main: [pk + '.' + cl] }, depends: { fabricloader: '>=0.16.0', minecraft: '~1.21.1', java: '>=21', 'fabric-api': '*' } }, null, 2) + '\n',
      ['src/main/java/' + pk.replace(/\./g, '/') + '/' + cl + '.java']: 'package ' + pk + ';\n\nimport net.fabricmc.api.ModInitializer;\n\npublic class ' + cl + ' implements ModInitializer {\n    public static final String MOD_ID = "' + id + '";\n\n    @Override\n    public void onInitialize() {\n        System.out.println("' + n + ' chargé");\n    }\n}\n',
      '.gitignore': '.gradle\nbuild\nrun\n.idea\n' }; },
  'mc-forge': (n) => { const id = n.toLowerCase().replace(/[^a-z0-9_]/g, '_'), pk = 'com.example.' + id, cl = id.replace(/(^|_)(\w)/g, (_m, _a, b) => b.toUpperCase()) + 'Mod';
    return {
      'settings.gradle': "pluginManagement {\n    repositories {\n        gradlePluginPortal()\n        maven { url = 'https://maven.minecraftforge.net/' }\n    }\n}\n",
      'gradle.properties': 'org.gradle.jvmargs=-Xmx2G\n',
      'build.gradle': ["plugins {", "    id 'java'", "    id 'net.minecraftforge.gradle' version '[6.0,6.2)'", "}", "group = '" + pk + "'", "version = '1.0.0'", "base { archivesName = '" + id + "' }", "java.toolchain.languageVersion = JavaLanguageVersion.of(17)", "minecraft {", "    mappings channel: 'official', version: '1.20.1'", "}", "dependencies {", "    minecraft 'net.minecraftforge:forge:1.20.1-47.2.0'", "}", ""].join('\n'),
      'src/main/resources/META-INF/mods.toml': ['modLoader="javafml"', 'loaderVersion="[47,)"', 'license="MIT"', '[[mods]]', 'modId="' + id + '"', 'version="1.0.0"', 'displayName="' + n + '"', 'description=\'\'\'' + n + '\'\'\'', ''].join('\n'),
      ['src/main/java/' + pk.replace(/\./g, '/') + '/' + cl + '.java']: 'package ' + pk + ';\n\nimport net.minecraftforge.fml.common.Mod;\n\n@Mod(' + cl + '.MOD_ID)\npublic class ' + cl + ' {\n    public static final String MOD_ID = "' + id + '";\n\n    public ' + cl + '() {\n        System.out.println("' + n + ' chargé");\n    }\n}\n',
      '.gitignore': '.gradle\nbuild\nrun\n.idea\n' }; }
};
let LOC_TURNW = { turn: '', n: 0 };
const LOC_WRITES = new Set(['write', 'edit', 'append', 'replace', 'mkdir', 'move', 'copy', 'delete', 'undo', 'scaffold']);
ipcMain.handle('local:exec', async (_e, p) => {
  p = p || {}; const root = p.root, verb = String(p.verb || ''), arg = p.arg || '', t0 = Date.now(), opts = p.opts || {};
  try {
    if (!root || !fs.statSync(root).isDirectory()) return { ok: false, title: verb, out: 'le dossier du projet est introuvable' };
    const f = Object.prototype.hasOwnProperty.call(LOC_VERBS, verb) ? LOC_VERBS[verb] : null; if (!f) return { ok: false, title: verb, out: 'instruction inconnue' };
    // 4.12 (H1) : verrous de fichiers pour les agents en parallèle (actifs seulement si opts.agent est fourni : un seul agent = aucun verrou)
    { const lk = lockClaim(root, opts.agent, opts.task, verb, arg); if (lk) return { ok: false, title: verb + ' ' + String(arg).split('\n')[0].slice(0, 50), out: lk }; }
    // 4.11.0 (C5) : plafond d'écriture : un gros fichier se livre par morceaux (@write puis @append), jamais d'un seul bloc géant coupé par la page
    if ((verb === 'write' || verb === 'append') && p.hasBody) {
      const sz = Buffer.byteLength(String(p.body || ''), 'utf8'), tk = String(p.turn || 't0');
      if (sz > 60000) return { ok: false, title: verb + ' ' + String(arg).split('\n')[0].slice(0, 50), out: 'bloc trop gros (' + Math.round(sz / 1024) + ' Ko, maximum 60 Ko par instruction) : écris les ~300 premières lignes avec @write puis le reste avec @append, un morceau par instruction' };
      LOC_TURNW = LOC_TURNW.turn === tk ? LOC_TURNW : { turn: tk, n: 0 }; LOC_TURNW.n += sz;
      if (LOC_TURNW.n > 240000) return { ok: false, title: verb + ' ' + String(arg).split('\n')[0].slice(0, 50), out: 'plafond d\'écriture du tour atteint (240 Ko) : termine ce tour, la suite au tour suivant' };
    }
    LOC_IGN = new Set([...LOC_IGNORE, ...((opts.ignore || []).map(x => String(x).trim()).filter(Boolean))]);
    const r = await f(root, arg, { body: p.hasBody ? String(p.body == null ? '' : p.body) : null, turn: p.turn || 't0', opts });
    const cap = (d) => d && d.diff ? { d: locCap(d.diff, 6000), a: d.add, r: d.del } : (d ? { d: '', a: d.add || 0, r: d.del || 0 } : undefined);
    if (r.dry) return { ok: true, title: r.title, out: '', dry: true, diff: cap(r.diff), rels: r.rels || [] };
    // 3.7.0 : contrôle automatique après @write / @edit / @append (désactivable dans les réglages du dossier)
    if (r.ok !== false && opts.verify !== false && (verb === 'write' || verb === 'edit' || verb === 'append') && r.rels && r.rels[0]) {
      const rel = r.rels[0], v = await locVerify(root, rel, locSafe(root, rel).full);
      if (v) {
        r.check = v;
        if (v.ok) r.title += ' · vérif ✔';
        else { r.title += ' · vérif ✕'; r.ok = false; r.out = 'VÉRIF ✕ ' + rel + ' : ' + v.what + ' — ' + v.msg + '\nLe fichier a été écrit mais contient une erreur : corrige-le tout de suite (@read ' + rel + ' autour de la ligne, puis @edit), ne passe pas à autre chose.'; }
      }
    }
    const ok = r.ok !== false;
    if (verb !== 'tree' && verb !== 'read' && verb !== 'find' && verb !== 'grep' && verb !== 'stat' && verb !== 'outline') jlog(root, (ok ? 'ok  ' : 'err ') + r.title);
    return { ok, title: r.title, out: locCap(r.out || '', LOC_MAXOUT), saved: r.saved || 0, ms: Date.now() - t0, changed: !!r.changed && LOC_WRITES.has(verb), rels: r.rels || [], diff: cap(r.diff), check: r.check ? { ok: r.check.ok, what: r.check.what } : undefined };
  } catch (x) {
    const msg = String(x && x.message || x); try { if (root && fs.existsSync(root) && !/introuvable/.test(msg)) jlog(root, 'err ' + verb + ' ' + String(arg).slice(0, 60) + ' : ' + msg); } catch {}
    return { ok: false, title: verb + (arg ? ' ' + String(arg).split('\n')[0].slice(0, 60) : ''), out: msg };
  }
});

// ---- 4.12 (J1) : vérification automatique de fin de tour : syntaxe de tous les fichiers touchés, résumée en une ligne (0 crédit, sans repasser par l'IA) ----
ipcMain.handle('local:verifyTurn', async (_e, p) => {
  try {
    p = p || {}; const root = p.root, rels = [...new Set((p.rels || []).map(String))].slice(0, 25); let ok = 0; const bad = [];
    for (const rel of rels) { let s; try { s = locSafe(root, rel); if (!fs.existsSync(s.full) || fs.statSync(s.full).isDirectory()) continue; } catch { continue; } const v = await locVerify(root, rel, s.full); if (!v) continue; if (v.ok) ok++; else bad.push(rel + ' (' + v.what + ' : ' + String(v.msg).slice(0, 100) + ')'); }
    return { ok: !bad.length, checked: ok + bad.length, bad, line: bad.length ? 'Vérif du tour ✕ ' + bad.join(' ; ') : (ok ? 'Vérif du tour ✔ ' + ok + ' fichier' + (ok > 1 ? 's' : '') + ' valide' + (ok > 1 ? 's' : '') : '') };
  } catch (x) { return { ok: true, checked: 0, bad: [], line: '', error: String(x && x.message || x) }; }
});

// ---- 4.12 (G2) : mode API optionnel (Gemini, Claude, OpenAI) : appel en flux avec https natif, sans dépendance. La clé n'est jamais écrite dans le journal. ----
const apxHttps = require('https'), apxHttp = require('http');
const APX = { reqs: new Map() };
const APX_DEF = { Claude: 'claude-sonnet-5-5', ChatGPT: 'gpt-5', Gemini: 'gemini-flash-latest' };
function apxBuild(p) {
  const plat = String(p.plat || ''), key = String(p.key || ''), model = String(p.model || APX_DEF[plat] || '');
  const prompt = String(p.prompt || ''), imgs = Array.isArray(p.images) ? p.images.filter(x => x && x.b64 && /^image\//.test(x.type || '')) : [];
  const maxT = Math.max(16, Math.min(32000, Number(p.maxTokens) || 8192));
  if (plat === 'Gemini') {
    const parts = imgs.map(x => ({ inlineData: { mimeType: x.type, data: x.b64 } })).concat([{ text: prompt }]);
    return { host: 'generativelanguage.googleapis.com', path: '/v1beta/models/' + encodeURIComponent(model) + ':streamGenerateContent?alt=sse', headers: { 'x-goog-api-key': key }, body: { contents: [{ role: 'user', parts }], generationConfig: { maxOutputTokens: maxT } } };
  }
  if (plat === 'Claude') {
    const content = imgs.map(x => ({ type: 'image', source: { type: 'base64', media_type: x.type, data: x.b64 } })).concat([{ type: 'text', text: prompt }]);
    return { host: 'api.anthropic.com', path: '/v1/messages', headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01' }, body: { model, max_tokens: maxT, stream: true, messages: [{ role: 'user', content }] } };
  }
  if (plat === 'ChatGPT') {
    const content = imgs.length ? imgs.map(x => ({ type: 'image_url', image_url: { url: 'data:' + x.type + ';base64,' + x.b64 } })).concat([{ type: 'text', text: prompt }]) : prompt;
    return { host: 'api.openai.com', path: '/v1/chat/completions', headers: { authorization: 'Bearer ' + key }, body: { model, stream: true, messages: [{ role: 'user', content }] } };
  }
  return null;
}
function apxDelta(plat, j) {
  try {
    if (plat === 'Gemini') return ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).map(x => x.text || '').join('');
    if (plat === 'Claude') return j.type === 'content_block_delta' && j.delta && j.delta.type === 'text_delta' ? (j.delta.text || '') : '';
    if (plat === 'ChatGPT') return (j.choices && j.choices[0] && j.choices[0].delta && j.choices[0].delta.content) || '';
  } catch {}
  return '';
}
function apxSse(plat, st, chunk, onDelta) {
  st.buf += chunk; let i;
  while ((i = st.buf.indexOf('\n')) >= 0) {
    const line = st.buf.slice(0, i).replace(/\r$/, ''); st.buf = st.buf.slice(i + 1);
    if (!line.startsWith('data:')) continue; const d = line.slice(5).trim(); if (!d || d === '[DONE]') continue;
    let j; try { j = JSON.parse(d); } catch { continue; }
    if (j && j.error) { st.err = String(j.error.message || JSON.stringify(j.error)).slice(0, 300); continue; }
    const t = apxDelta(plat, j); if (t) onDelta(t);
  }
}
function apxAsk(p, onDelta) {
  return new Promise((resolve) => {
    const b = apxBuild(p); if (!b) return resolve({ ok: false, error: 'plateforme sans mode API : ' + p.plat });
    if (!p.key) return resolve({ ok: false, auth: true, error: 'clé API manquante' });
    const data = JSON.stringify(b.body); let host = b.host, port, mod = apxHttps;
    if (p.base) { const m = /^([^:]+):(\d+)$/.exec(String(p.base)); if (!m) return resolve({ ok: false, error: 'base invalide' }); host = m[1]; port = +m[2]; mod = apxHttp; }    // p.base : seulement pour les tests
    let text = '', status = 0, errBody = '', done = false, cancelled = false, idle = null; const st = { buf: '', err: '' };
    const fin = (r) => { if (done) return; done = true; clearTimeout(idle); if (p.id) APX.reqs.delete(p.id); resolve(r); };
    const req = mod.request({ host, port, path: b.path, method: 'POST', headers: Object.assign({ 'content-type': 'application/json', 'content-length': Buffer.byteLength(data), accept: 'text/event-stream' }, b.headers) }, (res) => {
      status = res.statusCode || 0; res.setEncoding('utf8');
      res.on('data', (c) => { bump(); if (status >= 400) { errBody += c; return; } apxSse(p.plat, st, c, (t) => { text += t; try { onDelta && onDelta(t); } catch {} }); });
      res.on('end', () => {
        if (status >= 400) {
          let msg = errBody.slice(0, 400); try { const j = JSON.parse(errBody); const m = j.error && (j.error.message || j.error); if (m) msg = typeof m === 'string' ? m : JSON.stringify(m).slice(0, 300); } catch {}
          return fin({ ok: false, status, limited: status === 429 || status === 529 || (status !== 401 && status !== 403 && /quota|rate.?limit|exceeded|overloaded/i.test(msg)), auth: status === 401 || status === 403, error: 'HTTP ' + status + ' : ' + msg });
        }
        if (st.err && !text) return fin({ ok: false, status, limited: /quota|rate.?limit|overload|exceed/i.test(st.err), error: st.err });
        fin({ ok: true, status, text });
      });
      res.on('error', (e) => fin({ ok: false, cancel: cancelled, partial: text, error: cancelled ? 'annulé' : String(e && e.message || e) }));
      res.on('close', () => fin({ ok: false, cancel: cancelled, partial: text, error: cancelled ? 'annulé' : 'connexion interrompue' }));      // coupure après le début de la réponse (sans effet si la réponse s'est bien terminée)
    });
    const bump = () => { clearTimeout(idle); idle = setTimeout(() => { try { req.destroy(); } catch {} fin({ ok: false, partial: text, error: 'aucune réponse depuis 120 s' }); }, 120000); };
    if (p.id) APX.reqs.set(p.id, { cancel: () => { cancelled = true; try { req.destroy(); } catch {} } });
    req.on('error', (e) => fin({ ok: false, cancel: cancelled, partial: text, error: cancelled ? 'annulé' : String(e && e.message || e) }));
    req.write(data); req.end(); bump();
  });
}
ipcMain.handle('local:apiAsk', async (e, p) => {
  p = p || {}; const id = String(p.id || ''), sender = e && e.sender;
  try { return await apxAsk(p, (t) => { try { sender.send('api-delta', { id, d: t }); } catch {} }); } catch (x) { return { ok: false, error: String(x && x.message || x) }; }
});
ipcMain.handle('local:apiCancel', (_e, p) => { const r = APX.reqs.get(String(p && p.id || '')); if (r) { r.cancel(); return { ok: true }; } return { ok: false }; });

// ---- 4.12 (H1) : verrous de fichiers (.aihub/locks.json), expirent seuls après 15 min ----
const LOCK_TTL = 15 * 60 * 1000;
const locksFile = (root) => path.join(aihDir(root), 'locks.json');
const lockRel = (s) => String(s || '').trim().replace(/^["']|["']$/g, '').replace(/\\/g, '/').replace(/^\.\//, '').toLowerCase();
function locksLoad(root) {
  try { const j = JSON.parse(fs.readFileSync(locksFile(root), 'utf8')), now = Date.now(), f = {}; for (const [k, v] of Object.entries(j.files || {})) if (v && now - v.ts < LOCK_TTL) f[k] = v; return { files: f }; } catch { return { files: {} }; }
}
function locksSave(root, L) { try { fs.mkdirSync(aihDir(root), { recursive: true }); atomicWrite(locksFile(root), JSON.stringify(L), 'utf8'); } catch {} }
function lockTargets(verb, arg) {
  const first = String(arg || '').split('\n')[0].trim(); if (!first) return [];
  if (verb === 'move') return first.split(/\s+/).slice(0, 2).map(lockRel).filter(Boolean);
  if (verb === 'copy') return first.split(/\s+/).slice(1, 2).map(lockRel).filter(Boolean);
  return [lockRel(first.replace(/\s+lignes\s+\d+\s*-\s*\d+\s*$/i, ''))].filter(Boolean);
}
// vérifie ET réserve en une seule étape synchrone (deux agents ne peuvent pas passer en même temps)
function lockClaim(root, agent, task, verb, arg) {
  if (!agent || !LOC_WRITES.has(verb) || verb === 'undo' || verb === 'scaffold' || verb === 'replace') return '';
  const L = locksLoad(root), T = lockTargets(verb, arg), now = Date.now();
  for (const t of T) { const h = L.files[t]; if (h && h.agent !== agent) return 'fichier « ' + t + ' » en cours de modification par un autre agent (' + (h.task || h.agent) + ') : choisis un autre fichier ou attends la fin de sa tâche'; }
  if (!T.length) return '';
  for (const t of T) L.files[t] = { agent: String(agent), task: String(task || ''), ts: now };
  locksSave(root, L); return '';
}
ipcMain.handle('local:locks', (_e, p) => { try { return { ok: true, files: locksLoad(p.root).files }; } catch (x) { return { ok: false, files: {}, error: String(x && x.message || x) }; } });
ipcMain.handle('local:unlock', (_e, p) => {
  try { p = p || {}; const L = locksLoad(p.root); let n = 0; for (const k of Object.keys(L.files)) if (!p.agent || L.files[k].agent === String(p.agent)) { delete L.files[k]; n++; } locksSave(p.root, L); return { ok: true, n }; } catch (x) { return { ok: false, n: 0, error: String(x && x.message || x) }; }
});

// ---- confirmation (fenêtre native, impossible à contourner depuis une page web) ----
ipcMain.handle('local:confirm', async (_e, p) => {
  p = p || {};
  try {
    const parent = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows()[0];
    const buttons = p.always ? ['Autoriser', 'Toujours autoriser', 'Refuser'] : ['Autoriser', 'Refuser'];
    const r = await dialog.showMessageBox(parent, { type: 'question', buttons, defaultId: buttons.length - 1, cancelId: buttons.length - 1, noLink: true, title: 'AI Hub — autorisation', message: String(p.title || 'L\'IA veut agir').slice(0, 200), detail: String(p.detail || '').slice(0, 1800) });
    const c = buttons[r.response]; return { choice: c === 'Autoriser' ? 'once' : c === 'Toujours autoriser' ? 'always' : 'no' };
  } catch { return { choice: 'no' }; }
});

// ---- mémoire du dossier, journal, besoins, réglages, annulation ciblée, git ----
const needsFile = (root) => path.join(aihDir(root), 'needs.txt');
ipcMain.handle('local:memo', (_e, p) => {
  try { const d = aihDir(p.root), f = path.join(d, 'memo.txt');
    if (p.op === 'set') { fs.mkdirSync(d, { recursive: true }); atomicWrite(f, String(p.text || '').slice(0, 2000), 'utf8'); return { ok: true }; }
    return { ok: true, text: fs.existsSync(f) ? fs.readFileSync(f, 'utf8').trim() : '' }; } catch (x) { return { ok: false, text: '', error: String(x.message || x) }; }
});
ipcMain.handle('local:needs', (_e, p) => {
  try { const d = aihDir(p.root), f = needsFile(p.root); fs.mkdirSync(d, { recursive: true });
    const read = () => fs.existsSync(f) ? fs.readFileSync(f, 'utf8').split('\n').filter(Boolean) : [];
    if (p.op === 'add') fs.appendFileSync(f, new Date().toISOString().slice(0, 16).replace('T', ' ') + ' | ' + String(p.text || '').replace(/\s+/g, ' ').slice(0, 300) + '\n');
    else if (p.op === 'remove') { const a = read(); a.splice(Number(p.index), 1); fs.writeFileSync(f, a.join('\n') + (a.length ? '\n' : '')); }
    else if (p.op === 'clear') fs.writeFileSync(f, '');
    return { ok: true, list: read().map(l => { const i = l.indexOf(' | '); return i > 0 ? { at: l.slice(0, i), t: l.slice(i + 3) } : { at: '', t: l }; }) };
  } catch (x) { return { ok: false, list: [], error: String(x.message || x) }; }
});
ipcMain.handle('local:history', (_e, p) => {
  try { const d = aihDir(p.root), jf = path.join(d, 'journal.txt');
    const j = fs.existsSync(jf) ? fs.readFileSync(jf, 'utf8').split('\n').filter(Boolean).slice(-150).reverse() : [];
    return { ok: true, journal: j, undo: undoIndex(p.root).slice(-80).reverse().map(e => ({ id: e.id, ts: e.ts, turn: e.turn, op: e.op, rel: e.rel, rel2: e.rel2 })) };
  } catch (x) { return { ok: false, journal: [], undo: [], error: String(x.message || x) }; }
});
ipcMain.handle('local:undo', (_e, p) => {
  try { const idx = undoIndex(p.root); let list = [];
    if (p.id) list = idx.filter(e => e.id === p.id);
    else if (p.turn) list = idx.filter(e => e.turn === p.turn).reverse();
    else if (p.last) { const lt = idx.length ? idx[idx.length - 1].turn : null; list = idx.filter(e => e.turn === lt).reverse(); }
    if (!list.length) return { ok: false, out: 'rien à annuler' };
    const r = undoMany(p.root, list); seenClear(p.root); jlog(p.root, 'undo ' + r.ok + '/' + list.length + ' annulation(s) demandée(s) par l\'utilisateur');
    return { ok: r.ok > 0, out: r.out.join('\n'), n: r.ok };
  } catch (x) { return { ok: false, out: String(x.message || x) }; }
});
// 4.11 (E2) : panneau « Changements » : fichiers modifiés par tour + refus d'un seul fichier (réutilise l'annulation existante)
ipcMain.handle('local:turnDiff', (_e, p) => {
  try { const idx = undoIndex(p.root), turn = p.turn || (idx.length ? idx[idx.length - 1].turn : null), seen = new Map();
    for (const e of idx) if (e.turn === turn) { const k = e.rel || ''; if (!seen.has(k)) seen.set(k, { rel: e.rel, rel2: e.rel2 || '', ops: [], id: e.id }); seen.get(k).ops.push(e.op); }
    return { ok: true, turn, files: [...seen.values()].slice(0, 80) };
  } catch (x) { return { ok: false, files: [], error: String(x.message || x) }; }
});
ipcMain.handle('local:rejectFile', (_e, p) => {
  try { const idx = undoIndex(p.root), list = idx.filter(e => e.turn === p.turn && (e.rel === p.rel || e.rel2 === p.rel)).reverse();
    if (!list.length) return { ok: false, out: 'rien à annuler pour ' + p.rel };
    const r = undoMany(p.root, list); seenClear(p.root); jlog(p.root, 'undo ' + r.ok + '/' + list.length + ' ' + p.rel + ' refusé par l\'utilisateur');
    return { ok: r.ok > 0, out: r.out.join('\n'), n: r.ok };
  } catch (x) { return { ok: false, out: String(x.message || x) }; }
});
ipcMain.handle('local:cfg', (_e, p) => {      // copie lisible des réglages dans .aihub/config.json (les autorisations, elles, restent dans AI Hub)
  try { const d = aihDir(p.root); fs.mkdirSync(d, { recursive: true }); atomicWrite(path.join(d, 'config.json'), JSON.stringify(p.cfg || {}, null, 2)); return { ok: true }; } catch (x) { return { ok: false, error: String(x.message || x) }; }
});
function git(root, args) { return new Promise((res) => cp.execFile('git', args, { cwd: root, windowsHide: true, timeout: 30000, maxBuffer: 4 * 1024 * 1024 }, (err, so, se) => res({ ok: !err, out: String(so || ''), err: String(se || (err && err.message) || '') }))); }
ipcMain.handle('local:git', async (_e, p) => {      // point de sauvegarde avant que l'IA agisse (dépôt git seulement)
  try {
    const root = fs.realpathSync(p.root); if (!fs.existsSync(path.join(root, '.git'))) return { ok: true, repo: false };
    try { const ex = path.join(root, '.git', 'info', 'exclude'); const cur = fs.existsSync(ex) ? fs.readFileSync(ex, 'utf8') : ''; if (!/^\.aihub\/?$/m.test(cur)) { fs.mkdirSync(path.dirname(ex), { recursive: true }); fs.appendFileSync(ex, (cur && !cur.endsWith('\n') ? '\n' : '') + '.aihub/\n'); } } catch {}
    const st = await git(root, ['status', '--porcelain']); if (!st.ok) return { ok: false, repo: true, error: st.err.slice(0, 120) };
    if (!st.out.trim()) return { ok: true, repo: true, committed: false };
    const add = await git(root, ['add', '-A']); if (!add.ok) return { ok: false, repo: true, error: add.err.slice(0, 120) };
    const hasName = (await git(root, ['config', 'user.name'])).out.trim(), pre = hasName ? [] : ['-c', 'user.name=AI Hub', '-c', 'user.email=aihub@localhost'];
    const cm = await git(root, pre.concat(['commit', '--no-verify', '-m', String(p.label || 'AI Hub : point de sauvegarde').slice(0, 100)]));
    jlog(root, (cm.ok ? 'ok  ' : 'err ') + 'git ' + (p.label || 'point de sauvegarde'));
    return { ok: cm.ok, repo: true, committed: cm.ok, error: cm.ok ? '' : cm.err.slice(0, 120) };
  } catch (x) { return { ok: false, error: String(x.message || x) }; }
});

// 4.11 (C2) : conventions de PLAN.md + tâche en cours/prochaine + 3 dernières faites, injectées dans la CARTE (court, stable)
function ctxBrief(root) {
  try {
    const base = realBase(root), o = [];
    try { const pm = fs.readFileSync(path.join(base, 'PLAN.md'), 'utf8'), m = /^##\s*Conventions[^\n]*\n([\s\S]*?)(?=\n##\s|$)/im.exec(pm); if (m && m[1].trim()) o.push('CONVENTIONS (PLAN.md) : ' + m[1].trim().replace(/\s+/g, ' ').slice(0, 800)); } catch {}
    try {
      const T = JSON.parse(fs.readFileSync(path.join(aihDir(root), 'tasks.json'), 'utf8'));
      if (Array.isArray(T) && T.length) {
        const dn = new Set(T.filter(x => x.s === 'done').map(x => x.id)), doing = T.filter(x => x.s === 'doing');
        const nx = doing.concat(T.filter(x => x.s === 'todo' && (x.d || []).every(i => dn.has(i))).sort((x, y) => (x.p || 2) - (y.p || 2) || x.id - y.id)).slice(0, 2);
        o.push('TÂCHES ' + dn.size + '/' + T.length + (nx.length ? ' · SUIVANTE : ' + nx.map(x => x.id + ' ' + x.t.slice(0, 90)).join(' | ') : '') + ' · FAITES RÉCEMMENT : ' + T.filter(x => x.s === 'done').slice(-3).map(x => x.id + ' ' + x.t.slice(0, 40)).join(' ; '));
      }
    } catch {}
    return o.length ? o.join('\n') + '\n' : '';
  } catch { return ''; }
}
// ---- 3.7.0 : carte du projet + pré-lecture, règles du projet ----
ipcMain.handle('local:index', (_e, p) => {
  try {
    p = p || {}; const root = p.root; if (!root || !fs.statSync(root).isDirectory()) return { ok: false };
    LOC_IGN = new Set([...LOC_IGNORE, ...((p.ignore || []).map(x => String(x).trim()).filter(Boolean))]);
    try { CTX_ON = !fs.existsSync(path.join(aihDir(root), 'ctx-off')); } catch {}   // interrupteur : créer le fichier .aihub/ctx-off désactive le contexte ULTRA
    const idx = idxUpdate(root), pr = idxPre(root, idx, p.query || '', Math.max(0, Math.min(14000, +p.cap || 0)));
    return { ok: true, count: Object.keys(idx.files).length, map: ctxBrief(root) + idxMap(idx, Math.max(4, Math.min(20, +p.mapN || 15))) + (CTX_ON ? (() => { try { const dg = ctxDigest(idx); return dg ? '\n' + dg : ''; } catch { return ''; } })() : ''), pre: pr.pre, preFiles: pr.files, test: projHasTest(root) };
  } catch (x) { return { ok: false, error: String(x.message || x) }; }
});
ipcMain.handle('local:rules', (_e, p) => {
  try { const d = aihDir(p.root), f = path.join(d, 'rules.md');
    if (p.op === 'set') { fs.mkdirSync(d, { recursive: true }); atomicWrite(f, String(p.text || '').replace(/\r/g, '').slice(0, 1500), 'utf8'); return { ok: true }; }
    return { ok: true, text: fs.existsSync(f) ? fs.readFileSync(f, 'utf8').slice(0, 1500) : '' };
  } catch (x) { return { ok: false, text: '', error: String(x.message || x) }; }
});

ipcMain.handle('local:kill', () => { let n = 0; for (const c of [...LOC_PROCS]) { try { c.__killed = true; killTree(c); n++; } catch {} } return { ok: true, n }; });

// ---- 3.1.0 : état de reprise (.aihub/state.json) : tâche en cours, plan, derniers tours, derniers résultats ----
// Un autre compte (ou une conversation neuve, ou l'app relancée) reprend EXACTEMENT là où le précédent s'est arrêté.
const stFile = (root) => path.join(aihDir(root), 'state.json');
function stRead(root) { try { const s = JSON.parse(fs.readFileSync(stFile(root), 'utf8')); return s && typeof s === 'object' ? s : {}; } catch { return {}; } }
function stWrite(root, s) { const d = aihDir(root); fs.mkdirSync(d, { recursive: true }); const tmp = stFile(root) + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(s)); fs.renameSync(tmp, stFile(root)); }
ipcMain.handle('local:state', (_e, p) => {
  try {
    p = p || {}; let s = stRead(p.root);
    if (p.op === 'task') {
      const t = s.task;
      if (p.keep && t && t.status !== 'done') { t.status = 'running'; }
      else s = { task: { text: String(p.text || '').slice(0, 1500), at: Date.now(), status: 'running' }, plan: '', rounds: [], n: 0, lastResults: '' };
      stWrite(p.root, s);
    } else if (p.op === 'round') {
      s.rounds = s.rounds || []; s.n = (s.n || 0) + 1;
      s.rounds.push({ n: s.n, acc: String(p.acc || '').slice(0, 30), talk: String(p.talk || '').slice(0, 200), acts: (p.acts || []).slice(0, 12).map(a => ({ ok: !!a.ok, t: String(a.t || '').slice(0, 80) })), at: Date.now() });
      if (s.rounds.length > 40) s.rounds.shift();
      s.lastResults = String(p.results || '').slice(-20000);
      if (!s.task) s.task = { text: '', at: Date.now(), status: 'running' };
      if (p.status) s.task.status = p.status;
      if (p.status === 'done') s.lastResults = '';
      stWrite(p.root, s);
    } else if (p.op === 'plan') { s.plan = String(p.text || '').slice(0, 1600); stWrite(p.root, s); }
    else if (p.op === 'status') { if (!s.task) s.task = { text: '', at: Date.now() }; s.task.status = String(p.status || 'running'); if (p.status === 'done') s.lastResults = ''; stWrite(p.root, s); }
    else if (p.op === 'results') { s.lastResults = String(p.results || '').slice(-20000); stWrite(p.root, s); }
    else if (p.op === 'reset') { s = {}; stWrite(p.root, s); }
    return { ok: true, st: s };
  } catch (x) { return { ok: false, st: {}, error: String(x.message || x) }; }
});

// ===== 3.8.0 : explorateur du dossier du projet (un projet = un dossier ; ses fichiers = ceux du dossier) =====
const PJ_IGN = new Set(['node_modules', '.git', '.aihub', '.hg', '.svn', 'dist', 'build', '__pycache__', '.venv', 'venv', '.next', '.cache', 'target', '.idea', '.vs', 'coverage']);
const PJ_IMG = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', ico: 'image/x-icon', bmp: 'image/bmp' };
const pjSafe = (root, rel) => {            // chemin toujours à l'intérieur du dossier du projet
  const r = path.resolve(String(root || '')), f = path.resolve(r, String(rel || ''));
  if (f !== r && !f.startsWith(r + path.sep)) throw new Error('Chemin hors du projet');
  return f;
};
const pjIsText = (buf) => { const n = Math.min(buf.length, 4000); for (let i = 0; i < n; i++) if (buf[i] === 0) return false; return true; };
const pjSort = (a, b) => (b.isDirectory() - a.isDirectory()) || a.name.localeCompare(b.name, 'fr', { numeric: true });
function pjKind(dir, e) {                          // { d, f, lnk } — suit les liens symboliques
  let d = e.isDirectory(), f = e.isFile(), lnk = false;
  if (e.isSymbolicLink()) { try { const q = fs.statSync(path.join(dir, e.name)); d = q.isDirectory(); f = q.isFile(); lnk = true; } catch { return null; } }
  return { d, f, lnk };
}
function pjWalk(root, cb, cap) {
  let n = 0; const rec = (dir, rel, depth) => {
    if (n >= cap || depth > 40) return;
    let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    ents.sort(pjSort);
    for (const e of ents) {
      if (n >= cap) return;
      const r = rel ? rel + '/' + e.name : e.name, f = path.join(dir, e.name), k = pjKind(dir, e);
      if (!k) continue;
      if (k.d) { const heavy = k.lnk || PJ_IGN.has(e.name); n++; if (cb(heavy ? { p: r, d: true, h: 1 } : { p: r, d: true }) === false) return; if (!heavy) rec(f, r, depth + 1); }
      else if (k.f) { n++; let s = 0, m = 0; try { const q = fs.statSync(f); s = q.size; m = Math.round(q.mtimeMs); } catch {} if (cb({ p: r, d: false, s, m }) === false) return; }
    }
  };
  rec(root, '', 0);
}
ipcMain.handle('proj:tree', (_e, p) => {
  try { const root = pjSafe(p && p.root, ''); if (!fs.statSync(root).isDirectory()) return { ok: false };
    const items = []; pjWalk(root, (x) => { items.push(x); }, 20000);
    return { ok: true, items, cut: items.length >= 20000 };
  } catch (x) { return { ok: false, error: String(x.message || x) }; }
});
ipcMain.handle('proj:read', (_e, p) => {
  try { const f = pjSafe(p.root, p.rel), st = fs.statSync(f), ext = path.extname(f).slice(1).toLowerCase();
    if (!st.isFile()) return { ok: false, error: 'Pas un fichier' };
    if (PJ_IMG[ext] && st.size < 4e6) return { ok: true, kind: 'img', url: 'data:' + PJ_IMG[ext] + ';base64,' + fs.readFileSync(f).toString('base64'), mtime: st.mtimeMs, size: st.size };
    if (st.size > 250000) return { ok: true, kind: 'big', size: st.size, mtime: st.mtimeMs };
    const buf = fs.readFileSync(f); if (!pjIsText(buf)) return { ok: true, kind: 'bin', size: st.size, mtime: st.mtimeMs };
    return { ok: true, kind: 'text', text: buf.toString('utf8').replace(/^\uFEFF/, ''), mtime: st.mtimeMs, size: st.size };
  } catch (x) { return { ok: false, error: String(x.message || x) }; }
});
ipcMain.handle('proj:save', (_e, p) => {
  try { const f = pjSafe(p.root, p.rel); let exists = false, cur = 0;
    try { cur = fs.statSync(f).mtimeMs; exists = true; } catch {}
    if (exists && p.mtime && !p.force && Math.abs(cur - p.mtime) > 2) return { ok: false, conflict: true, mtime: cur };
    fs.mkdirSync(path.dirname(f), { recursive: true });
    atomicWrite(f, String(p.text == null ? '' : p.text), 'utf8');
    return { ok: true, mtime: fs.statSync(f).mtimeMs };
  } catch (x) { return { ok: false, error: String(x.message || x) }; }
});
ipcMain.handle('proj:op', async (_e, p) => {
  try { const f = pjSafe(p.root, p.rel);
    if (p.op === 'mkdir') fs.mkdirSync(f, { recursive: true });
    else if (p.op === 'rename') { const t = pjSafe(p.root, p.to); if (fs.existsSync(t)) return { ok: false, error: 'Ce nom existe déjà' }; fs.mkdirSync(path.dirname(t), { recursive: true }); fs.renameSync(f, t); }
    else if (p.op === 'delete') { if (f === path.resolve(p.root)) return { ok: false }; await shell.trashItem(f); }
    else if (p.op === 'show') shell.showItemInFolder(f);
    else return { ok: false };
    return { ok: true };
  } catch (x) { return { ok: false, error: String(x.message || x) }; }
});
ipcMain.handle('proj:grep', (_e, p) => {
  try { const root = pjSafe(p.root, ''), q = String(p.q || '').toLowerCase(); if (q.length < 2) return { ok: true, hits: [] };
    const hits = []; let files = 0;
    pjWalk(root, (x) => {
      if (x.d) return; if (hits.length >= 200) return false; if ((x.s || 0) > 300000) return;
      let buf; try { buf = fs.readFileSync(path.join(root, x.p)); } catch { return; } if (!pjIsText(buf)) return; files++;
      const lines = buf.toString('utf8').split('\n');
      for (let i = 0; i < lines.length && hits.length < 200; i++) { const L = lines[i]; if (L.length < 4000 && L.toLowerCase().includes(q)) hits.push({ p: x.p, l: i + 1, t: L.trim().slice(0, 160) }); }
    }, 20000);
    return { ok: true, hits, files, cut: hits.length >= 200 };
  } catch (x) { return { ok: false, error: String(x.message || x) }; }
});

// ---------- 3.8.2 : un dossier = ce qu'affiche l'explorateur, en temps réel ----------
ipcMain.handle('proj:list', (_e, p) => {          // un seul niveau d'un dossier (dossiers lourds : node_modules, dist, .git…)
  try { const rel = String(p.rel || ''), dir = pjSafe(p.root, rel), ents = fs.readdirSync(dir, { withFileTypes: true }), items = [];
    ents.sort(pjSort);
    for (const e of ents) { if (items.length >= 5000) break; const r = rel ? rel + '/' + e.name : e.name, k = pjKind(dir, e); if (!k) continue;
      if (k.d) items.push({ p: r, d: true, h: 1 });
      else if (k.f) { let s = 0, mt = 0; try { const q = fs.statSync(path.join(dir, e.name)); s = q.size; mt = Math.round(q.mtimeMs); } catch {} items.push({ p: r, d: false, s, m: mt }); } }
    return { ok: true, items, cut: ents.length > 5000 };
  } catch (x) { return { ok: false, error: String(x.message || x) }; }
});
const pjW = { root: null, w: null, t: null };
function pjUnwatch() { try { if (pjW.w) pjW.w.close(); } catch {} clearTimeout(pjW.t); pjW.w = null; pjW.root = null; }
ipcMain.handle('proj:watch', (_e, p) => {
  try { const root = pjSafe(p && p.root, '');
    if (pjW.w && pjW.root === root) return { ok: true };
    pjUnwatch(); if (!fs.statSync(root).isDirectory()) return { ok: false };
    pjW.root = root;
    pjW.w = fs.watch(root, { recursive: true, persistent: false }, (_ev, name) => {
      const seg = String(name || '').split(/[\\/]/); if (seg.includes('.git') || seg.includes('.aihub')) return;
      clearTimeout(pjW.t); pjW.t = setTimeout(() => { try { if (win && !win.isDestroyed()) win.webContents.send('proj-changed', { root }); } catch {} }, 200);
    });
    pjW.w.on('error', () => { pjUnwatch(); });
    return { ok: true };
  } catch (x) { pjUnwatch(); return { ok: false, error: String(x.message || x) }; }
});
app.on('before-quit', pjUnwatch);
