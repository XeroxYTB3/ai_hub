/*
 * ⚠ RÈGLE N°1 — MISE À JOUR UNIVERSELLE (à lire AVANT toute modification de ce fichier)
 * Cette mise à jour doit TOUJOURS être compatible, PEU IMPORTE la version actuellement installée :
 * version d'origine de l'exe, ancienne, récente, ou même plus récente que celle-ci. N'importe qui doit
 * pouvoir l'installer, depuis n'importe quelle version, sans rien perdre (comptes, scripts, réglages).
 * Pour cela, TOUJOURS :
 *  1. Livrer un paquet COMPLET : les 4 fichiers (main-core.js, preload.js, webview-preload.js, index.html), jamais un paquet partiel.
 *  2. requiresLauncher = null. Ne rien supposer du lanceur (voir normalizeCtx dans main-core.js) et ne jamais exiger un lanceur plus récent.
 *  3. Garder les 4 fichiers cohérents entre eux (preload.js <-> main-core.js <-> index.html).
 *  4. Savoir lire les données écrites par N'IMPORTE QUELLE version : champ absent = valeur par défaut ; ne jamais supprimer ni réécrire un champ inconnu.
 *  5. Ne rien écrire qu'une version plus ancienne ne puisse relire (le retour arrière doit toujours marcher).
 *  6. Numéro de version strictement supérieur au précédent ; un numéro déjà publié n'est jamais réutilisé.
 */
const { contextBridge, ipcRenderer } = require('electron');
const i = (c) => (...a) => ipcRenderer.invoke(c, ...a);
contextBridge.exposeInMainWorld('api', {
  copy: i('copy'), clear: i('clear'), wvpreload: i('wvpreload'), notify: i('notify'),
  exportAll: i('export'), importAll: i('import'),
  stateLoad: i('state:load'), stateSave: i('state:save'), orphans: i('orphans'), openData: i('open-data'),
  gemini: i('gemini'), updInfo: i('upd:info'), updApply: i('upd:apply'), updRevert: i('upd:revert'),
  updHealthy: i('upd:healthy'), updCheck: i('upd:check'), updFetch: i('upd:fetch'), updSetup: i('upd:setup'), updFail: i('upd:fail'), relaunch: i('relaunch'), launcherInfo: i('launcher:info'), launcherRebuild: i('launcher:rebuild'), launcherPick: i('launcher:pick'), launcherRestart: i('launcher:restart'), packZip: i('pack:zip'), chromeStart: i('chrome:start'), chromeWs: i('chrome:ws'), chromeImport: i('chrome:import'), chromeStop: i('chrome:stop'),
  setTheme: i('theme:set'), localPick: i('local:pick'), projTree: i('proj:tree'), projRead: i('proj:read'), projSave: i('proj:save'), projOp: i('proj:op'), projGrep: i('proj:grep'), projList: i('proj:list'), projWatch: i('proj:watch'), localCheck: i('local:check'), localExec: i('local:exec'), localConfirm: i('local:confirm'), localMemo: i('local:memo'), localNeeds: i('local:needs'), localHistory: i('local:history'), localUndo: i('local:undo'), localCfg: i('local:cfg'), localGit: i('local:git'), localKill: i('local:kill'), localIndex: i('local:index'), localRules: i('local:rules'), localState: i('local:state'), localTurnDiff: i('local:turnDiff'), localLocks: i('local:locks'), localUnlock: i('local:unlock'), localVerifyTurn: i('local:verifyTurn'), localRejectFile: i('local:rejectFile'), localApiAsk: i('local:apiAsk'), localApiCancel: i('local:apiCancel'), saveFile: i('save:file'), showItem: i('show:item'), convPut: i('conv:put'), convSearch: i('conv:search'), convCount: i('conv:count'), convClear: i('conv:clear'),
  onLauncher: (cb) => ipcRenderer.on('launcher-event', (_e, d) => cb(d)),
  onNet: (cb) => ipcRenderer.on('net-event', (_e, d) => cb(d)), onNotifClick: (cb) => ipcRenderer.on('notif-click', (_e, id) => cb(id)),
  onProj: (cb) => ipcRenderer.on('proj-changed', (_e, d) => cb(d)),
  onApiDelta: (cb) => ipcRenderer.on('api-delta', (_e, d) => cb(d))
});
