// Lanceur STABLE : ne change pas avec les mises à jour. Choisit le code à lancer (core/ d'origine
// ou une version mise à jour) et revient en arrière tout seul si une mise à jour ne démarre pas.
const { app } = require('electron');
const path = require('path');
if (!process.env.AIHUB_TEST) app.setPath('userData', path.join(app.getPath('appData'), 'ai-hub'));
const { createUpdater } = require('./updater');

const bundledDir = path.join(__dirname, 'core');
const updater = createUpdater({ root: path.join(app.getPath('userData'), 'updates'), bundledDir, launcherVersion: app.getVersion() });
let boot;
try { boot = updater.prepare(); }
catch (e) { boot = { version: 'bundled', dir: bundledDir, rolledBack: 'erreur du système de mise à jour : ' + e.message }; }

const ctx = {
  updater, boot, bundledDir, launcherVersion: app.getVersion(),
  relaunch() { app.relaunch(); app.exit(0); },
  // Échec pendant l'essai d'une nouvelle version : retour arrière puis relance. Faux si rien à annuler.
  fatal(reason) { try { if (updater.fail(reason)) { ctx.relaunch(); return true; } } catch {} return false; }
};
process.on('uncaughtException', (e) => { if (!ctx.fatal('exception : ' + (e && e.message))) console.error(e); });
try { require(path.join(boot.dir, 'main-core.js'))(ctx); }
catch (e) { if (!ctx.fatal('chargement impossible : ' + e.message)) throw e; }
