// Tourne DANS chaque page de chat : détecte les événements et les envoie à l'app
const { ipcRenderer } = require('electron');
let cfg = { detectors: [], idle: 120, sel: {} };

// Sélecteurs par défaut + sélecteurs de secours ajoutés dans Paramètres > Détections (cfg.sel)
const BASE = {
  user: '[data-testid="user-message"],user-query,[data-message-author-role="user"]',
  ai: '.font-claude-response,model-response,[data-message-author-role="assistant"]',
  comp: '[contenteditable="true"],textarea',
  stop: '[data-testid="stop-button"],button[aria-label*="Stop" i],button[aria-label*="Arrêter" i],button[aria-label*="Interrompre" i]',
  send: '[data-testid="send-button"],button[aria-label*="Send" i],button[aria-label*="Envoyer" i]'
};
const S = Object.assign({}, BASE);
let SKIP = '';
function applySel() {
  const sel = cfg.sel || {};
  for (const k of Object.keys(BASE)) {
    let extra = (sel[k] || '').trim();
    if (extra) { try { document.querySelector(extra); } catch { ipcRenderer.sendToHost('hub-event', { type: 'selector-invalid', detail: { key: k, value: extra }, url: location.href, ts: Date.now() }); extra = ''; } }
    S[k] = extra ? BASE[k] + ',' + extra : BASE[k];
  }
  SKIP = S.user + ',' + S.ai + ',' + S.comp + ',nav,aside,script,style,noscript';
}
applySel();
ipcRenderer.on('hub:config', (_e, c) => { cfg = c; applySel(); });

// [événement, regex, événement de fin]
const PAT = [
  ['limit-hit', /(you('|’)?ve (hit|reached) (your|the|our) [\w\s-]{0,25}limit|usage limit|message limit|limit reached|out of (free )?messages|limite (d['’]utilisation|de messages|quotidienne|atteinte)|vous avez atteint (votre|la) limite|plus de messages|come back (later|tomorrow)|reviens? plus tard|upgrade to (continue|keep))/i, 'limit-cleared'],
  ['limit-soon', /(\d+|few) messages? (remaining|left)|il vous reste \d+ message|\d+ messages? restants?/i],
  ['rate-limit', /(too many (requests|messages)|rate limit|trop de (requêtes|messages)|slow down|ralentissez)/i],
  ['overloaded', /(overloaded|at capacity|high demand|forte demande|surcharg|temporarily unavailable|service unavailable|temporairement indisponible)/i],
  ['error', /(something went wrong|an error occurred|une erreur (est survenue|s['’]est produite)|network error|erreur réseau|failed to (load|send|generate)|impossible de (générer|envoyer)|unable to (send|generate))/i],
  ['chat-too-long', /(conversation (is )?too long|conversation trop longue|context (window|limit)|maximum (conversation )?length|longueur maximale|start a new (chat|conversation)|commencez une nouvelle conversation)/i],
  ['captcha', /(verify (that )?you are human|verifying you are human|vérifiez que vous êtes (un )?humain|checking your browser|just a moment|vérification de sécurité)/i, 'captcha-cleared']
];
const LOGIN_BTN = /^(log ?in|sign ?in|se connecter|connexion|continue with (google|email)|continuer avec (google|e-?mail))$/im;

const emit = (type, detail) => ipcRenderer.sendToHost('hub-event', { type, detail, url: location.href, ts: Date.now() });
const q = (s) => { try { return [...document.querySelectorAll(s)]; } catch { return []; } };
const vis = (e) => e && e.offsetParent !== null;
emit('page-start');
const flags = {};
const edge = (k, on, onT, offT, d) => {
  if (on && !flags[k]) { flags[k] = 1; emit(onT, d); }
  else if (!on && flags[k]) { flags[k] = 0; if (offT) emit(offT); }
};
function shortTexts() {
  const out = [], w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n;
  while ((n = w.nextNode())) {
    const t = n.nodeValue.trim();
    if (t.length > 2 && t.length < 300) { const p = n.parentElement; if (p && !p.closest(SKIP)) out.push(t); }
  }
  return out.join('\n');
}

let lastUrl = location.href, pu = null, lastLen = 0, lastGrow = 0, recentSend = 0, lastTyping = 0, lastAct = Date.now();
let gen = false, genStart = 0, genSeen = 0, lg = null, lgCount = 0, t0 = Date.now();

document.addEventListener('keydown', (e) => {
  lastAct = Date.now();
  if (e.key === 'Enter' && !e.shiftKey && e.target.closest && e.target.closest(S.comp)) {
    const t = (e.target.value || e.target.innerText || '').trim();
    if (t) { recentSend = Date.now(); emit('send-attempt', { via: 'enter', preview: t.slice(0, 200) }); }
  }
}, true);
document.addEventListener('click', (e) => {
  lastAct = Date.now();
  if (e.target.closest && e.target.closest(S.send)) {
    const c = q(S.comp)[0]; const t = c ? (c.value || c.innerText || '').trim() : '';
    recentSend = Date.now(); emit('send-attempt', { via: 'click', preview: t.slice(0, 200) });
  }
}, true);
document.addEventListener('input', (e) => {
  lastAct = Date.now();
  if (e.target.closest && e.target.closest(S.comp) && Date.now() - lastTyping > 3000) emit('typing');
  lastTyping = Date.now();
}, true);
document.addEventListener('visibilitychange', () => emit(document.hidden ? 'tab-hidden' : 'tab-visible'));
window.addEventListener('offline', () => emit('offline'));
window.addEventListener('online', () => emit('online'));
window.addEventListener('load', () => emit('page-loaded', { title: document.title }));

function poll() {
  if (!document.body) return;
  const now = Date.now();
  // URL / navigation
  if (location.href !== lastUrl) {
    emit('url-changed', { from: lastUrl, to: location.href }); lastUrl = location.href;
    if (/^\/(new|app|chat)?\/?$/.test(location.pathname)) emit('new-chat');
    else if (/\/(chat|c|chats|app|thread|search)\/[\w-]{8,}/.test(location.pathname)) emit('chat-opened');
  }
  // connexion
  const txt = shortTexts();
  const comp = q(S.comp).some(vis), pw = q('input[type=password]').some(vis);
  const cur = comp && !pw ? true : (!comp && (pw || LOGIN_BTN.test(txt)) && now - t0 > 2500 ? false : null);
  if (cur !== null) {
    if (cur === lg) lgCount = 0; else if (++lgCount >= 2) {
      if (cur) emit('logged-in'); else { emit('login-required'); if (lg === true) emit('session-expired'); }
      lg = cur; lgCount = 0;
    }
  }
  // messages + génération
  const users = q(S.user), ais = q(S.ai), u = users.length;
  if (pu === null || u < pu) pu = u;
  else if (u === pu + 1) {
    pu = u; recentSend = now;
    emit('message-sent', { count: u, preview: (users[u - 1].innerText || '').trim().slice(0, 200) });
  } else pu = u;
  const last = ais[ais.length - 1], len = last ? last.textContent.length : 0;
  if (len > lastLen && now - recentSend < 90000) lastGrow = now;
  lastLen = len;
  const stopOn = q(S.stop).some(vis);
  const g = stopOn || now - lastGrow < 1500;
  if (g) genSeen = now;
  if (g && !gen) { gen = true; genStart = now; emit('response-started', { via: stopOn ? 'stop-button' : 'text-growth' }); }
  else if (!g && gen && now - genSeen > 1200) {
    gen = false;
    emit('response-complete', { chars: len, seconds: Math.round((now - genStart) / 100) / 10, userMessages: u, aiMessages: ais.length, preview: last ? last.textContent.trim().slice(0, 300) : '' });
  }
  // bannières / erreurs
  for (const [type, re, off] of PAT) { const m = txt.match(re); edge('p' + type, !!m, type, off, m && { match: m[0].slice(0, 120) }); }
  // détecteurs personnalisés
  for (const d of cfg.detectors || []) {
    if (!d.name || !d.value || (d.host !== '*' && !location.hostname.endsWith(d.host))) continue;
    let on = false;
    try { on = d.kind === 'selector' ? q(d.value).length > 0 : new RegExp(d.value, 'i').test(txt); } catch {}
    edge('c' + d.name, on, d.name, d.name + '-gone', {});
  }
  // inactivité
  edge('idle', !gen && now - lastAct > (cfg.idle || 120) * 1000, 'idle', 'active', {});
}
setInterval(poll, 800);
