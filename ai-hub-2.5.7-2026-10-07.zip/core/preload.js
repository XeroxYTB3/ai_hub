const { contextBridge, ipcRenderer } = require('electron');
const i = (c) => (...a) => ipcRenderer.invoke(c, ...a);
contextBridge.exposeInMainWorld('api', {
  copy: i('copy'), clear: i('clear'), wvpreload: i('wvpreload'), notify: i('notify'),
  exportAll: i('export'), importAll: i('import'),
  stateLoad: i('state:load'), stateSave: i('state:save'), orphans: i('orphans'), openData: i('open-data'),
  gemini: i('gemini'), updInfo: i('upd:info'), updApply: i('upd:apply'), updRevert: i('upd:revert'),
  updHealthy: i('upd:healthy'), updFail: i('upd:fail'), relaunch: i('relaunch')
});
