const { app, BrowserWindow, ipcMain, session, clipboard, dialog, Notification, shell } = require('electron');
const path = require('path'), fs = require('fs'), crypto = require('crypto');
const { pathToFileURL } = require('url');

module.exports = function start(ctx) {
let win;
// (Le dossier de données fixe est défini par le lanceur main.js)
const ud = () => app.getPath('userData');
const STATE = () => path.join(ud(), 'ai-hub-state.json');
const BK = () => path.join(ud(), 'backups');
let lastBk = 0;

function create() {
  win = new BrowserWindow({
    width: 1440, height: 900, backgroundColor: '#161a26', autoHideMenuBar: true,
    icon: fs.existsSync(path.join(__dirname, 'icon.ico')) ? path.join(__dirname, 'icon.ico') : undefined,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), webviewTag: true, contextIsolation: true }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.on('render-process-gone', (_e, d) => { ctx.fatal('interface plantée : ' + (d && d.reason)); });
}

ipcMain.handle('copy', (_e, t) => clipboard.writeText(t));
ipcMain.handle('clear', (_e, p) => session.fromPartition(p).clearStorageData());
ipcMain.handle('wvpreload', () => pathToFileURL(path.join(__dirname, 'webview-preload.js')).href);
ipcMain.handle('notify', (_e, t, b) => { if (Notification.isSupported()) new Notification({ title: t, body: b }).show(); });

// Export de tous les comptes : liste + cookies de chaque session, chiffré (AES-256-GCM) si mot de passe
ipcMain.handle('export', async (_e, { state, partitions, pass }) => {
  const cookies = {};
  for (const p of partitions) cookies[p] = await session.fromPartition(p).cookies.get({});
  const data = JSON.stringify({ app: 'ai-hub', version: app.getVersion(), v: 1, exportedAt: new Date().toISOString(), state, cookies });
  let out = data;
  if (pass) {
    const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', crypto.scryptSync(pass, salt, 32), iv);
    const enc = Buffer.concat([c.update(data, 'utf8'), c.final()]);
    out = JSON.stringify({ app: 'ai-hub', version: app.getVersion(), enc: 1, salt: salt.toString('base64'), iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: enc.toString('base64') });
  }
  const r = await dialog.showSaveDialog(win, { defaultPath: 'ai-hub-comptes-' + new Date().toISOString().slice(0, 10) + '.json' });
  if (r.canceled) return { ok: false };
  fs.writeFileSync(r.filePath, out);
  return { ok: true, path: r.filePath, encrypted: !!pass };
});

ipcMain.handle('import', async (_e, pass) => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'JSON', extensions: ['json'] }], properties: ['openFile'] });
  if (r.canceled) return { ok: false };
  let j = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8'));
  const ver = j.version;
  if (j.app && j.app !== 'ai-hub') return { ok: false, error: 'Ce fichier ne vient pas de AI Hub' };
  if (j.enc) {
    try {
      const d = crypto.createDecipheriv('aes-256-gcm', crypto.scryptSync(pass || '', Buffer.from(j.salt, 'base64'), 32), Buffer.from(j.iv, 'base64'));
      d.setAuthTag(Buffer.from(j.tag, 'base64'));
      j = JSON.parse(Buffer.concat([d.update(Buffer.from(j.data, 'base64')), d.final()]).toString('utf8'));
    } catch { return { ok: false, error: 'Mot de passe incorrect ou fichier corrompu' }; }
  }
  let n = 0;
  for (const [p, list] of Object.entries(j.cookies || {})) for (const c of list) {
    try {
      const o = { url: `http${c.secure ? 's' : ''}://${c.domain.replace(/^\./, '')}${c.path}`, name: c.name, value: c.value, path: c.path, secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite, expirationDate: c.expirationDate };
      if (!c.hostOnly) o.domain = c.domain;
      await session.fromPartition(p).cookies.set(o); n++;
    } catch {}
  }
  return { ok: true, state: j.state, cookies: n, version: ver || j.version, current: app.getVersion() };
});

// Sauvegarde de l'état (comptes, code, détections) dans un fichier avec copies de secours
const count = (s) => { try { return (JSON.parse(s).accs || []).length; } catch { return -1; } };
ipcMain.handle('state:load', () => {
  const files = [STATE()];
  try { files.push(...fs.readdirSync(BK()).sort().reverse().map((f) => path.join(BK(), f))); } catch {}
  for (const f of files) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch {} }
  return null;
});
ipcMain.handle('state:save', (_e, json) => {
  fs.mkdirSync(BK(), { recursive: true });
  try {
    const old = fs.readFileSync(STATE(), 'utf8');
    if (old !== json && (count(json) < count(old) || Date.now() - lastBk > 60000)) {
      fs.writeFileSync(path.join(BK(), 'state-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json'), old); lastBk = Date.now();
      fs.readdirSync(BK()).sort().reverse().slice(40).forEach((f) => fs.unlinkSync(path.join(BK(), f)));
    }
  } catch {}
  fs.writeFileSync(STATE() + '.tmp', json); fs.renameSync(STATE() + '.tmp', STATE());
  return true;
});
// Sessions qui existent sur le disque mais ne sont plus dans la liste des comptes
ipcMain.handle('orphans', async (_e, known) => {
  let names = []; try { names = fs.readdirSync(path.join(ud(), 'Partitions')); } catch {}
  const out = [];
  for (const n of names) {
    if (!/^a\d+$/.test(n) || known.includes(n)) continue;
    const ck = await session.fromPartition('persist:' + n).cookies.get({});
    if (ck.length) out.push({ id: n, domains: [...new Set(ck.map((c) => c.domain.replace(/^\./, '')))] });
  }
  return out;
});
ipcMain.handle('open-data', () => shell.openPath(ud()));


// ---------- Résumé par Gemini (appel fait ici, dans le processus principal : pas de souci CORS) ----------
ipcMain.handle('gemini', async (_e, { key, model, system, prompt }) => {
  if (!key) return { ok: false, error: 'Clé Gemini absente' };
  const m = String(model || 'gemini-flash-latest').replace(/[^\w.\-]/g, '');
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), 90000);
  try {
    const r = await fetch((process.env.AIHUB_GEMINI_URL || 'https://generativelanguage.googleapis.com/v1beta/models/') + m + ':generateContent', {
      method: 'POST', signal: ac.signal, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ systemInstruction: system ? { parts: [{ text: system }] } : undefined, contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.2, maxOutputTokens: 8192 } })
    });
    const j = await r.json().catch(() => null);
    if (!r.ok) return { ok: false, status: r.status, error: (j && j.error && j.error.message) || 'HTTP ' + r.status };
    const c = j && j.candidates && j.candidates[0];
    const text = ((c && c.content && c.content.parts) || []).map((p) => p.text || '').join('').trim();
    if (!text) return { ok: false, error: 'Réponse vide (' + ((c && c.finishReason) || (j && j.promptFeedback && j.promptFeedback.blockReason) || '?') + ')' };
    return { ok: true, text };
  } catch (e) { return { ok: false, error: e.name === 'AbortError' ? 'Délai dépassé (90 s)' : e.message }; }
  finally { clearTimeout(to); }
});

// ---------- Mises à jour (la logique est dans updater.js, testée à part) ----------
const backupState = (ver) => {                       // copie des données AVANT d'installer : on ne perd rien
  try { fs.mkdirSync(BK(), { recursive: true }); fs.copyFileSync(STATE(), path.join(BK(), 'state-' + new Date().toISOString().replace(/[:.]/g, '-') + '-avant-maj-' + ver + '.json')); } catch {}
};
ipcMain.handle('upd:info', () => Object.assign(ctx.updater.info(), { active: ctx.boot.version, rolledBack: ctx.boot.rolledBack, dataDir: ud() }));
ipcMain.handle('upd:apply', async () => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'Mise à jour AI Hub', extensions: ['aihubupdate', 'json'] }], properties: ['openFile'] });
  if (r.canceled) return { ok: false, cancelled: true };
  try { return ctx.updater.install(ctx.updater.readPackage(r.filePaths[0]), { beforeInstall: backupState }); }
  catch (e) { return { ok: false, error: 'Fichier illisible : ' + e.message }; }
});
ipcMain.handle('upd:revert', (_e, to) => ctx.updater.revert(to));
ipcMain.handle('upd:healthy', () => ctx.updater.confirm());
ipcMain.handle('upd:fail', (_e, reason) => ctx.fatal('interface : ' + String(reason).slice(0, 200)));
ipcMain.handle('relaunch', () => { ctx.relaunch(); });
// Garde-fou : une nouvelle version qui ne confirme pas en 15 s est annulée
if (ctx.updater.info().pending) setTimeout(() => { if (ctx.updater.info().pending) ctx.fatal('aucune confirmation de démarrage en 15 s'); }, 15000);

// Une seule instance à la fois : empêche deux fenêtres d'écraser les mêmes données
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
  app.whenReady().then(create);
}
app.on('window-all-closed', () => app.quit());
};
