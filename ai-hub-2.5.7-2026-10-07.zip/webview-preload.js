// Tourne DANS chaque page de chat : détecte les événements et les envoie à l'app
const { ipcRenderer, webFrame } = require('electron');
let cfg = { detectors: [], idle: 120, sel: {} };

// Sélecteurs par défaut + sélecteurs de secours ajoutés dans Paramètres > Détections (cfg.sel)
const BASE = {
  user: '[data-testid="user-message"],user-query,[data-message-author-role="user"]',
  ai: '.font-claude-response,model-response,[data-message-author-role]:not([data-message-author-role="user"])',   // aligné sur index.html
  comp: '[contenteditable="true"],textarea',
  stop: '[data-testid="stop-button"],button[aria-label*="Stop" i],button[aria-label*="Arrêter" i],button[aria-label*="Interrompre" i]',
  send: '[data-testid="send-button"],button[aria-label*="Send" i],button[aria-label*="Envoyer" i]'
};
const S = Object.assign({}, BASE);
let SKIP = '';
function applySel() {
  const sel = cfg.sel || {};
  for (const k of Object.keys(BASE)) {
    let extra = (sel[k] || '').trim();
    if (extra) { try { document.querySelector(extra); } catch { ipcRenderer.sendToHost('hub-event', { type: 'selector-invalid', detail: { key: k, value: extra }, url: location.href, ts: Date.now() }); extra = ''; } }
    S[k] = extra ? BASE[k] + ',' + extra : BASE[k];
  }
  SKIP = S.user + ',' + S.ai + ',' + S.comp + ',nav,aside,script,style,noscript';
}
applySel();
ipcRenderer.on('hub:config', (_e, c) => { cfg = c; applySel(); });

// Limite atteinte : gérée à part (machine à états persistante, voir poll). Textes FR + EN de Claude, ChatGPT, Gemini...
const LIMIT_RE = /(you('|’)?ve (hit|reached|exceeded) (your|the|our|this) [\w\s-]{0,25}(limit|cap)|you (have|had) (hit|reached|exceeded) (your|the|our) [\w\s-]{0,25}(limit|cap)|you('|’)?re out of [\w\s-]{0,15}messages|usage (limit|cap)|message (limit|cap)|limit reached|out of (free )?messages|limite (d['’]utilisation|de messages|quotidienne|horaire|atteinte|dépassée)|vous avez (atteint|dépassé) (votre|la) limite|vous avez (épuisé|atteint) (vos|votre) [\w\s'’-]{0,25}(messages|quota|limite)|quota (épuisé|dépassé|exceeded)|(n['’]avez|il n['’]y a) plus de messages|plus de messages (gratuits|disponibles)|plus aucun message|come back (later|tomorrow)|reviens? plus tard)/i;
// Heure de retour annoncée par le site : « jusqu'à 13:40 », « until 1:40 PM », « resets at 14:00 »...
function parseUntil(s) {
  const m = String(s || '').match(/(?:jusqu['’]?\s*(?:à|a)|until|resets?(?:\s+at)?|reviens?\s+(?:à|at)|back\s+at)\s+(\d{1,2})(?:\s*[:h]\s*(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?/i);
  if (!m) return 0;
  let h = +m[1], mi = +(m[2] || 0); const ap = (m[3] || '').toLowerCase().replace(/\./g, '');
  if (ap === 'pm' && h < 12) h += 12; if (ap === 'am' && h === 12) h = 0;
  if (h > 23 || mi > 59) return 0;
  const d = new Date(); d.setHours(h, mi, 0, 0);
  if (d.getTime() <= Date.now() - 60000) d.setDate(d.getDate() + 1);   // déjà passée aujourd'hui : c'est demain
  return d.getTime();
}
// [événement, regex, événement de fin]
const PAT = [
  ['limit-soon', /(\d+|few) messages? (remaining|left)|il vous reste \d+ message|\d+ messages? restants?/i],
  ['rate-limit', /(too many (requests|messages)|rate limit|trop de (requêtes|messages)|slow down|ralentissez)/i],
  ['overloaded', /(overloaded|at capacity|high demand|forte demande|surcharg|temporarily unavailable|service unavailable|temporairement indisponible)/i],
  ['error', /(something went wrong|an error occurred|une erreur (est survenue|s['’]est produite)|network error|erreur réseau|failed to (load|send|generate)|impossible de (générer|envoyer)|unable to (send|generate))/i],
  ['chat-too-long', /(conversation (is )?too long|conversation trop longue|context (window|limit)|maximum (conversation )?length|longueur maximale|start a new (chat|conversation)|commencez une nouvelle conversation)/i],
  ['captcha', /(verify (that )?you are human|verifying you are human|vérifiez que vous êtes (un )?humain|checking your browser|just a moment|vérification de sécurité)/i, 'captcha-cleared']
];
const LOGIN_BTN = /^(log ?in|sign ?in|se connecter|connexion|continue with (google|email)|continuer avec (google|e-?mail))$/im;

const emit = (type, detail) => ipcRenderer.sendToHost('hub-event', { type, detail, url: location.href, ts: Date.now() });
const q = (s) => { try { return [...document.querySelectorAll(s)]; } catch { return []; } };
const vis = (e) => e && e.offsetParent !== null;
emit('page-start');
const flags = {};
const edge = (k, on, onT, offT, d) => {
  if (on && !flags[k]) { flags[k] = 1; emit(onT, d); }
  else if (!on && flags[k]) { flags[k] = 0; if (offT) emit(offT); }
};
// Texte court de TOUTE la page : uniquement pour la détection de connexion et les pages sans conversation (captcha, erreur plein écran)
function pageTexts() {
  const out = [], w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n;
  while ((n = w.nextNode())) {
    const t = n.nodeValue.trim();
    if (t.length > 2 && t.length < 300) { const p = n.parentElement; if (p && !p.closest(SKIP)) out.push(t); }
  }
  return out.join('\n');
}

// Texte court des ZONES D'INTERFACE seulement (alertes, fenêtres, bandeau autour de la zone de saisie).
// La conversation n'est JAMAIS lue : même si les sélecteurs de messages changent, un échange qui parle de
// "limite atteinte" ne peut plus déclencher de fausse alerte. On exclut aussi toute zone qui défile (= la conversation).
const ZONE_ALERT = '[role="alert"],[role="status"],[role="alertdialog"],[role="dialog"],[aria-modal="true"],[aria-live="assertive"],[data-testid*="limit" i],[data-testid*="banner" i],[data-testid*="toast" i],[data-testid*="error" i],[class*="toast" i],[class*="banner" i],[class*="snackbar" i]';
let scrollMemo = new WeakMap();
const isScroller = (el) => {
  let r = scrollMemo.get(el);
  if (r === undefined) {
    try { const cs = getComputedStyle(el); r = /(auto|scroll)/.test(cs.overflowY) && el.clientHeight > 120 && el.scrollHeight > el.clientHeight + 40; } catch { r = false; }
    scrollMemo.set(el, r);
  }
  return r;
};
const inTranscript = (el, root) => { for (let e = el; e; e = e.parentElement) { if (isScroller(e)) return true; if (e === root) break; } return false; };
const hasMsg = (el) => { try { return !!el.querySelector(S.user + ',' + S.ai) || !!el.closest(S.user + ',' + S.ai); } catch { return false; } };
function zoneTexts() {
  scrollMemo = new WeakMap();
  const roots = new Set(q(ZONE_ALERT));
  const c = q(S.comp).find(vis);
  if (c) {                                    // bandeau juste au-dessus / autour de la zone de saisie
    let p = c;
    for (let i = 0; i < 5 && p.parentElement && p.parentElement !== document.body; i++) {
      const n = p.parentElement;
      if (isScroller(n) || hasMsg(n)) break;
      p = n;
    }
    roots.add(p);
  }
  const UPG = /^(mettre à niveau|upgrade|passer (à|au) |s['’]abonner|subscribe|get (pro|max|plus))/i;
  for (const b of q('button,a')) {            // le bandeau de limite contient presque toujours un bouton d'abonnement
    if (!vis(b)) continue;
    const t = (b.textContent || '').trim();
    if (t.length > 40 || !UPG.test(t)) continue;
    let p = b;
    for (let i = 0; i < 4 && p.parentElement && p.parentElement !== document.body; i++) {
      const n = p.parentElement;
      if (isScroller(n) || hasMsg(n)) break;
      p = n;
    }
    roots.add(p);
  }
  const out = new Set();
  for (const root of roots) {
    if (!root.isConnected || hasMsg(root)) continue;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); let n;
    while ((n = w.nextNode())) {
      const t = n.nodeValue.trim();
      if (t.length < 3 || t.length >= 300) continue;
      const el = n.parentElement;
      if (!el || !el.getClientRects().length || el.closest(SKIP) || inTranscript(el, root)) continue;
      out.add(t);
    }
  }
  return [...out].join('\n');
}

// État stable : il faut N relevés consécutifs pour passer à "actif" (évite les clignotements)
const cnt = {};
function stable(k, raw, nOn, nOff) {
  const c = cnt[k] || (cnt[k] = { on: false, a: 0, b: 0 });
  if (raw) { c.b = 0; if (!c.on && ++c.a >= nOn) c.on = true; }
  else { c.a = 0; if (c.on && ++c.b >= nOff) c.on = false; }
  return c.on;
}

// ---------- Limite : mémoire persistante (la limite reste marquée tant qu'elle n'est pas vraiment levée) ----------
// Sources : (1) texte du bandeau, (2) réponse réseau 429 / "exceeded_limit" du site (fiable, indépendante de l'affichage).
// Elle n'est levée que si : un message est ensuite envoyé avec succès, l'IA a répondu, le bandeau disparaît sur la même
// page sans changement de conversation (limite réinitialisée), ou après 6 h. Changer de conversation ne la lève plus.
const lim = { on: false, ts: 0, src: '', until: 0 };
let lastNav = Date.now(), missSince = 0;      // dernière navigation ; début de l'absence du bandeau
const LIM_TTL = 6 * 3600 * 1000;
function setLim(on, src, match, until) {
  if (on === lim.on) return;
  lim.on = on; lim.src = on ? src : ''; lim.until = on ? (until || 0) : 0; lim.ts = Date.now(); missSince = 0;
  if (on) emit('limit-hit', { match: String(match || '').slice(0, 120), source: src, until: lim.until || undefined });
  else emit('limit-cleared');
}
// L'app dit que l'heure de retour est passée : on oublie la limite sans bruit (elle sera redétectée si elle est encore là)
ipcRenderer.on('hub:limit-reset', () => { lim.on = false; lim.src = ''; lim.until = 0; lim.ts = Date.now(); missSince = 0; if (cnt.dom) { cnt.dom.on = false; cnt.dom.a = 0; cnt.dom.b = 0; } });

// Crochet réseau injecté dans la page (monde principal) : voit les réponses du site aux envois de messages
const NONCE = Math.random().toString(36).slice(2) + Date.now().toString(36);
function netHook(N) {
  const WATCH = /(completion|\/conversation(\?|$)|\/f\/conversation|StreamGenerate|generateContent|\/responses(\?|$))/i;
  const STRONG = /exceeded_limit|message_limit|usage[ _]limit|(reached|hit|exceeded)[^"]{0,40}limit|limit[^"]{0,30}(reached|exceeded)|clear_in|resets?_?at|quota|daily limit|hourly limit/i;
  const post = (o) => { try { o.__aihub = N; window.postMessage(o, '*'); } catch (e) {} };
  const of = window.fetch;
  if (typeof of !== 'function' || of.__aihub) return;
  window.fetch = function () {
    const a = arguments, p = of.apply(this, a);
    try {
      const url = String((a[0] && a[0].url) || a[0] || ''), m = String((a[1] && a[1].method) || (a[0] && a[0].method) || 'GET').toUpperCase();
      if (m === 'POST' && WATCH.test(url)) p.then((r) => {
        if (r.ok) return post({ kind: 'ok' });
        if (r.status === 429 || r.status >= 400) r.clone().text().then((t) => {
          const strong = STRONG.test(t || '');
          if (r.status === 429 || strong) post({ kind: strong ? 'limit' : 'rate', status: r.status, body: String(t || '').slice(0, 160) });
        }).catch(() => { if (r.status === 429) post({ kind: 'rate', status: 429, body: '' }); });
      }).catch(() => {});
    } catch (e) {}
    return p;
  };
  window.fetch.__aihub = true;
}
// Pour les sites qui détectent Electron / un navigateur intégré (connexion Google) : on enlève les marques
function cleanIdentity() {
  try {
    const ua = navigator.userAgent || '';
    const major = (/Chrome\/(\d+)/.exec(ua) || [])[1] || '130', full = (/Chrome\/([\d.]+)/.exec(ua) || [])[1] || (major + '.0.0.0');
    const brands = [{ brand: 'Chromium', version: major }, { brand: 'Google Chrome', version: major }, { brand: 'Not?A_Brand', version: '99' }];
    const fvl = [{ brand: 'Chromium', version: full }, { brand: 'Google Chrome', version: full }, { brand: 'Not?A_Brand', version: '99.0.0.0' }];
    const u = navigator.userAgentData;
    if (u) Object.defineProperty(Navigator.prototype, 'userAgentData', { configurable: true, get() {
      return new Proxy(u, { get(t, k) {
        if (k === 'brands') return brands;
        if (k === 'toJSON') return () => ({ brands, mobile: t.mobile, platform: t.platform });
        if (k === 'getHighEntropyValues') return (h) => t.getHighEntropyValues(h).then((r) => { if (r) { r.brands = brands; r.fullVersionList = fvl; } return r; });
        const v = t[k]; return typeof v === 'function' ? v.bind(t) : v;
      } });
    } });
    if (!window.chrome) window.chrome = {};
    const c = window.chrome;
    if (!c.runtime) c.runtime = {};
    if (!c.app) c.app = { isInstalled: false, InstallState: { DISABLED: 'disabled', INSTALLED: 'installed', NOT_INSTALLED: 'not_installed' }, RunningState: { CANNOT_RUN: 'cannot_run', READY_TO_RUN: 'ready_to_run', RUNNING: 'running' } };
    if (!c.csi) c.csi = () => ({ startE: Date.now(), onloadT: Date.now(), pageT: performance.now(), tran: 15 });
    if (!c.loadTimes) c.loadTimes = () => ({ requestTime: Date.now() / 1000, navigationType: 'Other', connectionInfo: 'h2', npnNegotiatedProtocol: 'h2', wasAlternateProtocolAvailable: false, wasFetchedViaSpdy: true, wasNpnNegotiated: true });
    if (navigator.webdriver) Object.defineProperty(Navigator.prototype, 'webdriver', { configurable: true, get: () => false });
  } catch (e) {}
}
try { webFrame.executeJavaScript('(' + cleanIdentity.toString() + ')();(' + netHook.toString() + ')(' + JSON.stringify(NONCE) + ');').catch(() => {}); } catch {}
let lastRate = 0;
window.addEventListener('message', (e) => {
  const d = e.data;
  if (!d || d.__aihub !== NONCE) return;
  if (d.kind === 'limit') setLim(true, 'network', d.status + ' ' + d.body);
  else if (d.kind === 'rate') { if (Date.now() - lastRate > 15000) { lastRate = Date.now(); emit('rate-limit', { match: d.status + ' ' + d.body, source: 'network' }); } }
  else if (d.kind === 'ok') { if (lim.on) setLim(false); }
});

let lastUrl = location.href, pu = null, lastLen = 0, lastGrow = 0, recentSend = 0, lastTyping = 0, lastAct = Date.now();
let gen = false, genStart = 0, genSeen = 0, lg = null, lgCount = 0, t0 = Date.now();

document.addEventListener('keydown', (e) => {
  lastAct = Date.now();
  if (e.key === 'Enter' && !e.shiftKey && e.target.closest && e.target.closest(S.comp)) {
    const t = (e.target.value || e.target.innerText || '').trim();
    if (t) { recentSend = Date.now(); emit('send-attempt', { via: 'enter', preview: t.slice(0, 200) }); }
  }
}, true);
document.addEventListener('click', (e) => {
  lastAct = Date.now();
  if (e.target.closest && e.target.closest(S.send)) {
    const c = q(S.comp)[0]; const t = c ? (c.value || c.innerText || '').trim() : '';
    recentSend = Date.now(); emit('send-attempt', { via: 'click', preview: t.slice(0, 200) });
  }
}, true);
document.addEventListener('input', (e) => {
  lastAct = Date.now();
  if (e.target.closest && e.target.closest(S.comp) && Date.now() - lastTyping > 3000) emit('typing');
  lastTyping = Date.now();
}, true);
document.addEventListener('visibilitychange', () => emit(document.hidden ? 'tab-hidden' : 'tab-visible'));
window.addEventListener('offline', () => emit('offline'));
window.addEventListener('online', () => emit('online'));
window.addEventListener('load', () => emit('page-loaded', { title: document.title }));

function poll() {
  if (!document.body) return;
  const now = Date.now();
  // URL / navigation
  if (location.href !== lastUrl) {
    emit('url-changed', { from: lastUrl, to: location.href }); lastUrl = location.href; lastNav = now;
    if (/^\/(new|app|chat)?\/?$/.test(location.pathname)) emit('new-chat');
    else if (/\/(chat|c|chats|app|thread|search)\/[\w-]{8,}/.test(location.pathname)) emit('chat-opened');
  }
  // connexion
  const comp = q(S.comp).some(vis), pw = q('input[type=password]').some(vis);
  const cur = comp && !pw ? true : (!comp && (pw || LOGIN_BTN.test(pageTexts())) && now - t0 > 2500 ? false : null);
  if (cur !== null) {
    if (cur === lg) lgCount = 0; else if (++lgCount >= 2) {
      if (cur) emit('logged-in'); else { emit('login-required'); if (lg === true) emit('session-expired'); }
      lg = cur; lgCount = 0;
    }
  }
  // messages + génération
  const users = q(S.user), ais = q(S.ai), u = users.length;
  if (pu === null || u < pu) pu = u;
  else if (u === pu + 1) {
    pu = u; recentSend = now;
    emit('message-sent', { count: u, preview: (users[u - 1].innerText || '').trim().slice(0, 200) });
  } else pu = u;
  const last = ais[ais.length - 1], len = last ? last.textContent.length : 0;
  if (len > lastLen && now - recentSend < 90000) lastGrow = now;
  lastLen = len;
  const stopOn = q(S.stop).some(vis);
  const g = stopOn || now - lastGrow < 1500;
  if (g) genSeen = now;
  if (g && !gen) { gen = true; genStart = now; emit('response-started', { via: stopOn ? 'stop-button' : 'text-growth' }); }
  else if (!g && gen && now - genSeen > 1200) {
    gen = false;
    if (lim.on && genStart > lim.ts && len >= 20) setLim(false);
    emit('response-complete', { chars: len, seconds: Math.round((now - genStart) / 100) / 10, userMessages: u, aiMessages: ais.length, preview: last ? last.textContent.trim().slice(0, 300) : '' });
  }
  // bannières / erreurs
  // Pages sans conversation ni zone de saisie (captcha, erreur plein écran) : toute la page ; sinon seulement les zones d'interface
  const bare = !comp && users.length === 0 && ais.length === 0;
  const txt = bare ? pageTexts() : zoneTexts();
  const flat = txt.replace(/\s+/g, ' ');          // « Vous n'avez plus de / messages / gratuits… » = 3 morceaux de texte
  const lm = flat.match(LIMIT_RE);
  const domOn = stable('dom', !!lm, 3, 5);          // 3 relevés consécutifs pour s'activer
  if (lm) missSince = 0; else if (!missSince) missSince = now;
  if (domOn && !lim.on && now - lim.ts > 10000) setLim(true, 'page', lm && lm[0], parseUntil(flat));
  // bandeau disparu SANS changement de conversation autour de ce moment = limite réinitialisée ; sinon on garde la limite
  else if (lim.on && lim.src === 'page' && !lm && missSince && now - missSince > 4000 && lastNav < missSince - 3000) setLim(false);
  if (lim.on && now - lim.ts > LIM_TTL) setLim(false);
  for (const [type, re, off] of PAT) { const m = flat.match(re); const on = stable(type, !!m, 2, 3); edge('p' + type, on, type, off, m && { match: m[0].slice(0, 120) }); }
  // détecteurs personnalisés
  for (const d of cfg.detectors || []) {
    if (!d.name || !d.value || (d.host !== '*' && !location.hostname.endsWith(d.host))) continue;
    let on = false;
    try { on = d.kind === 'selector' ? q(d.value).length > 0 : new RegExp(d.value, 'i').test(txt); } catch {}
    edge('c' + d.name, on, d.name, d.name + '-gone', {});
  }
  // Google refuse la connexion dans une fenêtre intégrée
  if (/(^|\.)google\.com$/.test(location.hostname) && !flags.gblock) {
    const gt = pageTexts().replace(/\s+/g, ' ');
    if (/(impossible de vous connecter|couldn['’]?t sign you in|ce navigateur ou cette application ne sont peut-être pas sécurisés|this browser or app may not be secure)/i.test(gt)) { flags.gblock = 1; emit('google-blocked', { url: location.href }); }
  }
  // inactivité
  edge('idle', !gen && now - lastAct > (cfg.idle || 120) * 1000, 'idle', 'active', {});
}
setInterval(poll, 800);

// ---------- 2.2.4 : bouton « Fichiers AI Hub » dans la barre de saisie de Claude ----------
// Affiche la bibliothèque de fichiers d'AI Hub (triée par projets) directement dans Claude.
// L'app envoie la liste (noms seulement) ; un clic renvoie le choix à l'app, qui joint le fichier.
let MENU = { projects: [], files: [] };
let hbtn = null, hmenu = null, hlist = null, hfoot = null, hq = '';
const SELH = new Set();
ipcRenderer.on('hub:menu', (_e, d) => { if (d) MENU = d; if (hmenu) drawHubMenu(); });
const ATT = 'button[aria-label*="Add files" i],button[aria-label*="Ajouter des fichiers" i],button[aria-label*="Attach" i],button[aria-label*="Joindre" i],button[aria-label*="Upload" i],[data-testid="input-menu-trigger"],[data-testid="file-upload"]';
const hsvg = () => {
  const ns = 'http://www.w3.org/2000/svg', s = document.createElementNS(ns, 'svg'), p = document.createElementNS(ns, 'path');
  for (const [k, v] of [['viewBox', '0 0 24 24'], ['width', '18'], ['height', '18'], ['fill', 'none'], ['stroke', 'currentColor'], ['stroke-width', '1.8'], ['stroke-linecap', 'round'], ['stroke-linejoin', 'round']]) s.setAttribute(k, v);
  p.setAttribute('d', 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z'); s.appendChild(p); return s;
};
function ensureHubBtn() {
  try {
    if (!document.body || !/(^|\.)claude\.ai$/.test(location.hostname)) return;
    const comp = q(S.comp).find(vis);
    if (!comp) { if (hbtn) hbtn.style.display = 'none'; closeHubMenu(); return; }
    if (!hbtn) {
      hbtn = document.createElement('button'); hbtn.type = 'button'; hbtn.setAttribute('data-aihub', '1');
      hbtn.setAttribute('aria-label', 'Joindre un fichier AI Hub'); hbtn.title = 'Joindre un fichier de tes projets AI Hub';
      hbtn.appendChild(hsvg());
      hbtn.addEventListener('mousedown', (e) => e.preventDefault());
      hbtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); toggleHubMenu(); });
    }
    let att = null, el = comp;
    for (let i = 0; i < 10 && el && !att; i++, el = el.parentElement) att = [...el.querySelectorAll(ATT)].find((b) => b !== hbtn && vis(b));
    if (att) {
      if (hbtn.dataset.mode !== 'inline' || hbtn.previousElementSibling !== att) {
        hbtn.style.cssText = ''; hbtn.className = att.className; att.insertAdjacentElement('afterend', hbtn); hbtn.dataset.mode = 'inline';
      }
      hbtn.style.display = '';
    } else {
      if (hbtn.dataset.mode !== 'float' || hbtn.parentElement !== document.body) {
        hbtn.className = ''; document.body.appendChild(hbtn); hbtn.dataset.mode = 'float';
        hbtn.style.cssText = 'position:fixed;z-index:2147483000;width:34px;height:34px;border-radius:10px;border:1px solid rgba(128,128,128,.35);background:rgba(128,128,128,.12);color:inherit;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0';
      }
      const r = comp.getBoundingClientRect();
      hbtn.style.left = Math.max(6, r.left) + 'px'; hbtn.style.top = Math.max(6, r.top - 40) + 'px'; hbtn.style.display = 'flex';
    }
  } catch {}
}
setInterval(ensureHubBtn, 700);

const hDark = () => {
  for (const e of [document.body, document.documentElement]) {
    const m = (getComputedStyle(e).backgroundColor || '').match(/[\d.]+/g);
    if (m && m.length >= 3 && !(m.length > 3 && +m[3] === 0)) return (+m[0] * 299 + +m[1] * 587 + +m[2] * 114) / 1000 < 128;
  }
  return matchMedia('(prefers-color-scheme: dark)').matches;
};
const hSize = (n) => n < 1024 ? n + ' o' : n < 1048576 ? Math.round(n / 1024) + ' Ko' : (n / 1048576).toFixed(1).replace('.', ',') + ' Mo';
function hel(tag, css, text) { const e = document.createElement(tag); if (css) e.style.cssText = css; if (text != null) e.textContent = text; return e; }
const onHubDown = (e) => { if (hmenu && !hmenu.contains(e.target) && !(hbtn && hbtn.contains(e.target))) closeHubMenu(); };
const onHubKey = (e) => { if (e.key === 'Escape') closeHubMenu(); };
function closeHubMenu() {
  if (hmenu) { hmenu.remove(); hmenu = null; hlist = null; hfoot = null; } SELH.clear();
  document.removeEventListener('mousedown', onHubDown, true); document.removeEventListener('keydown', onHubKey, true);
}
function toggleHubMenu() {
  if (hmenu) return closeHubMenu();
  ipcRenderer.sendToHost('hub-attach-open');      // l'app renvoie la liste à jour (hub:menu)
  const dark = hDark();
  hmenu = hel('div', 'position:fixed;z-index:2147483647;width:330px;max-height:62vh;overflow:auto;box-sizing:border-box;padding:6px;border-radius:12px;font:13px/1.35 system-ui,-apple-system,Segoe UI,sans-serif;box-shadow:0 8px 30px rgba(0,0,0,.28);border:1px solid ' + (dark ? '#4a4843' : '#e4e1d6') + ';background:' + (dark ? '#2b2a27' : '#fff') + ';color:' + (dark ? '#ece9e0' : '#1f1e1d'));
  hmenu.dataset.dark = dark ? '1' : '';
  hmenu.appendChild(hel('div', 'font-size:11px;font-weight:600;letter-spacing:.05em;text-transform:uppercase;opacity:.6;padding:6px 10px 4px', 'Joindre depuis AI Hub'));
  if ((MENU.files || []).length > 8) {
    const inp = hel('input', 'width:calc(100% - 12px);margin:2px 6px 6px;padding:6px 9px;border-radius:8px;border:1px solid ' + (dark ? '#4a4843' : '#d8d4c8') + ';background:transparent;color:inherit;font:inherit;box-sizing:border-box;outline:none');
    inp.placeholder = 'Rechercher…'; inp.value = hq; inp.addEventListener('input', () => { hq = inp.value; drawHubMenu(); });
    hmenu.appendChild(inp);
  }
  hlist = hel('div', ''); hmenu.appendChild(hlist);
  hfoot = hel('div', 'position:sticky;bottom:-6px;display:none;gap:8px;align-items:center;padding:8px 6px 4px;margin-top:4px'); hmenu.appendChild(hfoot);
  document.body.appendChild(hmenu); drawHubMenu();
  const r = hbtn.getBoundingClientRect();
  hmenu.style.left = Math.max(8, Math.min(r.left, innerWidth - 338)) + 'px';
  if (r.top > innerHeight / 2) hmenu.style.bottom = Math.max(8, innerHeight - r.top + 8) + 'px'; else hmenu.style.top = (r.bottom + 8) + 'px';
  document.addEventListener('mousedown', onHubDown, true); document.addEventListener('keydown', onHubKey, true);
}
function drawHubMenu() {
  if (!hlist) return;
  updHubFoot();
  const dark = !!hmenu.dataset.dark, hov = dark ? 'rgba(255,255,255,.08)' : 'rgba(31,30,29,.06)', pick = (o) => { ipcRenderer.sendToHost('hub-attach-pick', o); closeHubMenu(); };
  const files = (MENU.files || []).filter((f) => !hq || f.name.toLowerCase().includes(hq.toLowerCase()));
  hlist.textContent = '';
  if (!(MENU.files || []).length) { hlist.appendChild(hel('div', 'padding:10px;opacity:.7', 'Aucun fichier. Ajoute-en dans AI Hub > Fichiers (tu peux les classer par projet).')); return; }
  if (!files.length) { hlist.appendChild(hel('div', 'padding:10px;opacity:.7', 'Aucun fichier ne correspond.')); return; }
  const groups = (MENU.projects || []).map((p) => ({ p, f: files.filter((x) => x.proj === p.id) })).concat([{ p: null, f: files.filter((x) => !x.proj) }]).filter((g) => g.f.length);
  for (const g of groups) {
    const head = hel('div', 'display:flex;align-items:center;gap:8px;padding:8px 10px 3px');
    head.appendChild(hel('span', 'flex:1;font-weight:600;font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap', g.p ? g.p.name : 'Sans projet'));
    if (g.p) {
      const b = hel('button', 'border:0;background:none;color:#c6613f;font:inherit;font-size:11.5px;cursor:pointer;padding:2px 4px;border-radius:6px', 'contexte seul');
      b.title = 'Ajoute seulement le résumé du projet dans la zone de message'; b.addEventListener('click', () => pick({ pid: g.p.id })); head.appendChild(b);
    }
    { const allIn = g.f.every((x) => SELH.has(x.id)); const sb = hel('button', 'border:0;background:none;color:#c6613f;font:inherit;font-size:11.5px;cursor:pointer;padding:2px 4px;border-radius:6px', allIn ? 'désélectionner' : 'tout sélectionner'); sb.title = 'Sélectionne tous les fichiers de ce groupe pour les envoyer en une fois'; sb.addEventListener('click', () => { g.f.forEach((x) => allIn ? SELH.delete(x.id) : SELH.add(x.id)); drawHubMenu(); }); head.appendChild(sb); }
    hlist.appendChild(head);
    for (const f of g.f) {
      const row = hel('button', 'display:flex;align-items:center;gap:9px;width:100%;padding:7px 10px;border:0;background:none;color:inherit;font:inherit;text-align:left;cursor:pointer;border-radius:8px');
      const ext = ((f.name.includes('.') ? f.name.split('.').pop() : 'file') || 'file').slice(0, 4).toUpperCase();
      row.appendChild(mkCb(f.id)); row.appendChild(hel('span', 'flex:none;min-width:34px;text-align:center;font-size:10px;font-weight:700;padding:3px 4px;border-radius:6px;background:' + (dark ? 'rgba(198,97,63,.22)' : 'rgba(198,97,63,.12)') + ';color:#c6613f', ext));
      row.appendChild(hel('span', 'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap', f.name));
      row.appendChild(hel('span', 'flex:none;font-size:11.5px;opacity:.55', hSize(f.size)));
      row.addEventListener('mouseenter', () => { row.style.background = hov; }); row.addEventListener('mouseleave', () => { row.style.background = 'none'; });
      row.addEventListener('click', () => { if (SELH.size) { SELH.has(f.id) ? SELH.delete(f.id) : SELH.add(f.id); drawHubMenu(); } else pick({ fid: f.id }); }); hlist.appendChild(row);
    }
  }
}

function mkCb(id) {
  const cb = hel('input', 'flex:none;width:15px;height:15px;margin:0;accent-color:#c6613f;cursor:pointer'); cb.type = 'checkbox'; cb.checked = SELH.has(id); cb.title = 'Sélectionner pour envoyer plusieurs fichiers';
  cb.addEventListener('click', (e) => e.stopPropagation()); cb.addEventListener('change', () => { cb.checked ? SELH.add(id) : SELH.delete(id); drawHubMenu(); }); return cb;
}
function updHubFoot() {
  if (!hfoot) return; hfoot.textContent = '';
  if (!SELH.size) { hfoot.style.display = 'none'; return; }
  const dark = hmenu && hmenu.dataset.dark; hfoot.style.display = 'flex'; hfoot.style.background = dark ? '#2b2a27' : '#fff'; hfoot.style.borderTop = '1px solid ' + (dark ? '#4a4843' : '#e4e1d6');
  const go = hel('button', 'flex:1;border:0;border-radius:8px;padding:8px 10px;background:#c6613f;color:#fff;font:inherit;font-weight:600;cursor:pointer', 'Joindre ' + SELH.size + ' fichier' + (SELH.size > 1 ? 's' : ''));
  go.addEventListener('click', () => { const fids = [...SELH]; ipcRenderer.sendToHost('hub-attach-pick', { fids }); closeHubMenu(); });
  const no = hel('button', 'border:0;background:none;color:inherit;opacity:.7;font:inherit;cursor:pointer;padding:6px 8px', 'Annuler'); no.addEventListener('click', () => { SELH.clear(); drawHubMenu(); });
  hfoot.appendChild(go); hfoot.appendChild(no);
}
