const { app, BrowserWindow, ipcMain, session, clipboard, dialog, Notification, shell, nativeTheme } = require('electron');
const path = require('path'), fs = require('fs'), crypto = require('crypto');
const { pathToFileURL } = require('url');

module.exports = function start(ctx) {
let win;
// (Le dossier de données fixe est défini par le lanceur main.js)
const ud = () => app.getPath('userData');
const STATE = () => path.join(ud(), 'ai-hub-state.json');
const BK = () => path.join(ud(), 'backups');
let lastBk = 0;

// Thème enregistré (lu avant d'ouvrir la fenêtre pour éviter un flash blanc/noir au démarrage)
const BG = { dark: '#262624', light: '#FAF9F5' };
function savedTheme() { try { const t = JSON.parse(fs.readFileSync(STATE(), 'utf8')).settings.theme; return ['light', 'dark'].includes(t) ? t : 'system'; } catch { return 'system'; } }
if (process.platform === 'win32') { try { app.setAppUserModelId('com.aihub.app'); } catch {} }   // nécessaire pour les notifications Windows

// Retire le drapeau « automatisé » de Chromium (une des choses que regarde la page de connexion Google)
try { app.commandLine.appendSwitch('disable-blink-features', 'AutomationControlled'); } catch {}

// Les sites ne peuvent pas envoyer leurs propres notifications ni demander la position : AI Hub centralise les notifications
const DENY = new Set(['notifications', 'geolocation', 'midi', 'midiSysex']);
app.on('session-created', (s) => {
  try {
    s.setPermissionRequestHandler((_wc, perm, cb) => cb(!DENY.has(perm)));
    s.setPermissionCheckHandler((_wc, perm) => !DENY.has(perm));
  } catch {}
});

// Connexion Google ("ce navigateur ou cette application ne sont peut-être pas sécurisés") : on retire toute trace d'Electron
// de l'identité du navigateur, dans les en-têtes réseau (User-Agent + sec-ch-ua) ET dans les fenêtres de connexion (popups).
const CHROME_FULL = process.versions.chrome || '130.0.0.0', CHROME_MAJOR = CHROME_FULL.split('.')[0];
const cleanUA = (ua) => String(ua || '').replace(/\s?Electron\/\S+/, '').replace(/\s?ai-hub\/\S+/, '').replace(/\s?AI Hub\/\S+/i, '');
// Client Hints d'un vrai Google Chrome (Electron n'annonce que « Chromium » + « Electron », ce que Google refuse)
const CH_BRANDS = '"Chromium";v="' + CHROME_MAJOR + '", "Google Chrome";v="' + CHROME_MAJOR + '", "Not?A_Brand";v="99"';
const CH_FULL = '"Chromium";v="' + CHROME_FULL + '", "Google Chrome";v="' + CHROME_FULL + '", "Not?A_Brand";v="99.0.0.0"';
const GOOGLE_HOST = /(^|\.)(google\.[a-z.]+|gstatic\.com|googleapis\.com|googleusercontent\.com|youtube\.com)$/i;
app.on('session-created', (s) => {
  try {
    s.setUserAgent(cleanUA(s.getUserAgent()));
    s.webRequest.onBeforeSendHeaders((d, cb) => {
      const h = d.requestHeaders; let host = ''; try { host = new URL(d.url).hostname; } catch {}
      let hasCh = false, hasFull = false;
      for (const k of Object.keys(h)) {
        if (/^user-agent$/i.test(k)) h[k] = cleanUA(h[k]);
        else if (/^sec-ch-ua$/i.test(k)) { h[k] = CH_BRANDS; hasCh = true; }
        else if (/^sec-ch-ua-full-version-list$/i.test(k)) { h[k] = CH_FULL; hasFull = true; }
      }
      if (GOOGLE_HOST.test(host) && /^https:/i.test(d.url)) { if (!hasCh) h['sec-ch-ua'] = CH_BRANDS; if (!hasFull) h['sec-ch-ua-full-version-list'] = CH_FULL; }
      cb({ requestHeaders: h });
    });
  } catch {}
});
app.on('web-contents-created', (_e, wc) => { try { wc.setUserAgent(cleanUA(wc.getUserAgent())); } catch {} });

function create() {
  nativeTheme.themeSource = savedTheme();
  win = new BrowserWindow({
    width: 1440, height: 900, backgroundColor: nativeTheme.shouldUseDarkColors ? BG.dark : BG.light, autoHideMenuBar: true,
    icon: fs.existsSync(path.join(__dirname, 'icon.ico')) ? path.join(__dirname, 'icon.ico') : undefined,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), webviewTag: true, contextIsolation: true }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  nativeTheme.on('updated', () => { try { win.setBackgroundColor(nativeTheme.shouldUseDarkColors ? BG.dark : BG.light); } catch {} });
  win.webContents.on('render-process-gone', (_e, d) => { ctx.fatal('interface plantée : ' + (d && d.reason)); });
}

// ---------- 2.4.0 : détection par le réseau + historique local des conversations ----------
const NET_HOSTS = /(^|\.)(claude\.ai|chatgpt\.com|openai\.com|gemini\.google\.com)$/;
const COMPLETION = /\/(completion|backend-api\/(f\/)?conversation|StreamGenerate)(\/|$)/i;
app.on('session-created', (s) => {
  try {
    s.webRequest.onCompleted((d) => {
      try {
        if (!win || win.isDestroyed() || !d.webContentsId) return;
        const u = new URL(d.url);
        if (!NET_HOSTS.test(u.hostname)) return;
        const isComp = d.method === 'POST' && COMPLETION.test(u.pathname);
        const bad = [429, 503, 529].includes(d.statusCode) && (isComp || /\/(api|backend-api)\//.test(u.pathname));
        if (!isComp && !bad) return;
        const h = d.responseHeaders || {};
        const pick = (n) => { const k = Object.keys(h).find((x) => x.toLowerCase() === n); return k ? String([].concat(h[k])[0]) : null; };
        let until = 0; const ra = pick('retry-after');
        if (ra) { const n = Number(ra); until = isFinite(n) ? Date.now() + n * 1000 : (Date.parse(ra) || 0); }
        const quota = {};
        for (const k of Object.keys(h)) if (/ratelimit|usage|quota/i.test(k)) quota[k.toLowerCase()] = String([].concat(h[k])[0]).slice(0, 120);
        win.webContents.send('net-event', { wc: d.webContentsId, status: d.statusCode, host: u.hostname, completion: isComp, until, quota, ts: Date.now() });
      } catch {}
    });
  } catch {}
});

// Historique local : un fichier JSON (300 conversations max), recherche plein texte simple
const CV = () => path.join(ud(), 'conversations.json');
let cvCache = null, cvT = null;
const cvLoad = () => cvCache || (cvCache = (() => { try { const j = JSON.parse(fs.readFileSync(CV(), 'utf8')); return Array.isArray(j) ? j : []; } catch { return []; } })());
const cvWrite = () => { try { fs.writeFileSync(CV() + '.tmp', JSON.stringify(cvCache || [])); fs.renameSync(CV() + '.tmp', CV()); } catch {} };
const cvSave = () => { clearTimeout(cvT); cvT = setTimeout(cvWrite, 1500); };
app.on('before-quit', () => { if (cvCache) cvWrite(); });
ipcMain.handle('conv:put', (_e, c) => {
  if (!c || !c.key || !c.text) return false;
  const l = cvLoad(), key = String(c.key).slice(0, 300), i = l.findIndex((x) => x.key === key);
  if (i >= 0) l.splice(i, 1);
  l.unshift({ key, acc: c.acc, platform: c.platform, name: c.name, url: String(c.url || '').slice(0, 500), title: String(c.title || '').slice(0, 160), ts: Date.now(), text: String(c.text).slice(-60000) });
  if (l.length > 300) l.length = 300;
  cvSave(); return true;
});
ipcMain.handle('conv:search', (_e, q) => {
  const terms = String(q || '').toLowerCase().split(/\s+/).filter(Boolean).slice(0, 6);
  if (!terms.length) return [];
  const out = [];
  for (const c of cvLoad()) {
    const t = c.text.toLowerCase(), ti = (c.title || '').toLowerCase();
    if (!terms.every((w) => t.includes(w) || ti.includes(w))) continue;
    let score = 0; for (const w of terms) { score += (ti.includes(w) ? 5 : 0) + Math.min(10, t.split(w).length - 1); }
    const p = Math.max(0, t.indexOf(terms[0]) - 60);
    out.push({ score, key: c.key, acc: c.acc, platform: c.platform, name: c.name, url: c.url, title: c.title, ts: c.ts, snip: c.text.slice(p, p + 180).replace(/\s+/g, ' ') });
  }
  return out.sort((a, b) => b.score - a.score || b.ts - a.ts).slice(0, 20);
});
ipcMain.handle('conv:count', () => cvLoad().length);
ipcMain.handle('conv:clear', () => { cvCache = []; cvWrite(); return true; });

ipcMain.handle('copy', (_e, t) => clipboard.writeText(t));
ipcMain.handle('clear', (_e, p) => session.fromPartition(p).clearStorageData());
ipcMain.handle('wvpreload', () => pathToFileURL(path.join(__dirname, 'webview-preload.js')).href);
// Notifications Windows : un clic ramène la fenêtre au premier plan et ouvre le compte concerné
const liveNotifs = new Set();
ipcMain.handle('notify', (_e, t, b, accId) => {
  if (!Notification.isSupported()) return { ok: false, error: 'unsupported' };
  try {
    const n = new Notification({ title: String(t || 'AI Hub'), body: String(b || '') });
    liveNotifs.add(n);                                   // garder une référence (sinon le clic peut être perdu)
    n.on('close', () => liveNotifs.delete(n));
    n.on('failed', () => liveNotifs.delete(n));
    n.on('click', () => {
      liveNotifs.delete(n);
      if (!win) return;
      if (win.isMinimized()) win.restore();
      win.show(); win.focus();
      win.webContents.send('notif-click', accId || null);
    });
    n.show();
    return { ok: true };
  } catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('theme:set', (_e, t) => { nativeTheme.themeSource = ['light', 'dark'].includes(t) ? t : 'system'; return nativeTheme.shouldUseDarkColors; });

// Export de tous les comptes : liste + cookies de chaque session, chiffré (AES-256-GCM) si mot de passe
ipcMain.handle('export', async (_e, { state, partitions, pass }) => {
  const cookies = {};
  for (const p of partitions) cookies[p] = await session.fromPartition(p).cookies.get({});
  const data = JSON.stringify({ app: 'ai-hub', version: app.getVersion(), v: 1, exportedAt: new Date().toISOString(), state, cookies });
  let out = data;
  if (pass) {
    const salt = crypto.randomBytes(16), iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv('aes-256-gcm', crypto.scryptSync(pass, salt, 32), iv);
    const enc = Buffer.concat([c.update(data, 'utf8'), c.final()]);
    out = JSON.stringify({ app: 'ai-hub', version: app.getVersion(), enc: 1, salt: salt.toString('base64'), iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: enc.toString('base64') });
  }
  const r = await dialog.showSaveDialog(win, { defaultPath: 'ai-hub-comptes-' + new Date().toISOString().slice(0, 10) + '.json' });
  if (r.canceled) return { ok: false };
  fs.writeFileSync(r.filePath, out);
  return { ok: true, path: r.filePath, encrypted: !!pass };
});

ipcMain.handle('import', async (_e, pass) => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'JSON', extensions: ['json'] }], properties: ['openFile'] });
  if (r.canceled) return { ok: false };
  let j = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8'));
  const ver = j.version;
  if (j.app && j.app !== 'ai-hub') return { ok: false, error: 'Ce fichier ne vient pas de AI Hub' };
  if (j.enc) {
    try {
      const d = crypto.createDecipheriv('aes-256-gcm', crypto.scryptSync(pass || '', Buffer.from(j.salt, 'base64'), 32), Buffer.from(j.iv, 'base64'));
      d.setAuthTag(Buffer.from(j.tag, 'base64'));
      j = JSON.parse(Buffer.concat([d.update(Buffer.from(j.data, 'base64')), d.final()]).toString('utf8'));
    } catch { return { ok: false, error: 'Mot de passe incorrect ou fichier corrompu' }; }
  }
  let n = 0;
  for (const [p, list] of Object.entries(j.cookies || {})) for (const c of list) {
    try {
      const o = { url: `http${c.secure ? 's' : ''}://${c.domain.replace(/^\./, '')}${c.path}`, name: c.name, value: c.value, path: c.path, secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite, expirationDate: c.expirationDate };
      if (!c.hostOnly) o.domain = c.domain;
      await session.fromPartition(p).cookies.set(o); n++;
    } catch {}
  }
  return { ok: true, state: j.state, cookies: n, version: ver || j.version, current: app.getVersion() };
});

// Sauvegarde de l'état (comptes, code, détections) dans un fichier avec copies de secours
const count = (s) => { try { return (JSON.parse(s).accs || []).length; } catch { return -1; } };
ipcMain.handle('state:load', () => {
  const files = [STATE()];
  try { files.push(...fs.readdirSync(BK()).sort().reverse().map((f) => path.join(BK(), f))); } catch {}
  for (const f of files) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch {} }
  return null;
});
ipcMain.handle('state:save', (_e, json) => {
  fs.mkdirSync(BK(), { recursive: true });
  try {
    const old = fs.readFileSync(STATE(), 'utf8');
    if (old !== json && (count(json) < count(old) || Date.now() - lastBk > 60000)) {
      fs.writeFileSync(path.join(BK(), 'state-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json'), old); lastBk = Date.now();
      fs.readdirSync(BK()).sort().reverse().slice(40).forEach((f) => fs.unlinkSync(path.join(BK(), f)));
    }
  } catch {}
  fs.writeFileSync(STATE() + '.tmp', json); fs.renameSync(STATE() + '.tmp', STATE());
  return true;
});
// Sessions qui existent sur le disque mais ne sont plus dans la liste des comptes
ipcMain.handle('orphans', async (_e, known) => {
  let names = []; try { names = fs.readdirSync(path.join(ud(), 'Partitions')); } catch {}
  const out = [];
  for (const n of names) {
    if (!/^a\d+$/.test(n) || known.includes(n)) continue;
    const ck = await session.fromPartition('persist:' + n).cookies.get({});
    if (ck.length) out.push({ id: n, domains: [...new Set(ck.map((c) => c.domain.replace(/^\./, '')))] });
  }
  return out;
});
ipcMain.handle('open-data', () => shell.openPath(ud()));


// ---------- Résumé par Gemini (appel fait ici, dans le processus principal : pas de souci CORS) ----------
ipcMain.handle('gemini', async (_e, { key, model, system, prompt }) => {
  if (!key) return { ok: false, error: 'Clé Gemini absente' };
  const m = String(model || 'gemini-flash-latest').replace(/[^\w.\-]/g, '');
  const ac = new AbortController(), to = setTimeout(() => ac.abort(), 90000);
  try {
    const r = await fetch((process.env.AIHUB_GEMINI_URL || 'https://generativelanguage.googleapis.com/v1beta/models/') + m + ':generateContent', {
      method: 'POST', signal: ac.signal, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ systemInstruction: system ? { parts: [{ text: system }] } : undefined, contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.2, maxOutputTokens: 8192 } })
    });
    const j = await r.json().catch(() => null);
    if (!r.ok) return { ok: false, status: r.status, error: (j && j.error && j.error.message) || 'HTTP ' + r.status };
    const c = j && j.candidates && j.candidates[0];
    const text = ((c && c.content && c.content.parts) || []).map((p) => p.text || '').join('').trim();
    if (!text) return { ok: false, error: 'Réponse vide (' + ((c && c.finishReason) || (j && j.promptFeedback && j.promptFeedback.blockReason) || '?') + ')' };
    return { ok: true, text };
  } catch (e) { return { ok: false, error: e.name === 'AbortError' ? 'Délai dépassé (90 s)' : e.message }; }
  finally { clearTimeout(to); }
});

// ---------- Mises à jour (la logique est dans updater.js, testée à part) ----------
const backupState = (ver) => {                       // copie des données AVANT d'installer : on ne perd rien
  try { fs.mkdirSync(BK(), { recursive: true }); fs.copyFileSync(STATE(), path.join(BK(), 'state-' + new Date().toISOString().replace(/[:.]/g, '-') + '-avant-maj-' + ver + '.json')); } catch {}
};
ipcMain.handle('upd:info', () => Object.assign(ctx.updater.info(), { active: ctx.boot.version, rolledBack: ctx.boot.rolledBack, dataDir: ud() }));
ipcMain.handle('upd:apply', async () => {
  const r = await dialog.showOpenDialog(win, { filters: [{ name: 'Mise à jour AI Hub', extensions: ['aihubupdate', 'json'] }], properties: ['openFile'] });
  if (r.canceled) return { ok: false, cancelled: true };
  try { return ctx.updater.install(ctx.updater.readPackage(r.filePaths[0]), { beforeInstall: backupState }); }
  catch (e) { return { ok: false, error: 'Fichier illisible : ' + e.message }; }
});
ipcMain.handle('upd:revert', (_e, to) => ctx.updater.revert(to));
ipcMain.handle('upd:healthy', () => ctx.updater.confirm());
ipcMain.handle('upd:fail', (_e, reason) => ctx.fatal('interface : ' + String(reason).slice(0, 200)));
ipcMain.handle('relaunch', () => { ctx.relaunch(); });
// ---------- 2.5.4 : export du logiciel complet en ZIP (mode développeur) ----------
// <PACK>
const zlib = require('zlib');
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC_T[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
function makeZip(entries) {                       // entries : [{ name, data: Buffer, mtime: Date }]
  const parts = [], central = []; let off = 0;
  for (const e of entries) {
    const name = Buffer.from(e.name, 'utf8'), raw = e.data, def = zlib.deflateRawSync(raw), useDef = def.length < raw.length;
    const body = useDef ? def : raw, method = useDef ? 8 : 0, crc = crc32(raw), d = e.mtime || new Date();
    const dt = (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF, tm = ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xFFFF;
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(method, 8); lh.writeUInt16LE(tm, 10); lh.writeUInt16LE(dt, 12);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(name.length, 26);
    parts.push(lh, name, body);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(method, 10); ch.writeUInt16LE(tm, 12); ch.writeUInt16LE(dt, 14);
    ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(body.length, 20); ch.writeUInt32LE(raw.length, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(off, 42);
    central.push(ch, name);
    off += 30 + name.length + body.length;
  }
  const cd = Buffer.concat(central), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cd, end]);
}
const PACK_SKIP = /^(node_modules|\.git|dist|out|release)$/i;
function packWalk(root, rel, map, lim) {
  let names; try { names = fs.readdirSync(path.join(root, rel)); } catch { return; }
  for (const n of names) {
    const r = rel ? rel + '/' + n : n, full = path.join(root, r);
    let st; try { st = fs.statSync(full); } catch { continue; }
    if (st.isDirectory()) { if (!PACK_SKIP.test(n)) packWalk(root, r, map, lim); continue; }
    if (!st.isFile() || st.size > 40 * 1048576) continue;
    if (lim.n >= 5000 || lim.bytes + st.size > 300 * 1048576) throw new Error('logiciel trop gros pour le ZIP (plus de 5000 fichiers ou 300 Mo)');
    map.set(r, { name: r, data: fs.readFileSync(full), mtime: st.mtime }); lim.n++; lim.bytes += st.size;
  }
}
function packApp(ver, appRoot, activeDir) {
  const map = new Map(), lim = { n: 0, bytes: 0 };
  packWalk(appRoot, '', map, lim);                                                  // lanceur + fichiers d'origine
  if (path.resolve(activeDir) !== path.resolve(appRoot)) packWalk(activeDir, '', map, lim);   // version active : remplace les fichiers du même nom
  const core = ['main-core.js', 'preload.js', 'webview-preload.js', 'index.html'];
  if (core.every((f) => map.has(f))) {                                              // paquet de mise à jour prêt à réinstaller
    const files = {};
    for (const f of core) { const c = map.get(f).data.toString('utf8'); files[f] = { sha256: crypto.createHash('sha256').update(c, 'utf8').digest('hex'), content: c }; }
    map.set('ai-hub-update-' + ver + '.aihubupdate', { name: 'ai-hub-update-' + ver + '.aihubupdate', data: Buffer.from(JSON.stringify({ app: 'ai-hub-update', format: 1, version: ver, notes: 'Export complet du logiciel', createdAt: new Date().toISOString(), requiresLauncher: null, files }), 'utf8') });
  }
  map.set('LISEZMOI-EXPORT.txt', { name: 'LISEZMOI-EXPORT.txt', data: Buffer.from(
    'AI Hub - export du logiciel\r\nVersion : ' + ver + '\r\nCréé le : ' + new Date().toLocaleString('fr-FR') + '\r\n\r\n' +
    'Contenu : les fichiers du logiciel dans leur état actuel (version active par-dessus les fichiers du lanceur).\r\n' +
    'Ne contient PAS tes comptes, cookies, conversations ni ton code personnalisé (ils restent dans ' + ud() + ').\r\n\r\n' +
    'Pour relancer depuis les sources : installer Node.js, puis dans ce dossier : npm install electron  puis  npx electron .\r\n' +
    'Pour réinstaller cette version dans AI Hub : Paramètres > Mises à jour > Installer un fichier de mise à jour > ai-hub-update-' + ver + '.aihubupdate\r\n', 'utf8') });
  const entries = [...map.values()];
  return { buf: makeZip(entries), count: entries.length };
}
// </PACK>
ipcMain.handle('pack:zip', async () => {
  try {
    const info = ctx.updater.info(), boot = ctx.boot || {};
    const ver = boot.version && boot.version !== 'bundled' ? boot.version : (info.launcherVersion || app.getVersion());
    const r = await dialog.showSaveDialog(win, { defaultPath: 'ai-hub-' + ver + '-' + new Date().toISOString().slice(0, 10) + '.zip', filters: [{ name: 'ZIP', extensions: ['zip'] }] });
    if (r.canceled || !r.filePath) return { ok: false, cancelled: true };
    const res = packApp(ver, app.getAppPath(), __dirname);
    fs.writeFileSync(r.filePath, res.buf);
    try { shell.showItemInFolder(r.filePath); } catch {}
    return { ok: true, path: r.filePath, files: res.count, size: res.buf.length, version: ver };
  } catch (e) { return { ok: false, error: e.message }; }
});

// ---------- 2.5.5 : connexion via le vrai Google Chrome (Google refuse les fenêtres intégrées) ----------
// On ouvre un vrai Chrome (profil temporaire, port de débogage local), tu t'y connectes normalement,
// puis AI Hub lit les cookies du site concerné et les copie dans le compte. Le profil temporaire est supprimé ensuite.
// <CHROME>
const http = require('http'), cp = require('child_process'), os = require('os');
let chromeProc = null, chromeDir = null;
function chromePaths() {
  const e = process.env, c = [];
  if (process.platform === 'win32') {
    for (const b of [e.LOCALAPPDATA, e.ProgramFiles, e['ProgramFiles(x86)']]) if (b) c.push(path.join(b, 'Google', 'Chrome', 'Application', 'chrome.exe'));
    for (const b of [e['ProgramFiles(x86)'], e.ProgramFiles, e.LOCALAPPDATA]) if (b) c.push(path.join(b, 'Microsoft', 'Edge', 'Application', 'msedge.exe'));
  } else if (process.platform === 'darwin') {
    c.push('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge');
  } else {
    c.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge');
  }
  return c;
}
const cdpJson = (port, p) => new Promise((res, rej) => {
  const r = http.get({ host: '127.0.0.1', port, path: p, timeout: 3000 }, (m) => { let d = ''; m.on('data', (x) => { d += x; }); m.on('end', () => { try { res(JSON.parse(d)); } catch (e) { rej(e); } }); });
  r.on('error', rej); r.on('timeout', () => r.destroy(new Error('délai dépassé')));
});
// cookie Chrome (protocole DevTools) -> cookie Electron ; null si à ignorer
function toElectronCookie(c, hosts) {
  const raw = String(c.domain || ''), dom = raw.replace(/^\./, '').toLowerCase();
  if (!dom || c.partitionKey || /^(cf_clearance|__cf_bm|_cfuvid)$/.test(c.name)) return null;
  if (!hosts.some((h) => dom === h || dom.endsWith('.' + h))) return null;
  const o = { url: 'http' + (c.secure ? 's' : '') + '://' + dom + (c.path || '/'), name: c.name, value: c.value, path: c.path || '/', secure: !!c.secure, httpOnly: !!c.httpOnly };
  if (raw.startsWith('.')) o.domain = raw;
  const ss = String(c.sameSite || '').toLowerCase();
  o.sameSite = ss === 'none' ? 'no_restriction' : ss === 'lax' ? 'lax' : ss === 'strict' ? 'strict' : 'unspecified';
  if (c.expires > 0) o.expirationDate = c.expires;
  return o;
}
function chromeClean() {                           // supprime les profils temporaires oubliés (ils contiennent une session Google)
  try { for (const n of fs.readdirSync(os.tmpdir())) if (/^ai-hub-chrome-\d+$/.test(n)) { try { fs.rmSync(path.join(os.tmpdir(), n), { recursive: true, force: true, maxRetries: 8, retryDelay: 400 }); } catch {} } } catch {}
}
function chromeStop() {
  const p = chromeProc, dir = chromeDir; chromeProc = null; chromeDir = null;
  if (p && p.exitCode === null) {
    try { if (process.platform === 'win32') cp.execFile('taskkill', ['/pid', String(p.pid), '/T', '/F'], () => {}); else p.kill('SIGTERM'); } catch {}
  }
  if (dir) setTimeout(() => { try { fs.rmSync(dir, { recursive: true, force: true, maxRetries: 8, retryDelay: 400 }); } catch {} }, 1500);
}
// </CHROME>
ipcMain.handle('chrome:start', async (_e, url) => {
  try {
    chromeStop(); chromeClean();
    if (!/^https:\/\/[\w.-]+(\/|$)/i.test(String(url))) return { ok: false, error: 'adresse invalide' };
    const exe = chromePaths().find((p) => { try { return fs.existsSync(p); } catch { return false; } });
    if (!exe) return { ok: false, error: "Google Chrome (ou Microsoft Edge) n'est pas installé sur cet ordinateur." };
    const port = 9300 + Math.floor(Math.random() * 500);
    chromeDir = path.join(os.tmpdir(), 'ai-hub-chrome-' + Date.now());
    fs.mkdirSync(chromeDir, { recursive: true });
    const proc = cp.spawn(exe, ['--user-data-dir=' + chromeDir, '--remote-debugging-port=' + port, '--remote-allow-origins=*', '--no-first-run', '--no-default-browser-check', String(url)], { stdio: 'ignore' });
    chromeProc = proc; let dead = false; proc.on('exit', () => { dead = true; }); proc.on('error', () => { dead = true; });
    for (let i = 0; i < 40; i++) {                  // attend que Chrome réponde (20 s max)
      await new Promise((r) => setTimeout(r, 500));
      if (dead) { chromeStop(); return { ok: false, error: 'Chrome s\'est fermé au démarrage.' }; }
      try { const v = await cdpJson(port, '/json/version'); if (v && v.webSocketDebuggerUrl) return { ok: true, port, browser: String(v.Browser || '') }; } catch {}
    }
    chromeStop(); return { ok: false, error: 'Chrome ne répond pas.' };
  } catch (e) { chromeStop(); return { ok: false, error: e.message }; }
});
ipcMain.handle('chrome:ws', async (_e, port) => {
  try { const v = await cdpJson(Number(port), '/json/version'); return { ok: true, ws: v.webSocketDebuggerUrl }; }
  catch { return { ok: false, error: 'Chrome ne répond plus (l\'as-tu fermé ?). Clique « Ouvrir Chrome » pour recommencer.' }; }
});
ipcMain.handle('chrome:import', async (_e, { partition, hosts, cookies }) => {
  try {
    if (!/^persist:a\d+$/.test(String(partition))) return { ok: false, error: 'compte invalide' };
    const ses = session.fromPartition(partition); let n = 0, skipped = 0;
    for (const c of cookies || []) {
      const o = toElectronCookie(c, (hosts || []).map((h) => String(h).toLowerCase()));
      if (!o) { skipped++; continue; }
      try { await ses.cookies.set(o); n++; } catch { skipped++; }
    }
    try { await ses.cookies.flushStore(); } catch {}
    return { ok: true, imported: n, skipped };
  } catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('chrome:stop', () => { chromeStop(); return true; });
app.on('before-quit', () => { chromeStop(); });
app.whenReady().then(chromeClean);

// Garde-fou : une nouvelle version qui ne confirme pas en 15 s est annulée
if (ctx.updater.info().pending) setTimeout(() => { if (ctx.updater.info().pending) ctx.fatal('aucune confirmation de démarrage en 15 s'); }, 15000);

// Une seule instance à la fois : empêche deux fenêtres d'écraser les mêmes données
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });
  app.whenReady().then(create);
}
app.on('window-all-closed', () => app.quit());
};
